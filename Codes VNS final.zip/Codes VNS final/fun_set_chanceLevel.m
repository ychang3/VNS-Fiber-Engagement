function [CL_RSQ, CL_RMSE ] = fun_set_chanceLevel(S, setCL,R, ifplot)

m = height(setCL);

for rep = 1:R
    idx = randperm(m)  ;
    setCL.Fiber = setCL.Fiber(idx) ;
    
    if mod(length(S), 2) == 0
        s = 1;
        modello = 0;
    else
        s = 2;
        modello = S(1);
    end
    
    modello =  modello + S(s)*setCL.amp +  S(s+1)*setCL.EMG + ...
        S(s+2)*setCL.deltaHR +  S(s+3)*setCL.deltaINT +...
        S(s+4)*setCL.amp.^2 +S(s+5)*setCL.EMG.^2 +  ...
        S(s+6)*setCL.deltaHR.^2 + S(s+7)*setCL.deltaINT.^2;
    
    modello(modello<0) = 0;
    
    dist = diff([modello*100 setCL.Fiber*100], 1, 2);
    RMSE = rms(dist);
    RMSETOT_CL(rep) = RMSE;
    rsq = (corrcoef(setCL.Fiber*100 , modello*100)); rsq = rsq(1, 2)^2;
    RSQTOT_CL(rep) = rsq;
    
end

sormse = sort(RMSETOT_CL);
CL_RMSE = sormse(round(length(sormse)/R*0.05*R+1));

sorrsq = sort(RSQTOT_CL);
CL_RSQ = sorrsq(round(length(sorrsq)/R*0.95*R-1));


if ifplot
    figure, subplot(121),hist(RMSETOT_CL, 20); hold on
    line([CL_RMSE CL_RMSE], [0 12], 'color', 'r', 'linewidth', 2)
    set(gca, 'fontsize', 14);
    title(['RMSE CL = ' num2str(CL_RMSE)], 'fontweight', 'normal')
    
    subplot(122), hist(RSQTOT_CL, 20, 'exponential'); hold on
    line([CL_RSQ CL_RSQ], [0 20], 'color', 'r', 'linewidth', 2)
    set(gca, 'fontsize', 14);
    title(['Rsquared CL = ' num2str(CL_RSQ)], 'fontweight', 'normal')
end

end

