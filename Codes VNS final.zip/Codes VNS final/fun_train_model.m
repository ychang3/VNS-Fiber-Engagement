function [Train_R2,Train_RMSE, S] = fun_train_model(Training_dev,P, K, F, interc)

m_train = height(Training_dev);
Training_dev.Fiber(isnan(Training_dev.Fiber)) = 0;
for k = 1:K
    idx_train = randperm(m_train)  ;
    Training = Training_dev(idx_train(1:round(P*m_train)),:) ;
    Dev = Training_dev(idx_train(round(P*m_train)+1:end),:) ;
    
    % model on train set
    if interc
        lm = fitlm(Training, 'purequadratic');
    else
        lm = fitlm(Training, 'purequadratic', 'Intercept' , false);
    end
    
    Tres(:, k) = lm.Coefficients.Estimate.*(lm.Coefficients.pValue<=0.01);
    fitted = lm.Fitted;

    dist = abs(diff([fitted Training.Fiber], 1, 2));
    RMSETR  = rms(dist);
    RsquTR = (corrcoef(Training.Fiber , fitted)); RsquTR = RsquTR(1, 2)^2;
    
    Train_R2(k, :) = RsquTR;
    Train_RMSE(k, :) = RMSETR;
    
end

R = array2table(Tres);
R.Properties.RowNames = lm.CoefficientNames';

Rarr = table2array(R);
somma = sum((Rarr == 0), 2);
idx = somma>K/F;
Rarr(Rarr == 0 ) = NaN;
S = nanmedian(Rarr,  2);
S(idx) = 0;

end

