%% panels G H
A = load('evalA'); B = load('evalB');
C = load('evalC');

A.corre = A.corre.^2;
B.corre = B.corre.^2;
C.corre = C.corre.^2;

A.Accur = 1-A.Accur;
B.Accur = 1-B.Accur;
C.Accur = 1-C.Accur;

figure, boxplot([A.Accur B.Accur C.Accur], [ones(1, length(A.Accur)) 2*ones(1, length(B.Accur)) 3*ones(1, length(C.Accur))]), hold on

plot(ones(1, length(A.Accur)), A.Accur, '.', 'markersize', 14), hold on
plot(2*ones(1, length(B.Accur)), B.Accur, '.', 'markersize', 14)
plot(3*ones(1, length(C.Accur)), C.Accur, '.', 'markersize', 14)

%     set(gca,'XTickLabels', {{'A vs EMG'; 'linear'},'b','c'});
ylim([0 1]), xticklabels({'A vs EMG', 'B vs HR', 'C vs LBI'})
set(gca, 'fontsize', 14)
ylabel('Accuracy')

%
figure, boxplot([A.corre B.corre C.corre], [ones(1, length(A.corre)) 2*ones(1, length(B.corre)) 3*ones(1, length(C.corre))]), hold on

plot(ones(1, length(A.corre)), A.corre, '.', 'markersize', 14), hold on
plot(2*ones(1, length(B.corre)), B.corre, '.', 'markersize', 14)
plot(3*ones(1, length(C.corre)), C.corre, '.', 'markersize', 14)

%     set(gca,'XTickLabels', {{'A vs EMG'; 'linear'},'b','c'});
ylim([0 1]), xticklabels({'A vs EMG', 'B vs HR', 'C vs LBI'})
set(gca, 'fontsize', 14)
ylabel('corr')



