%% C no discr pol
clear all
close all

CO = [255 25 25;  0 102 34; 204 102 0;
    128 128 0 ; 187 153 255;
    136 204 0; 51 8 0; 66 229 244;
    0 14 142; 71 0 142 ; 111 109 114;
    255 85 0; 255 102 102; 77 77 255 ] / 256;


PATH = 'D:\TNP\Manuscript\Fiber Recruitment\DATA';
file = 'data_table_neural_physio';
load([PATH '\' file '.mat']);
% infopath
% [Aex, bex, cex] = xlsread(excelfile, num2str(100));
% fold_tot = bex(2:end, 1);
% direc = path_dati;

discr_pol = 0; plot_fit = 1;
val_norm = []; po = [1 -1]; fig_sing = 0;

mark = {'.', 'o'}; sizemark = [18 8]; linest = {'-', '--'};
which_pw_tot = [60 100 300 500 600 1000];
%                1   2   3   4   5   6
which_pw = which_pw_tot([1:6]);

legC = {}; posC = 1; C2_apn = 300;
val_totC = [];

for pol = 1:2
    
    for i = 1:length(fold_tot)
%         clear T TBL_neu
%         experimentdir  = [direc fold_tot{i}];
%         load([experimentdir '\TBL_neu2.mat'])
        T = table_exp{i};
        
        T.deltaIntMean  = -(T.meanINTpre - T.meanInt0);
        
        if i == 1; continue; end
        if i == 7; continue; end
        if i == 8; continue; end
        
        
        if i == 2 ; T = T(T.pol == 1, :); end  %
        if i == 3 ; T = T(T.pol == -1, :); end
        if i == 5 ; T = T(T.pol == -1, :); end
        if i == 6 ; T = T(T.pol == 1, :); end  %
        if i == 9 ; T = T(T.pol == -1, :); end  %
        if i == 10 ; T = T(T.pol == -1, :); end  %
        if i == 11 ; T = T(T.pol == 1, :); end  %
        
        
        
        
        %% %%%%%%%%%%%%%%%%%%%%%% C  for apnea
        
        if ~discr_pol
            Tpi = T(isnan(T.FT) & ismember(T.pw, which_pw) & abs(T.pol) == 1, :) ;
        else
            Tpi = T(isnan(T.FT) & ismember(T.pw, which_pw) & (T.pol) == po(pol), :) ;
        end
        
        %     Tpi = T(isnan(T.FT) & ismember(T.pw, which_pw) & T.pw > 0, :) ;
        Tpi = Tpi(Tpi.pw > 0, :);
        
        clear val
     
        x = Tpi.deltaIntMean;  y = Tpi.Cfiber; z = Tpi.amp; h = Tpi.pw;  w = Tpi.pol; val = [x y z h w];
        %         val(x<-0.5 | x>20 | y > 140, :) = []; val(isnan(sum(val, 2)), :) = [];
        %         val(val(:, 2) == 0, :) = [];
        
        val(x<-0.5, :) = []; val(isnan(sum(val, 2)), :) = [];
        if i ==2 || i ==3 || i ==10 || i ==11
                val(h <= 100, :) = []; 
        end
        
        if length(val(:,1))<1; continue; end
        %          if mean(val(:,1))<1;  continue; end
        %         if mean(val(:,2))<2;  continue; end
        
        
        pola = [1 -1];
        if fig_sing
            for p = 1:2
                pola_chosen = pola(p);
                val_po = val(val(:,4) >= 500 & val(:,4) <= 600 & val(:, 5) == pola_chosen, :);
                axs = val_po(:,3); %.*val_po(:,4);
                [axs, ifs] = sort(axs) ;
                val_po  = val_po(ifs, :);
                figure(i), subplot(131), plot(axs, val_po(:, 1),'Marker',  '.', 'markersize',16)  , xlabel('x th.'), ylabel('LBI'), hold on
                subplot(132), plot(axs, val_po(:, 2), 'Marker',  '.', 'markersize',16) , xlabel('x th.'), ylabel('C fiber'), hold on
                subplot(133), plot(val_po(:,1), val_po(:, 2),   '.', 'markersize',16)  , xlabel('LBI'), ylabel('C fiber'), hold on
                title([fold_tot{i}(1:end-1) ] )
                
            end
        end
        
        figure(C2_apn)
        plot(val(:,1), val(:,2),  mark{pol}, 'markersize', sizemark(pol), 'color', CO(i, :));  hold on;
        ylabel('C fiber'), xlabel('\Delta MBI (s)'), hold on, set(gca, 'fontsize', 14)
        
        try
            fit_type1=fittype('A*(1-exp(-x./T))','coefficients', {'A', 'T'},'indep','x');
            [tilp, gofi]=fit(val(:,1), val(:,2),fit_type1,'Robust','on', ...
                'StartPoint', [max(val(:, 2)) , 3], 'Lower',[1, 0], 'MaxIter', 1e6, 'TolFun', 1e-7); fittedX = linspace(0, max(val(:,1)), 100);
            if plot_fit
                h1 = plot(fittedX, feval(tilp, fittedX), 'color', CO(i, :),'linewidth', 1, 'linestyle', linest{pol});
                set(get(get(h1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
            end
            errorC11(posC) = gofi.rmse;
            NormerrorC11(posC) = gofi.rmse/(range(val(:,2)));
            AccurC11(posC) = 1-NormerrorC11(posC);
               co = corrcoef(feval(tilp, val(:, 1)), val(:, 2));
            corre(posC)  = co(1, 2);
            stdC11(posC) = std(val(:,2)) ;
        catch
        end
        legC{posC, 1} = fold_tot{i}(1:end-1); posC = posC +1;
        title('\Delta MBI  vs C fiber')
        legend(legC)
        charge = val(:,3).*val(:,4);
        val_totC = [val_totC; [val(:, 1)./max(val(:, 1)) val(:, 2)./max(val(:, 2)) charge]];

    end
    if ~discr_pol
        break
    end
    
end


figure
plot(val_totC(:,1), val_totC(:,2), '.', 'markersize', 10), hold on
ylabel('C fiber'), xlabel('\Delta MBI'), hold on, set(gca, 'fontsize', 14)
fit_type1=fittype('A*(1-exp(-x./T))','coefficients', {'A', 'T'},'indep','x');
[tilp, gofi]=fit(val_totC(:,1), val_totC(:,2),fit_type1,'Robust','on', ...
    'StartPoint', [max(val_totC(:, 2)) , 3], 'Lower',[max(val_totC(:, 2)), 0], 'MaxIter', 1e6, 'TolFun', 1e-7);
coeffvals =  coeffvalues(tilp); fittedX = linspace(0, max(val_totC(:,1)), 100);
NormerrorCt = gofi.rmse/(range(val_totC(:,2)));
AccurCt = 1-NormerrorCt;

h1 = plot(fittedX, feval(tilp, fittedX), 'color','k','linewidth', 1, 'linestyle',linest{1});
set(get(get(h1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
title(['RMSE = ' num2str(gofi.rmse) ])

%% color code
[uu, chu, posi] = unique(val_totC(:, 3), 'sorted');
% y = sum(val_totC(:, 3)==val_totC(:, 3)');
va2 = val_totC; 
va2(y == 1, :) = [];
colormap = parula(length(uu)*2);
[uu, chu, posi] = unique(va2(:, 3), 'sorted'); ss = colormap;

figure
for u = 1:length(uu)
    idx = find(posi == u);
    plot(va2(idx,1), va2(idx,2), 'o', 'markersize', 6, 'MarkerEdgeColor','k', 'MarkerFaceColor', ss(u*2, :)), hold on
end
ylabel('C fiber'), xlabel('\Delta MBI'), hold on, set(gca, 'fontsize', 14)
xlim([-0.01 1.01]); ylim([-0.01 1.01]);
h1 = plot(fittedX, feval(tilp, fittedX), 'color','k','linewidth', 1, 'linestyle',linest{1});
set(get(get(h1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
title(['RMSE = ' num2str(gofi.rmse) ])


%%
A = load('evalA'); B = load('evalB');
C = load('evalC');

A.corre = A.corre.^2;
B.corre = B.corre.^2;
C.corre = C.corre.^2;

A.Accur = 1-A.Accur;
B.Accur = 1-B.Accur;
C.Accur = 1-C.Accur;

figure, boxplot([A.Accur B.Accur C.Accur], [ones(1, length(A.Accur)) 2*ones(1, length(B.Accur)) 3*ones(1, length(C.Accur))]), hold on

plot(ones(1, length(A.Accur)), A.Accur, '.', 'markersize', 14), hold on
plot(2*ones(1, length(B.Accur)), B.Accur, '.', 'markersize', 14)
plot(3*ones(1, length(C.Accur)), C.Accur, '.', 'markersize', 14)

%     set(gca,'XTickLabels', {{'A vs EMG'; 'linear'},'b','c'});
ylim([0 1]), xticklabels({'A vs EMG', 'B vs HR', 'C vs LBI'})
set(gca, 'fontsize', 14)
ylabel('Accuracy')

%
figure, boxplot([A.corre B.corre C.corre], [ones(1, length(A.corre)) 2*ones(1, length(B.corre)) 3*ones(1, length(C.corre))]), hold on

plot(ones(1, length(A.corre)), A.corre, '.', 'markersize', 14), hold on
plot(2*ones(1, length(B.corre)), B.corre, '.', 'markersize', 14)
plot(3*ones(1, length(C.corre)), C.corre, '.', 'markersize', 14)

%     set(gca,'XTickLabels', {{'A vs EMG'; 'linear'},'b','c'});
ylim([0 1]), xticklabels({'A vs EMG', 'B vs HR', 'C vs LBI'})
set(gca, 'fontsize', 14)
ylabel('corr')


figure, boxplot([errorA errorB errorC11], [ones(1, length(AccurA)) 2*ones(1, length(AccurB)) 3*ones(1, length(AccurC11))]), hold on


%     set(gca,'XTickLabels', {{'A vs EMG'; 'linear'},'b','c'});
xticklabels({'A vs EMG', 'B vs HR', 'C vs LBI'})
set(gca, 'fontsize', 14)
ylabel('Accuracy')
