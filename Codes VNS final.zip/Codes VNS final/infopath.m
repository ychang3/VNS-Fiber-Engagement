pathfeins = 'C:\Users\Marina Cracchiolo\Dropbox (SSSUP)\Marina\Feinstein\';
pathfeins = 'E:\Feinstein\';

path_dati = [pathfeins 'dati\'];
excelfile = [ 'Exp_fibers_spec.xlsx' ];

