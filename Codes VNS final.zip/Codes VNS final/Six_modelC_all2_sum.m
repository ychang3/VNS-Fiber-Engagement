%% exponent fit
close all
clear all

pp  = pwd;

PATH = 'D:\TNP\Manuscript\Fiber Recruitment\DATA';
file = 'data_table_neural_physio';
load([PATH '\' file '.mat']);
% addpath([pp(1:end-34) '\codes'])
% pw_sel = 100; plotvar = 1; plotdiff  = 0;
% Ttot = table;
% [Aex, bex, cex] = xlsread([pp '\Exp_fibers_spec.xlsx'], num2str(pw_sel));
% bex = bex(2:end, :); cex = cex(2:end, :);
pos = 1; submean = 0;
TOT = table; cl = 1;
for i = 1:length(fold_tot)
    
%     [fold, rangeA, rangeB, rangeC, tmin1, tmin_1, estrB2, tEMG, discard, Cmin2max] = fun_extract_from_excel(Aex, bex,i);
%     
%     direc = [pp(1:end-34) '\dati\'];
%     experimentdir  = [direc fold];
%     load([experimentdir '\TBL_neu2.mat'])
    TBL_neu = table_exp{i};
    
    if i == 1    || i == 10
        continue
    elseif i == 7 || i == 10 || i == 11
        TBL_neu = TBL_neu(TBL_neu.pol == 1, :);
    else
    end
    
    %     TBL_neu = T;
    TB_clean = TBL_neu(TBL_neu.freq == 30 & TBL_neu.pw > 0 & TBL_neu.dur > 9 & TBL_neu.amp >= 1 & TBL_neu.amp < 10 & isnan(TBL_neu.FT), :);
    TB_clean.deltaHR = (TB_clean.HRpre-TB_clean.HRdur)./TB_clean.HRpre * 100;
    TB_clean(TB_clean.deltaHR < 0, :) = [];
    TB_clean.deltaINT = -(TB_clean.meanINTpre-TB_clean.meanInt0);
    
    TB_clean.amp = TB_clean.amp.*TB_clean.pw;
    TT = TB_clean(:, [1  33 30 39 36] );
    TT(isnan(TT.Cfiber), :) = [];
    
    mean_cate(cl) = 0;
    
    
    if submean
        mean_cate(cl) = mean(TT.Cfiber);
        TT.Cfiber = TT.Cfiber - mean(TT.Cfiber);
        
    end
    m = height(TT) ;
    if m == 0 ; continue; end
        TT.cla = ones(height(TT), 1)*i;
    classi(cl) = i;
    TT = [TT(:, 1:end-2) TT(:, end), TT(:, end-1)];
    TOT = [TOT; TT  ];
    
    cl = cl+1;
end

 M = containers.Map(classi, mean_cate');



%% model
plotvar = 0;
m = height(TOT);
P = 0.75 ;
K = 100;
F = 2;
for k = 1:K
    idx = randperm(m)  ;
    TOT.cla = categorical(TOT.cla);
    Training = TOT(idx(1:round(P*m)),:) ;
    Testing = TOT(idx(round(P*m)+1:end),:) ;
    
    % model on train set
    lm = fitlm(Training, 'purequadratic', 'CategoricalVar', {'cla'});
    Tres(:, k) = lm.Coefficients.Estimate.*(lm.Coefficients.pValue<=0.05);
    fitted = lm.Fitted;
    %     fitted(lm.Fitted<0) = 0;
    dist = diff([fitted Training.Cfiber], 1, 2);
    % dist_mean = diff([Training.Cfiber ones(length(Training.Cfiber), 1) * mean(Training.Cfiber)], 1, 2);
    RMSETR  = rms(dist);
    %     RsquTR = 1-sum( dist.^2) ./sum( dist_mean.^2 );
    RsquTR = (corrcoef(Training.Cfiber , fitted)); RsquTR = RsquTR(1, 2)^2;
    
    % validation set
    Ypre = predict(lm, (Testing(:, 1:end-1)) );
    
    dist = diff([Ypre Testing.Cfiber], 1, 2);
    %     dist_mean = diff([Testing.Cfiber ones(length(Testing.Cfiber), 1) * mean(Testing.Cfiber)], 1, 2);
    
    RMSEVAL  = rms(dist);
    %     RsquVAL = 1-sum( dist.^2) ./sum( dist_mean.^2 );
    RsquVAL = (corrcoef(Testing.Cfiber , Ypre)); RsquVAL = RsquVAL(1, 2)^2;
    
    if plotvar
        ax(k) = subplot(2,5,k);
        plot(Testing.Cfiber, Ypre , 'ko') % observed data
        title([num2str( lm.Rsquared.Ordinary) ' '  num2str(lm.RMSE)])
        xlabel('actual'), ylabel('predicted')
        cc = corrcoef(Testing.Cfiber,Ypre);
    end
    
    res(k, :) = [RsquTR RMSETR RsquVAL RMSEVAL];
    
end

R = array2table(Tres);
R.Properties.RowNames = lm.CoefficientNames';
% R(6:13,:) = [];

Rarr = table2array(R);
somma = sum((Rarr == 0), 2);
idx = somma>K/F;
Rarr(Rarr == 0 ) = NaN;
S = nanmedian(Rarr,  2);
S(idx) = 0;
interc = S(6:13);
S(6:13) = [];
interc2 = array2table(interc', 'VariableNames', lm.CoefficientNames(6:13));
M2 = containers.Map(classi, [0; interc]);


%% set Chance level

for rep = 1:100
    idx = randperm(m)  ;
    TOT.cla = categorical(TOT.cla);
    
    Testing = TOT(idx(round(P*m)+1:end),:) ;
    
    idx = randperm(m)  ;
    Testing.Cfiber = TOT.Cfiber(idx(round(P*m)+1:end)) ;
    
    clear to_add
    for j = 1: length(Testing.Cfiber)
        to_add(j, :) = [M( str2double(str2mat(Testing.cla(j)))) M2( str2double(str2mat(Testing.cla(j))))];
    end
    
    modello =  S(1).^ones(length(Testing.amp), 1) + S(2)*Testing.amp +  S(3)*Testing.EMG + ...
        S(4)*Testing.deltaHR +  S(5)*Testing.deltaINT +...
        S(6)*Testing.amp.^2 +S(7)*Testing.EMG.^2 +  ...
        S(8)*Testing.deltaHR.^2 + S(9)*Testing.deltaINT.^2;
    
    modello(modello<0) = 0;
    % modello = modello+ to_add(:, 2);
    
    dist = diff([modello Testing.Cfiber], 1, 2);
    %     dist_mean = diff([Testing.Cfiber ones(length(Testing.Cfiber), 1) * mean(Testing.Cfiber)], 1, 2);
    
    RMSE  = rms(dist);
    RMSETOT_CL(rep) = RMSE;
    
    % rsq = 1-sum( dist.^2) ./sum( dist_mean.^2 );
    rsq = (corrcoef(Testing.Cfiber , modello)); rsq = rsq(1, 2)^2;
    RSQTOT_CL(rep) = rsq;
    
end
%
figure, subplot(121),histfit(RMSETOT_CL, 20); hold on
sormse = sort(RMSETOT_CL);
CL_RMSE = sormse(length(sormse)/100*5+1);
line([CL_RMSE CL_RMSE], [0 12], 'color', 'r', 'linewidth', 2)
set(gca, 'fontsize', 14);
[pdca_RMSE] = fitdist(RMSETOT_CL', 'Normal');
title(['RMSE CL = ' num2str(CL_RMSE)], 'fontweight', 'normal')

subplot(122), histfit(RSQTOT_CL, 20, 'exponential'); hold on
sorrsq = sort(RSQTOT_CL);
CL_RSQ = sorrsq(length(sorrsq)/100*95-1);
line([CL_RSQ CL_RSQ], [0 20], 'color', 'r', 'linewidth', 2)
set(gca, 'fontsize', 14);
[pdca_RSQ] = fitdist(RSQTOT_CL', 'exponential');
title(['Rsquared CL = ' num2str(CL_RSQ)], 'fontweight', 'normal')

%% display results

% new dataset
for rep = 1:500
    idx = randperm(m)  ;
    TOT.cla = categorical(TOT.cla);
    
    Testing = TOT(idx(round(P*m)+1:end),:) ;
    
    clear to_add
    
    for j = 1: length(Testing.Cfiber)
        to_add(j, :) = [M( str2double(str2mat(Testing.cla(j)))) M2( str2double(str2mat(Testing.cla(j))))];
    end
    
    modello =  S(1).^ones(length(Testing.amp), 1) + S(2)*Testing.amp +  S(3)*Testing.EMG + ...
        S(4)*Testing.deltaHR +  S(5)*Testing.deltaINT +...
        S(6)*Testing.amp.^2 +S(7)*Testing.EMG.^2 +  ...
        S(8)*Testing.deltaHR.^2 + S(9)*Testing.deltaINT.^2;
    
    % modello = modello + to_add(:, 2) + to_add(:, 1);
    % Testing_fiber = Testing.Cfiber + to_add(:, 1);
    
    modello(modello<0) = 0;
    
    % without CL
    Testing_fiber = Testing.Cfiber;
    dist = diff([modello Testing_fiber], 1, 2);
    RMSE  = rms(dist);
    RMSETOT_wo(rep) = RMSE;
    rsq = (corrcoef(Testing_fiber , modello)); rsq = rsq(1, 2)^2;
    RSQTOT_wo(rep) = rsq;
    aa = [modello modello+to_add(:, 2) Testing.Cfiber];
    
    % with CL
    modello = modello + to_add(:, 2);
    dist = diff([modello Testing_fiber], 1, 2);
    RMSE  = rms(dist);
    RMSETOT_w(rep) = RMSE;
    rsq = (corrcoef(Testing_fiber , modello)); rsq = rsq(1, 2)^2;
    RSQTOT_w(rep) = rsq;
    
    %
    
    if rsq > 0.9
        
        figure, plot(Testing_fiber+ to_add(:, 1), modello+ to_add(:, 1), '.', 'markersize', 14)
        aa = [get(gca, 'xlim'); get(gca, 'ylim')];
        xlim([0 max(aa(:, 2))]);  ylim([0 max(aa(:, 2))]);
        hold on, line([0  max(aa(:, 2))], [0  max(aa(:, 2)) ])
        xlabel('actual'), ylabel('predicted')
        set(gca, 'fontsize', 14)
        title([num2str(rsq) ' ' num2str(RMSE)])
        
    end
end
%

RMSETOT = RMSETOT_wo;
RSQTOT = RSQTOT_wo;


figure, subplot(121); bar([median(res(:, 2)) median(res(:, 4)) median(RMSETOT)]), hold on
errorbar(1, median(res(:, 2)) , median(res(:, 2))-prctile(res(:, 2), 25), -median(res(:, 2))+prctile(res(:, 2), 75)); hold on
errorbar(2, median(res(:, 4)) , median(res(:, 4))-prctile(res(:, 4), 25), -median(res(:, 4))+prctile(res(:, 4), 75)); hold on
errorbar(3, median(RMSETOT) , median(RMSETOT)-prctile(RMSETOT, 25), -median(RMSETOT)+prctile(RMSETOT, 75)); hold on
title('RMSE')
xticks(1:3), xticklabels({'Train set', 'Val set', 'Test set'})
set(gca, 'fontsize', 14)
hold on, line([0 4], [CL_RMSE CL_RMSE], 'LineStyle', '--', 'linewidth', 2, 'color', 'k')

subplot(122); bar([median(res(:, 1)) median(res(:, 3)) median(RSQTOT)]), hold on
errorbar(1, median(res(:, 1)) , median(res(:, 1))-prctile(res(:, 1), 25), -median(res(:, 1))+prctile(res(:, 1), 75)); hold on
errorbar(2, median(res(:, 3)) , median(res(:, 3))-prctile(res(:, 3), 25), -median(res(:, 3))+prctile(res(:, 3), 75)); hold on
errorbar(3, median(RSQTOT) , median(RSQTOT)-prctile(RSQTOT, 25), -median(RSQTOT)+prctile(RSQTOT, 75)); hold on

title('Rsquared')
xticks(1:3), xticklabels({'Train set', 'Val set', 'Test set'})
set(gca, 'fontsize', 14); ylim([0 1])
hold on, line([0 4], [CL_RSQ  CL_RSQ], 'LineStyle', '--', 'linewidth', 2, 'color', 'k')

% figure, subplot(121); bar([mean(res(:, 2)) mean(res(:, 4)) mean(RMSETOT)]), hold on
% errorbar(1, mean(res(:, 2)) , std(res(:, 2))); hold on
% errorbar(2, mean(res(:, 4)) , std(res(:, 4))); hold on
% errorbar(3, mean(RMSETOT), std(RMSETOT));
% title('RMSE')
% xticks(1:3), xticklabels({'Train set', 'Val set', 'Test set'})
% set(gca, 'fontsize', 14)
% hold on, line([0 4], [CL_RMSE CL_RMSE], 'LineStyle', '--', 'linewidth', 2, 'color', 'k')
% subplot(122); bar([mean(res(:, 1)) mean(res(:, 3)) mean(RSQTOT)]), hold on
% errorbar(1, mean(res(:, 1)) , std(res(:, 1))); hold on
% errorbar(2, mean(res(:, 3)) , std(res(:, 3))); hold on
% errorbar(3, mean(RSQTOT), std(RSQTOT));
% title('Rsquared')
% xticks(1:3), xticklabels({'Train set', 'Val set', 'Test set'})
% set(gca, 'fontsize', 14); ylim([0 1])
% hold on, line([0 4], [CL_RSQ  CL_RSQ], 'LineStyle', '--', 'linewidth', 2, 'color', 'k')
