function[ ] = fun_figure2(neu, curve, Tselo, rangeA, rangeB, rangeC,  plotvar, neu2)

pw = Tselo.pw(1);

tv = (0:length(neu.avg_CAP(:, 1))-1)/30-1;

% EMG



%% plot

if plotvar
    g1 = figure;
    ii = 1;
        subplot(121),
        plot(tv, neu.avg_CAP(:, ii), 'linewidth', 1);  hold on
     
    set(gca, 'Fontsize', 16)
    xlabel('time (ms)'), ylabel('Thresh. x')
    
    xlim([-1.05 20.1])
    line([pw pw]/1000, get(gca, 'ylim'), 'color', 'k')
    line([0 0 ], get(gca, 'ylim'), 'color', 'k')
    patch('YData',[get(gca, 'ylim') fliplr(get(gca, 'ylim'))],'XData',[rangeA(1) rangeA(1) rangeA(2) rangeA(2)  ],'FaceAlpha',0.3,'LineStyle','none',...
        'FaceColor',[1 0.3 0.3]);
    patch('YData',[get(gca, 'ylim') fliplr(get(gca, 'ylim'))],'XData',[rangeB(1) rangeB(1) rangeB(2) rangeB(2)  ],'FaceAlpha',0.3,'LineStyle','none',...
        'FaceColor',[0.5 1 0.5]);
    patch('YData',[get(gca, 'ylim') fliplr(get(gca, 'ylim'))],'XData',[rangeC(1) rangeC(1) rangeC(2) rangeC(2)  ],'FaceAlpha',0.3,'LineStyle','none',...
        'FaceColor',[1 1 0.5]);
    
%         subplot(185),
%         yl = [300 400];
%         patch('YData',[yl fliplr(yl)],'XData',[0 0 10 10  ],'FaceAlpha',0.3,'LineStyle','none',...
%             'FaceColor',[238 230 255]/255); hold on
%         
%         subplot(186), yl = [0 2];
%         patch('YData',[yl fliplr(yl)],'XData',[0 0 10 10  ],'FaceAlpha',0.3,'LineStyle','none',...
%             'FaceColor',[238 230 255]/255), hold on
%         
%         subplot(187), yl = [0 200];
%         patch('YData',[yl fliplr(yl)],'XData',[0 0 10 10  ],'FaceAlpha',0.3,'LineStyle','none',...
%             'FaceColor',[238 230 255]/255), hold on
     
end


   i = 1;
        c = curve{i};
        
            
            subplot(165),   yyaxis right, plot(c.ecg_breath(:, 1), c.ecg_breath(:, 2), 'k', 'linewidth', 1); hold on, xlim([-10 20])
            yyaxis left,  plot(c.hr(:, 1), hampel(c.hr(:, 2)), 'k', 'linewidth', 1); hold on, xlim([-10 20])
            title('heart rate', 'fontweight', 'normal'), set(gca, 'fontsize', 14), xlabel('Time (sec)')
            
            subplot(166), yyaxis right, plot(c.ecg_breath(:, 1), c.ecg_breath(:, 3),'k', 'linewidth', 1); hold on, xlim([-10 20])
            yyaxis left,  plot(c.br(:, 1), c.br(:, 2), 'k');  hold on,
            title('nasal sensor', 'fontweight', 'normal'), set(gca, 'fontsize', 14),  xlabel('Time (sec)')
            
        


%% if you have second channel, run this part of the code
if isstruct(neu2)
    if plotvar
   ii = 1;
        subplot(121), plot(tv, neu2.avg_CAP(:, ii), '--', 'linewidth', 1);  hold on
    end
    
    iix = find(tv>rangeB(2) & tv < rangeC(1));   
    subplot(164), plot(tv(iix), neu.avg_CAP(iix, ii), '-', 'linewidth', 1);  hold on
    plot(tv(iix), neu2.avg_CAP(iix, ii), '--', 'linewidth', 1);  hold on


end

