close all
clear all

pp  = pwd;
interc = 0;

PATH = 'D:\TNP\Manuscript\Fiber Recruitment\DATA';
file = 'data_table_neural_physio';
load([PATH '\' file '.mat']);
% addpath([pp(1:end-34) '\codes'])
% pw_sel = 100; plotvar = 1; plotdiff  = 0;
% Ttot = table;
% [Aex, bex, cex] = xlsread([pp '\Exp_fibers_spec.xlsx'], num2str(pw_sel));
% bex = bex(2:end, :); cex = cex(2:end, :);
TOT = table;
fiber = 'C'; ff= 1;
norm_prima = 1;
norm_dopo = 0;
norm_meta = 0;
ca = {'EMG', 'deltaHR', 'deltaINT'};

for i = 1:length(fold_tot)
    %     if i == 9
    %         continue
    %     end
        
    try
%         [fold, rangeA, rangeB, rangeC, tmin1, tmin_1, estrB2, tEMG, discard, Cmin2max] = fun_extract_from_excel(Aex, bex,i);
%         direc = [pp(1:end-34) '\dati\'];
%         experimentdir  = [direc fold];
%         load([experimentdir '\TBL_neu2.mat'])
        TBL_neu = table_exp{i};
        
        MAXEMG = mean(TBL_neu.EMG(TBL_neu.pw>=500 & TBL_neu.pw<=600  & TBL_neu.amp >= 6 & TBL_neu.amp <=8 & isnan(TBL_neu.FT)));
        
        if i == 11 && strcmp(fiber, 'A'); TBL_neu(TBL_neu.Afiber > 80, :) = []; end 
        if i == 8 && strcmp(fiber, 'B'); TBL_neu(TBL_neu.Bfiber > 80, :) = []; end
        
        TBL_neu.deltaHR = (TBL_neu.HRpre-TBL_neu.HRdur)./TBL_neu.HRpre * 100;
        TBL_neu.deltaHR(TBL_neu.deltaHR < 0) = 0;
        TBL_neu.deltaINT = -(TBL_neu.meanINTpre-TBL_neu.meanInt0);
        
        
        figure;subplot(221),hist(TBL_neu.(ca{ff})), 
        subplot(223), hist(TBL_neu.([fiber 'fiber']))
        
        if norm_prima
            maxF = sort(TBL_neu.([fiber 'fiber']));
            maxF(isnan(maxF)) = []; maxF = nanmean(unique(maxF(end-5:end-1)));
            maxF_tot(i) = maxF;
            TBL_neu.([fiber 'fiber']) = TBL_neu.([fiber 'fiber'])./maxF;
        end
        
        maxcomp(:, i) = [maxF; max(TBL_neu.deltaHR)];

        [out, TBL_neu, MAXEMG] = criteria_fibers(fiber, TBL_neu, i, MAXEMG);
        if out ==1
            continue
        end
        
        TBL_neu.EMG = TBL_neu.EMG/MAXEMG;
        MAXEMG_tot(i) = MAXEMG;
        
        TB_clean = TBL_neu(TBL_neu.freq == 30 & TBL_neu.pw > 0 & TBL_neu.dur > 9 & TBL_neu.amp >= 1 & TBL_neu.amp < 10 & isnan(TBL_neu.FT), :);       
        TB_clean.amp = TB_clean.amp.*TB_clean.pw;
        
        
        switch fiber
            case 'A'
                TT = TB_clean(:, [1  33 30 39 34] );
                
            case 'B'
                TT = TB_clean(:, [1  33 30 39 35] );
            case 'C'
                TT = TB_clean(:, [1  33 30 39 36] );
        end
        TT.Properties.VariableNames([end]) = {'Fiber'};
        %         subplot(122), scatter(TT.deltaINT(TB_clean.pol == 1),TT.Fiber(TB_clean.pol == 1));
        %         hold on, scatter(TT.deltaINT(TB_clean.pol == -1),TT.Fiber(TB_clean.pol == -1));
        subplot(122), scatter(TT.(ca{ff})(TB_clean.pol == 1),TT.Fiber(TB_clean.pol == 1));
        hold on, scatter(TT.(ca{ff})(TB_clean.pol == -1),TT.Fiber(TB_clean.pol == -1));
        title(['r: ' num2str(i)])
        
        TT(isnan(TT.Fiber), :) = [];
        
        m = height(TT) ;
        if m == 0 ; continue; end
        TT.cla = ones(height(TT), 1)*i;
        TOT = [TOT; TT  ];
        
    catch
    end
end

TOT.deltaINT(TOT.deltaINT < 0) = 0;

%% model animal-wise
cl = unique(TOT.cla);
for col = 1:width(TOT)
    TOT.(TOT.Properties.VariableNames{col})(isnan(TOT.(TOT.Properties.VariableNames{col}))) = 0;
end
clear CL_RMSE_tot CL_R2_tot S_tot Train_R2_tot Train_RMSE_tot Test_RMSE_tot Test_R2_tot data_tot
data_tot =  [];

figure
i = 1;
for ani = 1:length(cl)
    anim = cl(ani);
    Test = TOT(TOT.cla == anim, 1:end-1);
    Training_dev = TOT(TOT.cla ~= anim, 1:end-1);
    if height(Test)<10
        continue
    end
    
    P = 0.75; K = 100; F = 2;
    [Train_R2,Train_RMSE, S] = fun_train_model(Training_dev, P, K, F, interc);
    Train_R2_tot(i) = median(Train_R2);
    Train_RMSE_tot(i) = median(Train_RMSE);
    S_tot(:, i) = S;
    % set Chance level
    ifplot= 1; R = 100;
    [CL_R2, CL_RMSE] = fun_set_chanceLevel(S, Training_dev,R, ifplot);
    
    CL_RMSE_tot(i) = CL_RMSE;
    CL_R2_tot(i) = CL_R2;
    
    % test model new animal
%     subplot(2, 5, i)
    ifplot = 0;
    [modello, rsq_test, RMSE_test] = fun_test_model(Test,S, ifplot);
    ylabel(['Predicted R: ' num2str(cl(i))]);
    Test_RMSE_tot(i) = RMSE_test;
    Test_R2_tot(i) = rsq_test;
    
    data_tot = [data_tot; Test.Fiber modello];
    i = i+1;
end

%%
figure, subplot(121); bar([median(Train_R2_tot) median(Test_R2_tot)]), hold on
errorbar(1, median(Train_R2_tot) , median(Train_R2_tot)-prctile(Train_R2_tot, 25), -median(Train_R2_tot)+prctile(Train_R2_tot, 75)); hold on
errorbar(2, median(Test_R2_tot) , median(Test_R2_tot)-prctile(Test_R2_tot, 25), -median(Test_R2_tot)+prctile(Test_R2_tot, 75)); hold on
title('R^2')
% xticks(1:2), xticklabels({'Train set',  'Test set'})
set(gca, 'fontsize', 14)
hold on, line([0 3], [median(CL_R2_tot) median( CL_R2_tot) ], 'LineStyle', '--', 'linewidth', 2, 'color', 'k')

subplot(122); bar([median(Train_RMSE_tot) median(Test_RMSE_tot)]), hold on
errorbar(1, median(Train_RMSE_tot) , median(Train_RMSE_tot)-prctile(Train_RMSE_tot, 25), -median(Train_RMSE_tot)+prctile(Train_RMSE_tot, 75)); hold on
errorbar(2, median(Test_RMSE_tot) , median(Test_RMSE_tot)-prctile(Test_RMSE_tot, 25), -median(Test_RMSE_tot)+prctile(Test_RMSE_tot, 75)); hold on
title('RMSE')
% xticks(1:2), xticklabels({'Train set',  'Test set'})
set(gca, 'fontsize', 14)
hold on, line([0 3], [median(CL_RMSE_tot/100) median( CL_RMSE_tot/100) ], 'LineStyle', '--', 'linewidth', 2, 'color', 'k')


%%

figure, plot(data_tot(:, 1), data_tot(:, 2), '.', 'markersize', 14)
aa = [get(gca, 'xlim'); get(gca, 'ylim')];
xlim([0 max(aa(:, 2))]);  ylim([0 max(aa(:, 2))]);
hold on, line([0  max(aa(:, 2))], [0  max(aa(:, 2)) ])
xlabel('actual'), ylabel('predicted')
set(gca, 'fontsize', 14)

somma = sum((S_tot == 0), 2);
idx = somma>length(cl)/F;
S_tot(S_tot == 0 ) = NaN;
S = nanmedian(S_tot,  2);
S(idx) = 0;

% S = S*100;
% data_tot = [];
% cl = unique(TOT.cla);
% for i = 1:length(cl)
%     anim = cl(i);
%     Test = TOT(TOT.cla == anim, 1:end-1);
%
%     %% test model new animal
%     [modello, rsq_test, RMSE_test] = fun_test_model(Test,S, ifplot);
%     Test_RMSE_tot(i) = RMSE_test;
%     Test_R2_tot(i) = rsq_test;
%
%     data_tot = [data_tot; Test.Fiber modello];
%
% end
%
% figure, subplot(121); bar([median(Train_R2_tot) median(Test_R2_tot)]), hold on
% errorbar(1, median(Train_R2_tot) , median(Train_R2_tot)-prctile(Train_R2_tot, 25), -median(Train_R2_tot)+prctile(Train_R2_tot, 75)); hold on
% errorbar(2, median(Test_R2_tot) , median(Test_R2_tot)-prctile(Test_R2_tot, 25), -median(Test_R2_tot)+prctile(Test_R2_tot, 75)); hold on
% title('R^2')
% xticks(1:2), xticklabels({'Train set',  'Test set'})
% set(gca, 'fontsize', 14)
% hold on, line([0 4], [median(CL_R2_tot) median( CL_R2_tot) ], 'LineStyle', '--', 'linewidth', 2, 'color', 'k')
%
% subplot(122); bar([median(Train_RMSE_tot) median(Test_RMSE_tot)]), hold on
% errorbar(1, median(Train_RMSE_tot) , median(Train_RMSE_tot)-prctile(Train_RMSE_tot, 25), -median(Train_RMSE_tot)+prctile(Train_RMSE_tot, 75)); hold on
% errorbar(2, median(Test_RMSE_tot) , median(Test_RMSE_tot)-prctile(Test_RMSE_tot, 25), -median(Test_RMSE_tot)+prctile(Test_RMSE_tot, 75)); hold on
% title('RMSE')
% xticks(1:2), xticklabels({'Train set',  'Test set'})
% set(gca, 'fontsize', 14)
% hold on, line([0 4], [median(CL_RMSE_tot) median( CL_RMSE_tot) ], 'LineStyle', '--', 'linewidth', 2, 'color', 'k')
%

%         subplot(223),
%         TBL_sub = TBL_neu(TBL_neu.freq == 30 & TBL_neu.pw > 0 & TBL_neu.dur > 9 & TBL_neu.amp >= 1 & TBL_neu.amp < 10 & isnan(TBL_neu.FT), :);
%         scatter(TBL_sub.EMG(TBL_sub.pol == 1),TBL_sub.Afiber(TBL_sub.pol == 1))
%         hold on;scatter(TBL_sub.EMG(TBL_sub.pol == -1),TBL_sub.Afiber(TBL_sub.pol == -1))

%         TB_clean.deltaHR = (TB_clean.HRpre-TB_clean.HRdur)./TB_clean.HRpre * 100;
%         TB_clean.deltaHR(TB_clean.deltaHR < 0) = 0;
%         TB_clean.deltaINT = -(TB_clean.meanINTpre-TB_clean.meanInt0);
        
% %% std
%
% figure, subplot(121); bar([mean(Train_R2_tot) mean(Test_R2_tot)]), hold on
% errorbar(1, mean(Train_R2_tot) , std(Train_R2_tot)); hold on
% errorbar(2, mean(Test_R2_tot) , std(Test_R2_tot)); hold on
% title('R^2')
% xticks(1:2), xticklabels({'Train set',  'Test set'})
% set(gca, 'fontsize', 14)
% hold on, line([0 4], [mean(CL_R2_tot) mean( CL_R2_tot) ], 'LineStyle', '--', 'linewidth', 2, 'color', 'k')
%
% subplot(122); bar([mean(Train_RMSE_tot) mean(Test_RMSE_tot)]), hold on
% errorbar(1, mean(Train_RMSE_tot) , std(Train_RMSE_tot)); hold on
% errorbar(2, mean(Test_RMSE_tot) , std(Test_RMSE_tot)); hold on
% title('RMSE')
% xticks(1:2), xticklabels({'Train set',  'Test set'})
% set(gca, 'fontsize', 14)
% hold on, line([0 4], [mean(CL_RMSE_tot) mean( CL_RMSE_tot) ], 'LineStyle', '--', 'linewidth', 2, 'color', 'k')
