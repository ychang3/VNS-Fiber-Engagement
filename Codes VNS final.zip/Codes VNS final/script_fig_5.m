clear
close all

load Table_data_A_C_LBI.mat
expid = T.ExpID;
fb_a = T.Afiber;
fb_c = T.Cfiber;
lbi = T.LBI;
resp = T.Apnea0_Bradypn1;


apnea = [fb_a(resp==0) fb_c(resp==0)];
bradypnea = [fb_a(resp==1 & lbi>0.2) fb_c(resp==1 & lbi>0.2)];
nochanges = [fb_a(resp==1 & lbi<=0.2) fb_c(resp==1 & lbi<=0.2)];


figure
plot((apnea(:, 1)), (apnea(:, 2)),'o','MarkerSize',5,'Color','r'), hold on
plot((bradypnea(:, 1)), (bradypnea(:, 2)),'o','MarkerSize',5,'Color','b'), hold on
plot((nochanges(:, 1)), (nochanges(:, 2)),'o','MarkerSize',5,'Color','g'), hold on

plot(mean(apnea(:, 1)), mean(apnea(:, 2)),'o','MarkerSize',20,'Color','r'), hold on
plot(mean(bradypnea(:, 1)), mean(bradypnea(:, 2)),'o','MarkerSize',20,'Color','b'), hold on
plot(mean(nochanges(:, 1)), mean(nochanges(:, 2)),'o','MarkerSize',20,'Color','g'), hold on


xlim([-0.05 1.05])
ylim([-0.05 1.05])


%%%%%%%%%%


%% test on A and C
n = 1;
lab = ones(size(apnea(:, 1)));
[~, ~, stats] = anova1([apnea(:, n); bradypnea(:, n); nochanges(:, n)],...
    [ones(length(apnea(:, n)), 1); 2*ones(length(bradypnea(:, n)), 1); 3*ones(length(nochanges(:, n)), 1)], 'on') ; 
figure, boxplot([apnea(:, n); bradypnea(:, n); nochanges(:, n)],...
    [ones(length(apnea(:, n)), 1); 2*ones(length(bradypnea(:, n)), 1); 3*ones(length(nochanges(:, n)), 1)]), hold on

compareA = multcompare(stats);

n = 2;
[~, ~, stats] = anova1([apnea(:, n); bradypnea(:, n); nochanges(:, n)],...
    [ones(length(apnea(:, n)), 1); 2*ones(length(bradypnea(:, n)), 1); 3*ones(length(nochanges(:, n)), 1)], 'on') ; 
figure, boxplot([apnea(:, n); bradypnea(:, n); nochanges(:, n)],...
    [ones(length(apnea(:, n)), 1); 2*ones(length(bradypnea(:, n)), 1); 3*ones(length(nochanges(:, n)), 1)]), hold on
compareC = multcompare(stats);


% %% %%%%%%
% gc = makeColorMap([0 1 1],[0 0 1],sum(resp));
% lbi_sort = sort(lbi(resp==1));
% for i=1:length(expid)
%     x(i) = fb_a(i);
%     y(i) = fb_c(i);
%     if resp(i)==0
%         c(i,:) = [1 0 0]';
%     else
%         [~,idx]=min(abs(lbi(i)-lbi_sort));
%         c(i,:) = gc(idx,:);
%     end
% end
% 
% figure
% for i=1:length(x)
%     plot(x(i),y(i),'o','MarkerSize',5,'LineWidth',2,'Color',c(i,:))
%     hold on
% end
% 
% xlim([-0.1 1.1])
% ylim([-0.1 1.1])
% 
% %% 3groups: apena, bradypnea, no effect
% 
% apnea = [fb_a(resp==0) fb_c(resp==0)];
% bradypnea = [fb_a(resp==1 & lbi>0.2) fb_c(resp==1 & lbi>0.2)];
% nochanges = [fb_a(resp==1 & lbi<=0.2) fb_c(resp==1 & lbi<=0.2)];
% 
% 
% % med_apnea_a = mean(fb_a(resp==0));
% % med_apnea_c = mean(fb_c(resp==0));
% % med_brady_a = mean(fb_a(resp==1 & lbi>0.2));
% % med_brady_c = mean(fb_c(resp==1 & lbi>0.2));
% % med_noresp_a = mean(fb_a(abs(lbi)<=0.2));
% % med_noresp_c = mean(fb_c(abs(lbi)<=0.2));
% 
% plot(mean(apnea(:, 1)), mean(apnea(:, 2)),'*','MarkerSize',50,'Color',[1 0 0])
% plot(mean(bradypnea(:, 1)), mean(bradypnea(:, 2)),'*','MarkerSize',50,'Color',[0 0 1])
% plot(mean(nochanges(:, 1)), mean(nochanges(:, 2)),'*','MarkerSize',50,'Color',[0 1 1])
