function t = timestr2sec(str)

if str(end) == 's'
    t = str2double(str(1:end-1));
else    
    temp = cellfun(@(x) str2double(x), strsplit(str, ':'));
    if length(temp) == 2
        temp = [0 temp];    
    end
    t = sum(temp.*[3600 60 1]);
end