function [hut] = adjust_polarity(hut, experimentdir)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here

Dcsv = dir(sprintf('%s\\*.csv', experimentdir));
% [keyset, polar] = WaveformParamsPolarity([experimentdir '\' Dcsv.name]);
[keyset, polar, FT, condit] = WaveformParamsPolarity([experimentdir '\' Dcsv.name]);
n = 1;
for i = 1:length(keyset)
    
    for j = n:length(hut.trains{1,1})
        
        if strcmp(hut.trains{1,1}(1,j).repset, keyset{i})
            
            hut.trains{1,1}(1,j).pol = polar(i);
             hut.trains{1,1}(1,j).FT = FT(i);
              hut.trains{1,1}(1,j).condit = condit(i);  
            n = j+1;
            
            break
            
        end
        
    end

end

