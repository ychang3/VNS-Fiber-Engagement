function getDistbwCufs(foldername)
% folder name is a string
    tableDir = 'F:\UT_project_VagusStim\Data';
    tablefname = 'UTPH_rat_log_v2.xlsx';
    opts = detectImportOptions(fullfile(tableDir,tablefname));
    utTable = readtable(fullfile(tableDir,tablefname),opts);
    
    fnames = utTable.FolderName;
    IndexC = strfind(C, 'bla');
    Index = find(not(cellfun('isempty', IndexC)));
    
    dist = utTable.DistanceB_wCuffs_mm_;
    
end