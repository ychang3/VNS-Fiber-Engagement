function features = extractNeuralFeatures(data, hut, ikey, if_plot)
% Extracts neural features from peripheral cuff recordings

%% Define Constants
kstdevs = 6;
markersz = 50;

%% Initialize some variables
sr = 30000;
n1 = 300;
n2 = 900;

[nsamples, nsignals] = size(data);
t = ((0:length(data)-1) - n1)/sr * 1000;
pw = hut.wparams.params(ikey).pulsewidth_us/1000;

preStimInds = (1:n1);
postStimInds = (find(t>pw,1,'first'):nsamples);

assert(n1+n2 == nsamples, 'Incorrect number of samples')

%% Main function body
features = [];
for iisignal = 1:nsignals
    %% Establish a baseline for peak detection
    iibaseline = data(preStimInds,iisignal);
    iiy = data(postStimInds,iisignal);
    iit = t(postStimInds);
    threshold = kstdevs*std(iibaseline(1:end-100));
   
    if if_plot
%     figure; hold on
%     plot(t,data(:,iisignal),'k')
    end
    %     plot(t(preStimInds),iibaseline,'b')
    %     plot(t(preStimInds),threshold*ones(size(iibaseline)))
    
    %% Detect peaks
    [pkamps,pktimes,pkwidths,pkproms] = findpeaks(iiy,iit,'MinPeakProminence',threshold);
    if if_plot
    figure, findpeaks(iiy,iit,'MinPeakProminence',threshold);
    end
    %% Detect area under peak (using prominence)
    % Identify the bounds for integration -- find the nearest subthreshold
    % minima that neighbor the peak
    pkarea = [];
    lbound = [];
    rbound = [];
    remInd = [];
    for iipk = 1:length(pktimes)
        iiamp = pkamps(iipk);
        iitime = pktimes(iipk);
        iiprom = pkproms(iipk);
        
        t0ind = find(t>= iitime,1,'first');
        if iipk<length(pktimes)
            trind = find(t>=pktimes(iipk+1),1,'first');
        else
            trind = length(t);
        end
        
        if iipk>1
            tlind = find(t>=pktimes(iipk-1),1,'first');
        else
            tlind = find(t>= pw,1,'first');
        end
        
        tleft = (t0ind:-1:tlind);
        tright = (t0ind:1:trind);
        yleft = -(data(tleft,iisignal)-data(tleft(1)));
        yright = -(data(tright,iisignal)-data(tleft(1)));
        
        % TODO: consider using iiprom instead of threshold
        warning('off','all')
        ylpks = [];
        modl = 1;
        while isempty(ylpks)
            [~,ylpks]=findpeaks(yleft,'MinPeakHeight',iiprom*modl);
            modl = modl-.05;
            if modl <= 0
                break
            end
        end
        yrpks = [];
        mod2 = 1;
        while isempty(yrpks)
            [~,yrpks]=findpeaks(yright,'MinPeakHeight',iiprom*mod2);
            mod2 = mod2-.05;
            if mod2 <= 0
                break
            end
        end
        warning('on','all')
        
        if isempty(ylpks) && max(yleft)==yleft(end)
            ylpks = length(yleft);
        end
        if isempty(yrpks) && max(yright)==yright(end)
            yrpks = length(yright);
        end
        
        if isempty(ylpks) || isempty(yrpks) %failure to find side limits -- removal due to unlikely to be a real peak
            % Return to time indices
            lbound(iipk) = NaN;
            rbound(iipk) = NaN;
            pkarea(iipk) = NaN;
            remInd(end+1) = iipk;
        else
            % Return to time indices
            lbound(iipk) = tleft(ylpks(1));
            rbound(iipk) = tright(yrpks(1));
            
            % lbound = tleft(find(yleft<iiamp-iiprom,1,'first'));
            % rbound = tright(find(yright<iiamp-iiprom,1,'first'));
            
            pkarea(iipk) = sum(data(lbound(iipk):rbound(iipk),iisignal));
        end
    end
    
%     for irem = fliplr(iipk)
%         pktimes(irem) = [];
%         pkamps(irem) = [];
%         pkwidths(irem) = [];
%         pkproms(irem) = [];
%         pkarea(irem) = [];
%         lbound(irem) = [];
%         rbound(irem) = [];
%     end
    
    %% Plot the found data
    if if_plot
        hold on, scatter(pktimes,pkamps,markersz,'ro','LineWidth',2);
        hold on, scatter(t(lbound),data(lbound,iisignal),markersz,'bx','LineWidth',2)
        hold on, scatter(t(rbound),data(rbound,iisignal),markersz,'bx','LineWidth',2)
        title(ikey)
    end
    %% Output peaks
    features{iisignal}.pktimes = pktimes';
    features{iisignal}.pkamps = pkamps;
    features{iisignal}.pkwidths = pkwidths';
    features{iisignal}.pkproms = pkproms;
    features{iisignal}.pkarea = pkarea';
    features{iisignal}.lbound = lbound';
    features{iisignal}.rbound = rbound';
end
end