function dist = getDistbwCuffs(filename)
% TODO: Change this to an importExperParams function that pulls in more
% stuff from the file.

[~,expname,~]=fileparts(filename);
% folder name is a string
    tableDir = 'F:\UT_project_VagusStim\Data';
    tablefname = 'UTPH_rat_log_v2.xlsx';
    opts = detectImportOptions(fullfile(tableDir,tablefname));
    utTable = readtable(fullfile(tableDir,tablefname),opts);
    
    fnames = utTable.FolderName;
    %IndexC = strfind(C, 'bla');
    %IndexC = find(not(cellfun('isempty', IndexC)));
    tabInd = find(contains(fnames,expname));
    
    dist = utTable.DistanceB_wCuffs_mm_(tabInd);
end