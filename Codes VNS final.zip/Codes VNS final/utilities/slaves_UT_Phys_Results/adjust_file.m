if strcmp(namefile,  '2018-05-24-u-1')
        res.results(65:end) = [];
    end
    
    if strcmp(namefile,  '2018-05-03-u-1')
        res.results(end) = [];
    end
    
    if strcmp(namefile,  '2018-05-04-u-1')
        res.results(19) = [];
    end
    
    if strcmp(namefile,  '2018-05-14-u-1')
        res.results(9) = [];
        res.results(end) = [];
    end
    
    if strcmp(namefile,  '2018-05-11-u-1')
        res.results(10) = [];
    end
    
    if strcmp(namefile,  '2018-05-21-u-1')
        res.results(end) = [];
    end
    
    
    if strcmp(namefile,  '2018-05-22-u-1')
        res.results(67:68) = [];
        res.results(end) = [];
    end
    
    if strcmp(namefile,  '2018-07-12-j-1')
        res.results(66:67) = [];
    end
    
    if strcmp(namefile,  '2018-08-02-u-1')
        res.results(57) = [];
    end
    
    
    if strcmp(namefile,  '2018-08-03-u-1')
        res.results(82:83) = [];
    end
    
    if strcmp(namefile,  '2018-05-24-u-1')
        res.results([23 25]) = [];
    end
    
    if strcmp(namefile,  '2018-06-08-u-1')
        res.results([59 60 ]) = [];
    end
    
    
    if strcmp(namefile,  '2018-06-11-j-1')
        res.results([77 ]) = [];
    end
    if strcmp(namefile,  '2018-06-11-j-2')
        res.results([7 ]) = [];
    end
    
    if strcmp(namefile,  '2018-06-11-u-1')
        res.results([55 56 ]) = [];
    end
    
    if strcmp(namefile,  '2018-06-13-u-1')
        res.results([33 34 ]) = [];
    end
    
    if strcmp(namefile,  '2018-06-14-u-1')
        res.results([67 68 ]) = [];
    end
    
    
    STOP = 0;
    if (no_ampl && length(res.paramstim.amp)>1); STOP = 1; end
    if (solose_ampl && length(res.paramstim.amp)<2); STOP = 1; end
    if (only_pw && length(res.paramstim.pw)<4); STOP = 1; end
    if (Hfreq && max(res.paramstim.freq) < 5); STOP = 1; end
    if (length(res.paramstim.polarity) < 2); STOP = 1 ; end
