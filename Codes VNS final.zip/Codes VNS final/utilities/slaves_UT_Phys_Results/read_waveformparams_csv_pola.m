function raw = read_waveformparams_csv_pola(filename, delim)
            fid = fopen(filename, 'r');
            hcleanup = onCleanup(@() fclose(fid));
            raw = [];
            while ~feof(fid)
                myline = fgetl(fid);
                splitline = strsplit(myline, [delim '(?=(?:[^"]*"[^"]*")*[^"]*$)'], 'DelimiterType', 'RegularExpression', 'CollapseDelimiters', false);
                % splitline = strsplit(myline, delim, 'CollapseDelimiters', false);
                if ~isempty(raw)
                    assert(length(splitline) == size(raw, 2), ...
                        '%s and %s in csv file are inconsistent', ...
                        strjoin(raw(end, :), ', '), strjoin(splitline, ', '));
                end
                raw = [raw; splitline];
            end
end