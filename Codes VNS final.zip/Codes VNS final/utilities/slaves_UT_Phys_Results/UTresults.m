% UTresults

classdef UTresults
    properties
        results
        res_mdl
        map_idx
        states
        paramstim
        all_res_pola
    end
    methods
        function obj = UTresults(res, res_mdl)
            if nargin > 0
                obj.results = res;
            end
            if nargin > 1
                obj.res_mdl = res_mdl;
            end
        end
        
        %% check if some during interval is empty
        function obj = check_empty_interval_BR(obj, modo)
            idx=find(cellfun(@isempty, {obj.results.BR_during} ));
            if ~isempty(idx)
                switch modo
                    case 'NaN'
                        for ii = 1:length(idx)
                            obj.results(idx(ii)).BR_during = NaN;
                        end
                    case 'delete'
                        obj.results(idx) = [];
                        
                    case 'zeros'
                        for ii = 1:length(idx)
                            obj.results(idx(ii)).BR_during = 0;
                        end
                end
            end
        end
        
        function obj = check_empty_interval_HR(obj, modo)
            idx=find(cellfun(@isempty, {obj.results.HR_during} ));
            if ~isempty(idx)
                switch modo
                    case 'NaN'
                        for ii = 1:length(idx)
                            obj.results(idx(ii)).HR_during = NaN;
                        end
                    case 'delete'
                        obj.results(idx) = [];
                        
                    case 'zeros'
                        for ii = 1:length(idx)
                            obj.results(idx(ii)).HR_during = 0;
                        end
                        
                end
            end
        end
        
        
        %% compute weighted mean over pre during and post for HR and BR .
        %  the weight is the deltaT between the mean value of previous and
        %  the following stimulaon. Compute the weightened sum and then
        %  devide per the duration of the entire iinterval
        
        
        function obj = compute_mean(obj, how, n, when)
            
            resTot = obj. results;
            %% n = in seconds; compute mean from n sec till end
            for i = 1:numel(resTot)
                res = resTot(i);
                
                whmHR = [mean(res.HR_pre(2:end-1)) ...
                    mean(res.HR_during)...
                    mean(res.HR_post(2:end-1))];
                
                
                whmBR = [mean(res.BR_pre(2:end-1)) ...
                    mean(res.BR_during)...
                    mean(res.BR_post(2:end-1))];
                
                obj.results(i).resultHR = whmHR;
                obj.results(i).resultBR = whmBR;
            end
        end
        
        function obj = compute_numbBreath(obj)
            
            resTot = obj. results;
            %% n = in seconds; compute mean from n sec till end
            for i = 1:numel(resTot)
                res = resTot(i);
                L = res.numpulses./res.freq;
                whmBR = [length(res.BR_pre)/5 ...
                    length(res.BR_during)./L ...
                    length(res.BR_post)/5];
                obj.results(i).resultNR = whmBR;
            end
        end
        
        %         function obj = compute_mean(obj, how, n, when)
        %
        %             resTot = obj. results;
        %             if ~exist('n', 'var')
        %                 n = 0;
        %             end
        %
        %             if ~exist('when', 'var')
        %                 when = 'last';
        %             end
        %
        %             switch how
        %
        %                 case 'weight'
        %                     %% simple visualization of parameters pre during and post stimulation
        %
        %                     for i = 1:numel(resTot)
        %                         res = resTot(i);
        %                         % Time
        %                         THR = [res.HR_preT res.HR_duringT res.HR_postT];
        %                         deltaTHR = (THR(3:end)-THR(1:end-2))/2;
        %                         Lpre = length(res.HR_preT); Ldur = length(res.HR_duringT); Lpost=length(res.HR_postT);
        %
        %                         whmHR = [sum(res.HR_pre(2:end-1).*deltaTHR(2:Lpre-1))/(sum(deltaTHR(2:Lpre-1)))  ...
        %                             sum(res.HR_during(2:end-1).*deltaTHR(Lpre+1:Ldur+Lpre-2))/(sum(deltaTHR(Lpre+1:Ldur+Lpre-2)))...
        %                             sum(res.HR_post(2:end-1).*deltaTHR(Lpre+Ldur+1:Ldur+Lpre+Lpost-2))/(sum(deltaTHR(Lpre+Ldur+1:Ldur+Lpre+Lpost-2)))];
        %
        %
        %                         TBR = [res.BR_preT res.BR_duringT res.BR_postT];
        %                         deltaTBR = (TBR(3:end)-TBR(1:end-2))/2;
        %                         Lpre = length(res.BR_preT); Ldur = length(res.BR_duringT); Lpost=length(res.BR_postT);
        %
        %                         if Lpre < 2
        %                             TTpre = res.BR_pre;
        %                         elseif Lpre == 2
        %                             TTpre = mean(res.BR_pre);
        %                         else
        %                             TTpre = sum(res.BR_pre(2:end-1).*deltaTBR(1:Lpre-2))/(res.BR_preT(end-1)-res.BR_preT(1));
        %                         end
        %
        %                         if Ldur == 0
        %                             whmBR = [TTpre ...
        %                                 NaN...
        %                                 sum(res.BR_post(1:end-1).*deltaTBR(Lpre+Ldur:Ldur+Lpre+Lpost-2))/(res.BR_postT(end)-res.BR_postT(1))];
        %                         elseif Ldur == 1
        %                             whmBR = [TTpre ...
        %                                 NaN...
        %                                 sum(res.BR_post(1:end-1).*deltaTBR(Lpre+Ldur:Ldur+Lpre+Lpost-2))/(res.BR_postT(end)-res.BR_postT(1))];
        %                         else
        %                             whmBR = [TTpre ...
        %                                 sum(res.BR_during.*deltaTBR(Lpre:Ldur+Lpre-1)) /(res.BR_duringT(end)-res.BR_duringT(1))...
        %                                 sum(res.BR_post(1:end-1).*deltaTBR(Lpre+Ldur:Ldur+Lpre+Lpost-2))/(res.BR_postT(end)-res.BR_postT(1))];
        %                         end
        %
        %                         obj.results(i).resultHR = whmHR;
        %                         obj.results(i).resultBR = whmBR;
        %                     end
        %
        %                 case 'num_beat'
        %                     %% number of beat in total during stimulation
        %
        %                     for i = 1:numel(resTot)
        %
        %
        %                         res = resTot(i);
        %                          L_stim = res.numpulses/res.freq;
        %
        %                          whmHR = [length(res.HR_pre)/5 ...
        %                             length(res.HR_during)/L_stim...
        %                             length(res.HR_post)/5];
        %
        %                         %%
        %                         try
        %                         BB = length(res.BR_during)/L_stim;
        %                         catch
        %                             BB = 0;
        %                         end
        %                         whmBR = [length(res.BR_pre)/5 ...
        %                             BB...
        %                             length(res.BR_post)/5];
        %
        %                         obj.results(i).resultHR = whmHR;
        %                         obj.results(i).resultBR = whmBR;
        %                     end
        %
        %                 case 'mean_n'
        %                     %% n = in seconds; compute mean from n sec till end
        %                     for i = 1:numel(resTot)
        %                         res = resTot(i);
        %                         %                 n = 5;
        %                         TT = res.HR_duringT;
        %                         try
        %
        %
        %                         %%
        %                         switch when
        %                             case 'first'
        %                                 [~, TT_] = min(abs(TT - (TT(1)+n))); %TT = TT(TT_:end);
        %                                 HH = res.HR_during(1:TT_);
        %                             case 'last'
        %                                 [~, TT_] = min(abs(TT - (TT(1)+n))); %TT = TT(TT_:end);
        %                                 HH = res.HR_during(TT_:end);
        %
        %                             case 'interv'
        %                                 [~, TT_1] = min(abs(TT - (TT(1)+n(1)))); %TT = TT(TT_:end);
        %                                  [~, TT_2] = min(abs(TT - (TT(1)+n(2)))); %TT = TT(TT_:end);
        %                                 HH = res.HR_during(TT_1:TT_2);
        %                         end
        %
        %                         catch
        %                             HH = 0;
        %                         end
        %
        %                         whmHR = [mean(res.HR_pre(2:end-1)) ...
        %                             mean(HH)...
        %                             mean(res.HR_post(2:end-1))];
        %
        %                         %%
        %                         try
        %
        %                         switch when
        %                             case 'first'
        %                                  TT = res.BR_duringT; [~, TT_] = min(abs(TT - (TT(1)+n))); %TT = TT(TT_:end);
        %                                 BB = res.BR_during(1:TT_);
        %                             case 'last'
        %                                  TT = res.BR_duringT; [~, TT_] = min(abs(TT - (TT(1)+n))); %TT = TT(TT_:end);
        %                                 BB = res.BR_during(TT_:end);
        %
        %                             case 'interv'
        %                                 [~, TT_1] = min(abs(TT - (TT(1)+n(1)))); %TT = TT(TT_:end);
        %                                  [~, TT_2] = min(abs(TT - (TT(1)+n(2)))); %TT = TT(TT_:end);
        %                                 BB = res.BR_during(TT_1:TT_2);
        %
        %                         end
        %
        %                         catch
        %                             BB = 0;
        %                         end
        %
        %
        %                         whmBR = [mean(res.BR_pre(2:end-1)) ...
        %                             mean(BB)...
        %                             mean(res.BR_post(2:end-1))];
        %
        %
        %                         obj.results(i).resultHR = whmHR;
        %                         obj.results(i).resultBR = whmBR;
        %                     end
        %
        %             end
        %
        %
        %         end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        function obj = compute_mean_HR_BR(obj)
            resTot = obj. results;
            for i = 1:numel(resTot)
                res = resTot(i);
                L_stim = res.numpulses/res.freq;
                
                whmHR = [mean(res.HR_pre) ...
                    mean(res.HR_during) ];
                
                %%
                try
                    BB = mean(res.BR_during);
                catch
                    BB = 0;
                end
                whmBR = [mean(res.BR_pre) ...
                    BB...
                    ];
                
                obj.results(i).resultHR_aff_eff = whmHR;
                obj.results(i).resultBR_aff_eff = whmBR;
             
            end
        end
        
        %% check outliers and delete
        
        function obj = check_outliers(obj, which, thsld, above_below)
            switch which
                case 'BR'
                    ver = vertcat(obj.results.resultBR);
                case 'HR'
                    ver = vertcat(obj.results.resultHR);
            end
            
            switch above_below
                case 'above'
                    ver = ver(:,2); idx = find((ver)>thsld);
                case 'below'
                    ver = ver(:,2); idx = find((ver)<thsld);
            end
            
            for i = 1:length(idx)
                switch which
                    case 'HR'
                        obj.results(idx(i)).resultHR = [obj.results(idx(i)).resultHR(1) NaN obj.results(idx(i)).resultHR(3)];
                    case 'BR'
                        obj.results(idx(i)).resultBR = [obj.results(idx(i)).resultBR(1) NaN obj.results(idx(i)).resultBR(3)];
                end
                
            end
        end
        
        %% all results
        
        function obj = compute_tbl_for_polarity(obj, only_value, how)
            
            T0 = vertcat(obj.results.t0);
            aveHR = vertcat(obj.results.resultHR_aff_eff);
            aveBR = vertcat(obj.results.resultBR_aff_eff);
            aveNR = vertcat(obj.results.resultNR);
            
            if only_value
                valHR = aveHR(:, 2);
                valBR =aveBR(:, 2);
                 valNR =aveNR(:, 2);
            else
                
                valHR = (aveHR(:, 2)-aveHR(:, 1))./aveHR(:, 1)*100;
                valBR =(aveBR(:, 2)-aveBR(:, 1))./aveBR(:, 1)*100;
                valNR =(aveNR(:, 2)-aveNR(:, 1))./aveNR(:, 1)*100;
            end
            
            try
                setID = cellstr(vertcat(obj.results.setid));
            catch
                setID = cellstr(strvcat(obj.results.setid));
            end
            
            clear parset repeset
            for ii = 1:length(setID)
                CC = strsplit(char(setID(ii)),'.');
                parset(ii, 1) = str2num(char(CC(1))); repeset(ii, 1) = str2num(char(CC(2)));
            end
            
            amp =  vertcat(obj.results.amp);
            freq =  vertcat(obj.results.freq);
            numpulses =  vertcat(obj.results.numpulses);
            pw =  vertcat(obj.results.pw);
            FT =  vertcat(obj.results.FT);
            
            polarity =  vertcat(obj.results.polarity);
            valHR(abs(valHR)<1) = -1;
            valBR(isnan(valBR)) = -100;
            valBR(abs(valBR)<1) = -1;
            
            
            switch how
                case 'BR/HR'
                    ratio =  valBR./valHR;
                    ratio(ratio>100) = 100;
                    ratio(-ratio>60) = -10;
                case 'HR/BR'
                    ratio =  valHR./valBR;
                    
                case 'no'
                    ratio = NaN*ones(length(valHR), 1);
            end
            
            
            
            T = table(T0, valHR, valBR, ratio, valNR, amp, freq, numpulses, pw, polarity , FT, setID, parset, repeset);
            obj.all_res_pola = T;
            
        end
        
        %%
        
        function [couple, R, R_log] = compute_ratio_pola(obj, if_plot, namefile, norma)
            
            couple = [];
            PA = unique(obj.all_res_pola.parset);
            R = []; R_log = [];
            for pa = 1:length(PA)
                RE = unique(obj.all_res_pola.repeset(obj.all_res_pola.parset == pa));
                
                for re = 1:length(RE)
                    IDX = find(obj.all_res_pola.parset == PA(pa) & obj.all_res_pola.repeset == RE(re) );
                    for i = 2:2:length(IDX)
                        couple = ([couple; obj.all_res_pola.ratio(IDX(i-1)) obj.all_res_pola.ratio(IDX(i))]);
                    end
                end
            end
            
%              couple(couple<0) = 0;
            couple = abs(couple);
            if norma
                R_all  = (couple(:, 1) - couple(:, 2))./sqrt(couple(:, 1).^2 + couple(:, 2).^2);
                R_all_log  = (log10(couple(:, 1)) - log10(couple(:, 2)))./sqrt(log10(couple(:, 1)).^2 + log10(couple(:, 2)).^2);
            else
                R_all  = (couple(:, 1) - couple(:, 2));
            end
            
            R_all(abs(R_all)> 1000) = [];
            R_all(abs(R_all)> 3.5*nanstd(R_all)) = [];
            
            R = nanmean(R_all);
            R_log = real(nanmean(R_all_log));
            
            if if_plot
                figure, plot(couple(:,1), couple(:, 2), '.');
                XYL = [get(gca, 'Xlim'); get(gca, 'Ylim')];
                hold on, line([min(XYL) max(XYL)], [min(XYL) max(XYL)])
                title([namefile ' R = ' num2str(R)], 'Interpreter', 'none', 'fontweight', 'normal')
            end
            
        end
        
        %%
        
        
        function obj = compute_changes(obj, ifplot, only_value)
            
            T0 = vertcat(obj.results.t0);
            aveHR = vertcat(obj.results.resultHR);
            aveBR = vertcat(obj.results.resultBR);
            if only_value
                percHR = aveHR(:, 2);
                percBR =aveBR(:, 2);
            else
                
                percHR = (aveHR(:, 2)-aveHR(:, 1))./aveHR(:, 1)*100;
                percBR =(aveBR(:, 2)-aveBR(:, 1))./aveBR(:, 1)*100;
            end
            
            diffHR  = aveHR(:, 2)-aveHR(:, 1);
            diffBR = (aveBR(:, 2)-aveBR(:, 1));
            try
                setID = cellstr(vertcat(obj.results.setid));
            catch
                setID = cellstr(strvcat(obj.results.setid));
            end
            
            amp =  vertcat(obj.results.amp);
            freq =  vertcat(obj.results.freq);
            numpulses =  vertcat(obj.results.numpulses);
            pw =  vertcat(obj.results.pw);
            polarity =  vertcat(obj.results.polarity);
            T = table(T0, percHR, percBR, diffHR, diffBR, polarity, amp, freq, numpulses, pw, aveHR(:,1), aveHR(:,2), aveHR(:,3), aveBR(:,1), aveBR(:,2), aveBR(:,3), setID);
            T.Properties.VariableNames{'Var11'} = 'HRpre';
            T.Properties.VariableNames{'Var12'} = 'HRdur';
            T.Properties.VariableNames{'Var13'} = 'HRpost';
            T.Properties.VariableNames{'Var14'} = 'BRpre';
            T.Properties.VariableNames{'Var15'} = 'BRdur';
            T.Properties.VariableNames{'Var16'} = 'BRpost';
            
            
            legenda = {'pre', 'dur', 'post'};
            
            if ifplot
                figure,
                subplot(221), plot(T0/60, aveHR, '--.', 'markersize', 8),  set(gca, 'fontsize', 12)
                title(['HR'], 'interpreter', 'none', 'fontweight', 'normal'),
                xlabel('time in min'), ylabel('HR'), legend(legenda)
                subplot(222), plot(T0/60,  percHR , '--.', 'markersize', 8), set(gca, 'fontsize', 12)
                title(['% change in HR'], 'interpreter', 'none', 'fontweight', 'normal'),
                xlabel('time in min'), ylabel('% HR'),
                
                subplot(223), plot(T0/60, aveBR, '--.', 'markersize', 8),  set(gca, 'fontsize', 12)
                title(['BR'], 'interpreter', 'none', 'fontweight', 'normal'),
                xlabel('time in min'), ylabel('BR'), legend(legenda)
                subplot(224), plot(T0/60, percBR, '--.', 'markersize', 8), set(gca, 'fontsize', 12)
                title(['% change in BR'], 'interpreter', 'none', 'fontweight', 'normal'),
                xlabel('time in min'), ylabel('% BR')
            end
            
            obj.res_mdl.all_res = T;
        end
        
        
        %% map
        
        %         function obj = find_order_setids(obj)
        %             T = obj.results;
        %             map_idx = {};
        %             T_val = [vertcat(T.polarity) vertcat(T.amp) vertcat(T.freq) vertcat(T.numpulses) vertcat(T.pw)];
        %             [C, ~, ic] = unique(T_val, 'rows');
        %             ss = (C-(min(C)))./(max(C)- min(C));
        %             ss(isnan(ss)) = 0;
        %
        %             if length(unique(C(:,1)))>1
        %                 ss_change_pol = ss; ss_change_pol(:, 1)= ss_change_pol(:, 1)*5;
        %                 x = sum(ss_change_pol, 2);
        %                 [x_ord, x_idx] = sort(x);
        %                 x_idx1 = zeros(length(x_idx), 1);
        %                 x_idx1(1:2:end) = x_idx(1:end/2);
        %                 x_idx1(2:2:end) = x_idx(end/2+1:end);
        %                 C_ord = C(x_idx1, :);
        %                 mapping = [[1:max(ic)]' x_idx1];
        %             else
        %                 x = sum(ss, 2);
        %                 [x_ord, x_idx] = sort(x);
        %                 C_ord = C(x_idx, :);
        %                 mapping = [[1:max(ic)]' x_idx];
        %             end
        %
        %             %             mapping = [[1:max(ic)]' x_idx];
        %
        %             LUT     = zeros(1, max(mapping(:, 1)));  % Not required
        %             LUT(mapping(:, 1)) = mapping(:, 2);
        %             ic  = LUT(ic);
        %             ic = ic';
        %
        %             for i = 1:max(ic)
        %                 idx = find( ic == i);
        %                 aa = diff(idx);
        %                 start_new = find(aa>1);
        %                 rep = ones( length(idx) , 1);
        %                 if isempty(start_new)
        %                     map_idx{i} = [find( ic == i) rep];
        %                 else
        %                     for j = 1:length(start_new)
        %                         rep(start_new(j)+1:end) = rep(start_new(j)+1:end)+1;
        %                     end
        %
        %                     xx = find( ic == i);
        %                     set_x = ones(length(xx), 1);
        %                     xx_dif = find(diff(xx) > 2);
        %                     for pp = 1:length(xx_dif)
        %                         set_x(xx_dif(pp)+1:end) = set_x(xx_dif(pp)+1:end)+1;
        %
        %                     end
        %
        %                     map_idx{i} = [xx rep set_x];
        %                 end
        %             end
        %             obj.map_idx = map_idx;
        %             obj.states = [[1:max(ic)]' C_ord];
        %         end
        
        
        function obj = find_order_setids(obj)
            T = obj.results;
            map_idx = {};
            T_val = [vertcat(T.polarity) vertcat(T.amp) vertcat(T.freq) vertcat(T.numpulses) vertcat(T.pw)];
            [C, ~, ic] = unique(T_val, 'rows', 'sorted');
            ss = (C-(min(C)))./(max(C)- min(C));
            ss(isnan(ss)) = 0;
            
            %             mapping = [[1:max(ic)]' x_idx];
            
            for i = 1:max(ic)
                idx = find( ic == i);
                aa = diff(idx);
                start_new = find(aa>1);
                rep = ones( length(idx) , 1);
                if isempty(start_new)
                    map_idx{i} = [find( ic == i) rep ones(length(rep), 1)];
                else
                    for j = 1:length(start_new)
                        rep(start_new(j)+1:end) = rep(start_new(j)+1:end)+1;
                    end
                    
                    xx = find( ic == i);
                    set_x = ones(length(xx), 1);
                    xx_dif = find(diff(xx) > 2);
                    for pp = 1:length(xx_dif)
                        set_x(xx_dif(pp)+1:end) = set_x(xx_dif(pp)+1:end)+1;
                        
                    end
                    
                    map_idx{i} = [xx rep set_x];
                end
            end
            obj.map_idx = map_idx;
            obj.states = [[1:max(ic)]' C];
        end
        
        %% get param stimulation
        
        function obj = get_param_stimulation(obj, ifPrint)
            T = obj.results;
            parametri = struct('amp' , unique(vertcat(T.amp)), 'freq', unique(vertcat(T.freq)), ...
                 'FT', unique(vertcat(T.FT)), ...
                 'numpulses', unique(vertcat(T.numpulses)), 'pw', unique(vertcat(T.pw)), 'polarity', unique(vertcat(T.polarity)));
            
             FTnan = find(isnan(parametri.FT));
             if ~isempty(FTnan)
             parametri.FT = [parametri.FT(find(~isnan(parametri.FT)));  NaN];
             end
            if ifPrint
                parametri
            end
            obj.paramstim = parametri;
        end
        
        %% correlation
        
        function obj = find_correlation(obj)
            M = obj.res_mdl.vectors;
            [c,p] = corr(M(:,2), M(:,3), 'rows','complete');
            
            figure
            subplot(131)
            plot(M(:,2), M(:,3), '.', 'markersize', 12), title(['corr coeff = ' num2str(round(c, 3)) '; pval = ' num2str(round(p, 3))])
            xlabel('% HR'), ylabel('% BR')
            
            subplot(132)
            for i = 1:max(unique(M(:,4)))
                [c,p] =corr( M(M(:,4) == i,2), M((M(:,4) == i), 3), 'rows','complete');
                hold on, plot(M(M(:,4) == i,2), M((M(:,4) == i), 3), '.', 'markersize', 12), legenda{i} = ['R = ' num2str(round(c, 3)) '; pval = ' num2str(round(p, 3))];
            end
            legend(legenda)
            title('different param sets', 'fontweight', 'normal'), xlabel('% HR'), ylabel('% BR')
            xlabel('% HR'), ylabel('% BR')
            
            hr = obj.res_mdl.all_res.percHR;
            br = obj.res_mdl.all_res.percBR;
            for q = 5:length(hr)
                c_time(q) = corr(hr(1:q), br(1:q), 'rows','complete');
            end
            subplot(133), plot(obj.res_mdl.all_res.T0/60, c_time),
            xlabel('time in min'), ylabel('R')
            
        end
        
        %% plot pre dur postall values
        
        function obj = plot_predurpost_all(obj)
            figure(200), cl = colormap;
            close figure 200
            N = 5;
            for mv = 1:length(obj.map_idx)
                figure
                
                for m = 1:length(obj.map_idx{1,mv})
                    try
                        p = obj.results(obj.map_idx{1,mv}(m));
                        subplot(121), plot((p.HR_preT)-(p.HR_duringT(1)), smooth(p.HR_pre, N),'color',  cl(m*5, :)); hold on
                        plot((p.HR_duringT)-(p.HR_duringT(1)), smooth(p.HR_during, N), 'color', cl(m*5, :)); hold on
                        plot((p.HR_postT)-(p.HR_duringT(1)), smooth(p.HR_post, N), 'color', cl(m*5, :)); hold on
                        
                        subplot(122), plot((p.BR_preT)-(p.BR_duringT(1)), smooth(p.BR_pre, N), 'color',  cl(m*5, :)); hold on
                        plot((p.BR_duringT)-(p.BR_duringT(1)), smooth(p.BR_during, N), 'color', cl(m*5, :)); hold on
                        plot((p.BR_postT)-(p.BR_duringT(1)), smooth(p.BR_post, N), 'color', cl(m*5, :)); hold on
                    catch
                    end
                end
                subplot(121), title(['stim @ ' num2str(obj.states(mv, 3)) ' mV; ' num2str(obj.states(mv, 4)) ...
                    ' Hz; ' num2str(obj.states(mv, 6)) ' ms; #puls '  num2str(obj.states(mv, 5)) '; pol ' num2str(obj.states(mv, 2))], 'fontweight', 'normal')
            end
        end
        
        
        
        
        %% sort map as in paper
        
        function obj = sort_state_figure_all(obj)
            figure,
            
            [map, map_states, titolo, mm, CHR, which, CHR2] = obj.sort_state_figure('HR', 'pos', 0);
            subplot(441),  imagesc(map'), colorbar, title('HR - positive polarity')
            subplot(483),  imagesc(map_states), colorbar, xticks(1:5), title(titolo, 'fontweight', 'normal'); xticklabels({ 'polarity', 'amp', 'freq', 'numpulses', 'pw'}); xtickangle(45), xlabel('param'), yticks([1:length(sort(unique(map)))]), yticklabels(sort(unique(map))), ylabel('states')
            subplot(484),  imagesc(obj.states(mm,1)), colorbar, ylabel('states')
            subplot(445), plot(CHR), xlabel('states'), ylabel('% change'),  title(['\Delta ' which ' for each state ']), grid on
            subplot(446), plot(CHR2), xlabel('states'), ylabel('% change'),  title(['\Delta BR for each state ']), grid on
            
            [map, map_states, titolo, mm, CHR, which, CHR2] = obj.sort_state_figure('HR', 'neg', 0);
            subplot(443),  imagesc(map'), colorbar, title('HR - negative polarity')
            subplot(487),  imagesc(map_states), colorbar, xticks(1:5), title(titolo, 'fontweight', 'normal'); xticklabels({ 'polarity', 'amp', 'freq', 'numpulses', 'pw'}); xtickangle(45), xlabel('param'), yticks([1:length(sort(unique(map)))]), yticklabels(sort(unique(map))), ylabel('states')
            subplot(488),  imagesc(obj.states(mm,1)), colorbar, ylabel('states')
            subplot(447), plot(CHR), xlabel('states'), ylabel('% change'),  title(['\Delta ' which ' for each state ']), grid on
            subplot(448), plot(CHR2), xlabel('states'), ylabel('% change'),  title(['\Delta BR for each state ']), grid on
            
            [map, map_states, titolo, mm, CHR, which, CHR2] = obj.sort_state_figure('BR', 'pos', 0);
            subplot(449),  imagesc(map'), colorbar, title('BR - positive polarity')
            subplot(4, 8, 19),  imagesc(map_states), colorbar, xticks(1:5), title(titolo, 'fontweight', 'normal'); xticklabels({ 'polarity', 'amp', 'freq', 'numpulses', 'pw'}); xtickangle(45), xlabel('param'), yticks([1:length(sort(unique(map)))]), yticklabels(sort(unique(map))), ylabel('states')
            subplot(4, 8, 20),  imagesc(obj.states(mm,1)), colorbar, ylabel('states')
            subplot(4,4,13), plot(CHR), xlabel('states'), ylabel('% change'),  title(['\Delta ' which ' for each state ']), grid on
            subplot(4,4,14), plot(CHR2), xlabel('states'), ylabel('% change'),  title(['\Delta HR for each state ']), grid on
            
            [map, map_states, titolo, mm, CHR, which, CHR2] = obj.sort_state_figure('BR', 'neg', 0);
            subplot(4,4,11),  imagesc(map'), colorbar, title('BR - negative polarity')
            subplot(4,8,23),  imagesc(map_states), colorbar, xticks(1:5), title(titolo, 'fontweight', 'normal'); xticklabels({ 'polarity', 'amp', 'freq', 'numpulses', 'pw'}); xtickangle(45), xlabel('param'), yticks([1:length(sort(unique(map)))]), yticklabels(sort(unique(map))), ylabel('states')
            subplot(4,8,24),  imagesc(obj.states(mm,1)), colorbar, ylabel('states')
            subplot(4,4,15), plot(CHR), xlabel('states'), ylabel('% change'),  title(['\Delta ' which ' for each state ']), grid on
            subplot(4,4,16), plot(CHR2), xlabel('states'), ylabel('% change'),  title(['\Delta HR for each state ']), grid on
        end
        
        function [map, map_states, titolo, mm, CHR, which, CHR2] = sort_state_figure(obj, which, pol, if_plot)
            
            vectors = obj.res_mdl.vectors;
            switch pol
                case 'pos'
                    mm = find(obj.states(:,2) == 1);
                    titolo = 'pol posit';
                    
                case 'neg'
                    mm = find(obj.states(:,2) == -1);
                    titolo = 'pol neg';
            end
            indexes = ismember(vectors(:, 4),  mm);
            vectors  = vectors(indexes, :);
            %             vectors  = vectors(vectors(:, 6) == 1, :);
            switch which
                case 'HR'; w = 2;
                case 'BR'; w = 3;
            end
            
            [CHR, idxHR] = sort(vectors(:,w));
            CHR = CHR(~isnan(CHR)); idxHR = idxHR(~isnan(CHR));
            map = vectors(idxHR, 4);
            map_states = obj.states(mm,2:end);
            map_states = (map_states-(min(map_states)))./(max(map_states)- min(map_states));
            map_states(isnan(map_states)) = 0;
            
            %% mappa sull'altro
            switch which
                case 'HR'; w = 3;
                case 'BR'; w = 2;
            end
            [CHR2] = (vectors(idxHR,w));
            
            %%
            
            if if_plot
                figure, subplot(221),  imagesc(map'), colorbar
                subplot(244),  imagesc(map_states), colorbar
                xticks(1:5), title(titolo, 'fontweight', 'normal')
                xticklabels({ 'polarity', 'amp', 'freq', 'numpulses', 'pw'});
                xtickangle(45)
                xlabel('param'),  ylabel('states')
                subplot(243),  imagesc(obj.states(mm,1)), colorbar
                ylabel('states')
                
                subplot(212), plot(CHR),
                xlabel('states'), ylabel('% change')
                title(['\Delta ' which ' for each state '])
                grid on
            end
            %%
            
        end
        
        %% stationarity analysis between sets TODO aggiungere polarita'
        
        %% idx and stationarity analysis between sets
        
        function [MEAN, RANGE, DROP_set] = compute_index(obj, which, if_plot)
            switch which
                case 'HR'
                    if if_plot; figure;  end
                    TT = obj.res_mdl.all_res.percHR;
                    [MEAN, RANGE, DROP_set] = subFunctioncompute_index(obj, TT, which, 0, if_plot);
                case 'BR'
                    if if_plot; figure;  end
                    TT = obj.res_mdl.all_res.percBR;
                    TT(isnan(TT)) = 0;
                    [MEAN, RANGE, DROP_set] = subFunctioncompute_index(obj, TT, which, 0, if_plot);
                case 'both'
                    if if_plot; figure;  end
                    
                    TT = obj.res_mdl.all_res.percHR;
                    [MEAN_i, RANGE_i, DROP_set_i] = subFunctioncompute_index(obj, TT, 'HR', 1, if_plot);
                    
                    TT = obj.res_mdl.all_res.percBR;
                    TT(isnan(TT)) = 0;
                    [MEAN_ii, RANGE_ii, DROP_set_ii] = subFunctioncompute_index(obj, TT, 'BR', 2, if_plot);
                    
                    MEAN = {MEAN_i, MEAN_ii};
                    RANGE = {RANGE_i, RANGE_ii};
                    DROP_set = {DROP_set_i ; DROP_set_ii};
            end
        end
        
        
        function [MEAN, RANGE, DROP_set] = subFunctioncompute_index(obj, TT, which ,nn, if_plot)
            
            r = length(obj.map_idx);
            DROP = NaN*zeros(r, 6) ;% max(obj.res_mdl.vectors(:,5)));
            
            for i = 1:r
                
                set_num = unique(obj.map_idx{i}(:,3));
                n = 1;
                idx = obj.map_idx{i}(:,1) ;
                
                ixx = numel(set_num);
                if ixx > 2
                    ixx = 2;
                end
                
                for s = 1:ixx %
                    
                    idx_n = idx(obj.map_idx{i}(:,3) == s) ;
                    for jj = 1: 3 %length(idx)
                        try
                            sm = smooth(obj.results(idx_n(jj)).HR_during(1:end-2));
                            DROP(i,n) = (max(sm)-min(sm))./min(sm);
                            n = n+1;
                        catch
                        end
                    end
                    MEAN(i,s) = [mean(TT(idx_n))];
                    MIN(i,s) = [min(TT(idx_n))];
                    MAX(i,s) = [max(TT(idx_n))];
                    try
                        RANGE (i,s) =  range(TT(idx_n));
                    catch
                        RANGE (i,s) =  NaN;
                    end
                    DROP_set (i,s) =  mean(DROP(i,(1:3)+3*(s-1))) ;
                end
            end
            
            map_states = obj.states(:,2:end);
            map_states = (map_states-(min(map_states)))./(max(map_states)- min(map_states));
            map_states(isnan(map_states)) = 0;
            
            %             figure,
            %             subplot(141),  imagesc(map_states), colorbar
            %             xticks(1:5)
            %             xticklabels({ 'polarity', 'amp', 'freq', 'numpulses', 'pw'});
            %             xtickangle(45)
            %             xlabel('param'),  ylabel('states')
            %             title(['stati map ' which], 'fontweight', 'normal')
            %
            %             subplot(142),  imagesc(-MEAN), colorbar00000000000000000.
            
            %             title('Mean %change', 'fontweight', 'normal')
            %             subplot(143),  imagesc(RANGE./MEAN), colorbar
            %             title('norm range %change', 'fontweight', 'normal')
            %
            %             %               subplot(144),  imagesc(zscore(DROP, [], 2)), colorbar
            %             subplot(144),  imagesc(DROP_set), colorbar
            %             title('mean Drop', 'fontweight', 'normal')
            % %             x = find(obj.states(:, 2) == 1);
            for yy = 1:length(map_states(:, 1))
                v = obj.states(yy, :);
                %     ylabel_mat{yy} = {[num2str(v(1)) ': ' num2str(v(2)) 'pol; ' num2str(3) ' mA; ' num2str(4) ' Hz;'] ;  [num2str(5) '#P; ' num2str(6)  ' ms']};
                ylabel_mat{yy} = [num2str(v(1)) ': ' num2str(v(2)) 'pol; ' num2str(v(3)) ' mA; ' num2str(v(4)) ' Hz; \newline' num2str(v(5)) '#P; ' num2str(v(6))  ' ms'];
                
            end
            
            if if_plot
                subplot(131),
                
                imagesc(map_states), colorbar
                xticks(1:5)
                xticklabels({ 'polarity', 'amp', 'freq', 'numpulses', 'pw'});
                xtickangle(45)
                xlabel('param'),  ylabel('states'); yticks([1:yy]), yticklabels(ylabel_mat);
                title(['stati map ' which], 'fontweight', 'normal')
                
                for i = 1:ixx
                    x = find(obj.states(:, 2) == 1);
                    switch nn
                        case 0
                            subplot(132),
                        case 1
                            subplot(232),
                        case 2
                            subplot(235),
                    end
                    errorbar(x,MEAN(x,i), MEAN(x,i)-MIN(x,i), MAX(x,i)-MEAN(x,i)), hold on,
                    
                    title([ which ' pos pol' ]), xlabel('status'), yy1 = get(gca, 'ylim'); xlim([x(1)-1 x(end)+1])
                    x = find(obj.states(:, 2) == -1);
                    switch nn
                        case 0
                            subplot(133),
                        case 1
                            subplot(233),
                        case 2
                            subplot(236),
                    end
                    
                    
                    errorbar(x,MEAN(x,i), MEAN(x,i)-MIN(x,i), MAX(x,i)-MEAN(x,i)), xlim([x(1)-1 x(end)+1])
                    hold on,
                    title('neg pol'), xlabel('status'), yy2 = get(gca, 'ylim');
                    
                end
                yy = [yy1 ; yy2];
                lim_y = [min(yy(:, 1)) max(yy(:, 2))];
                
                switch nn
                    case 0
                        subplot(132), ylim(lim_y),  grid on , subplot(133), ylim(lim_y),  grid on
                    case 1
                        subplot(232), ylim(lim_y), grid on , subplot(233), ylim(lim_y),  grid on
                    case 2
                        subplot(235), ylim(lim_y), grid on ,subplot(236), ylim(lim_y),  grid on
                end
                
            end
        end
        
        function obj = check_stationarity_multiple_sets(obj, ifplot, ifstat)
            vectors = []; polarity =  [] ; amp = [];
            freq = []; numpulses = []; pw = [];
            T = obj.res_mdl.all_res;
            
            r = length(obj.map_idx);
            for i = 1:r
                idx = obj.map_idx{i}(:,1);
                percHR = T.percHR(idx);
                percBR = T.percBR(idx);
                T0= T.T0(idx)/60;
                
                if ifplot
                    figure
                    
                    for j = 1:max(obj.map_idx{i}(:,2))
                        idx_rep = find(obj.map_idx{i}(:,2) == j);
                        
                        subplot(121),bar(T.T0(idx(idx_rep(1))), nanmean(T.percHR(idx(idx_rep)))), hold on, plot(T.T0(idx(idx_rep(1)))*ones(1,length(T.percHR(idx(idx_rep)))), (T.percHR(idx(idx_rep))), '.', 'markersize', 12)
                        xlabel('Time in hrs'), ylabel('% change in HR')
                        
                        subplot(122),bar(T.T0(idx(idx_rep(1))), nanmean(T.percBR(idx(idx_rep)))), hold on, plot(T.T0(idx(idx_rep(1)))*ones(1,length(T.percBR(idx(idx_rep)))), (T.percBR(idx(idx_rep))), '.', 'markersize', 12)
                        xlabel('Time in hrs'), ylabel('% change in BR')
                    end
                end
                
                %                 vectors = [vectors; [T0 percHR percBR i*ones(length(obj.map_idx{i}), 1)  obj.map_idx{i}(:,2) obj.map_idx{i}(:,3) ] ];
                vectors = [vectors; [T0 percHR percBR i*ones(length(idx), 1)  obj.map_idx{i}(:,2) obj.map_idx{i}(:,3) ] ];
                
                polarity =  [ polarity ; T.polarity(idx)];
                amp = [amp; T.amp(idx)];
                freq = [freq; T.freq(idx)];
                numpulses = [numpulses; T.numpulses(idx)];
                pw = [pw ; T.pw(idx)];
                
            end
            obj.res_mdl.vectors = vectors;
        end
        
        function obj = compute_indexes(obj)
            
        end
        
        function obj = plot_function_param(obj, param1, param2, param3, valParam3, pol)
            
            % param1 xaxis, param2 overlap, param3 fix
            figure
            T = obj.results;
            AA = obj.res_mdl.all_res;
            pp1 = getfield(obj.paramstim, param1);
            pp2 = getfield(obj.paramstim, param2);
            pp3 = getfield(obj.paramstim, param3);
            
            for ii = 1:length(pp2)
                VAL = []; PAR = [];
                for jj = 1:length(pp1)
                    
                    idx_pos = find([AA.(param1)] == pp1(jj) & [AA.(param2)] == pp2(ii)...
                        & [AA.(param3)] == valParam3 ...
                        &  [AA.polarity] == pol);
                    
                    VAL = [VAL; [AA.percHR(idx_pos) AA.percBR(idx_pos)]];
                    PAR = [PAR; repmat(pp1(jj), length(idx_pos), 1) ];
                end
                
                subplot(121), plot(PAR, VAL(:,1), '--.', 'markersize', 12), hold on
                subplot(122), plot(PAR, VAL(:,2), '--.', 'markersize', 12), hold on
                
            end
            
            subplot(121), leg = legend(num2str(pp2)); xticks(pp1);
            title(leg, param2);
            xlabel(param1), ylabel('change in HR %'), %ylim([-50 10])
            title(['Stim @ pol = ' num2str(pol) '; ' param3 ' = ' num2str(valParam3)])
            subplot(122), leg = legend(num2str(pp2)); xticks(pp1);
            title(leg, param2);
            xlabel(param1), ylabel('change in BR %'), %ylim([-50 10])
            title(['Stim @ pol = ' num2str(pol) '; ' param3 ' = ' num2str(valParam3)])
        end
        
        
        %% idx
        
        function obj = compute_idx(obj)
            
            for mv = 1:length(obj.map_idx)
                figure
                
                for m = 1:length(obj.map_idx{1,mv})
                    try
                        p = obj.results(obj.map_idx{1,mv}(m));
                        subplot(121), plot((p.HR_preT)-(p.HR_duringT(1)), smooth(p.HR_pre, N),'color',  cl(m*5, :)); hold on
                        plot((p.HR_duringT)-(p.HR_duringT(1)), smooth(p.HR_during, N), 'color', cl(m*5, :)); hold on
                        plot((p.HR_postT)-(p.HR_duringT(1)), smooth(p.HR_post, N), 'color', cl(m*5, :)); hold on
                        
                        subplot(122), plot((p.BR_preT)-(p.BR_duringT(1)), smooth(p.BR_pre, N), 'color',  cl(m*5, :)); hold on
                        plot((p.BR_duringT)-(p.BR_duringT(1)), smooth(p.BR_during, N), 'color', cl(m*5, :)); hold on
                        plot((p.BR_postT)-(p.BR_duringT(1)), smooth(p.BR_post, N), 'color', cl(m*5, :)); hold on
                    catch
                    end
                end
                subplot(121), title(['stim @ ' num2str(obj.states(mv, 3)) ' mV; ' num2str(obj.states(mv, 4)) ...
                    ' Hz; ' num2str(obj.states(mv, 6)) ' ms; #puls '  num2str(obj.states(mv, 5)) '; pol ' num2str(obj.states(mv, 2))], 'fontweight', 'normal')
            end
        end
        
        %% find index from repset
        
        function [idx_phys] = query_index_phys(obj, repset, pol)
            setID = obj.res_mdl.all_res.setID;
            idx_phys = find(strcmp(repset, setID) & obj.res_mdl.all_res.polarity == pol);
        end
        
        %%
        
        function [WGHT, pVAL, mdl] = model_regression_generate(obj, tt, model_string)
            
            mdl = fitlm(tt,model_string);
            WGHT = mdl.Coefficients.Estimate;
            pVAL = mdl.Coefficients.pValue;
            
        end
        
        
    end
    
    
end



%% generate matrix two columns with the map to combine rows in results
%         function obj = find_order_setids(obj, setid)
%
%             MAPPA = [];
%             for i=1:numel(setid)
%                 idx1 = find( strcmp( {obj.results(:).setid}, setid{1,i}{1,1}));
%                 idx2 = find( strcmp( {obj.results(:).setid}, setid{1,i}{1,2}));
%                 MAPPA_i = [idx1'];
%
%                 for j1 = 1:numel(idx1)
%                     pp1 = obj.results(idx1(j1)).polarity;
%                     n = 2;
%                     for j2 = 1:numel(idx2)
%                         pp2 = obj.results(idx2(j2)).polarity;
%
%                         if pp1== pp2
%                             MAPPA_i(j1, n) = idx2(j2);
%                             n = n+1;
%                         end
%                     end
%
%                 end
%
%                 MAPPA = [ MAPPA; MAPPA_i];
%
%             end
%
%             MAPPA= unique(MAPPA, 'row');
%             %             MAPPA((MAPPA==0)) = NaN;
%             [r,~]= find((MAPPA==0));
%             MAPPA(r, :) = [];
%             obj.map = MAPPA;
%         end


%
%  %% stationarity analysis between set 1 and 2
%         function obj = check_stationarity(obj, ifplot, ifstat)
%
%             T = obj.res_mdl.all_res;
%
%             percHR = [T.percHR(obj.map(:,1)) T.percHR(obj.map(:,2))];
%             percBR = [T.percBR(obj.map(:,1)) T.percBR(obj.map(:,2))];
%             diffHR = [T.diffHR(obj.map(:,1)) T.diffHR(obj.map(:,2))];
%             diffBR = [T.diffBR(obj.map(:,1)) T.diffBR(obj.map(:,2))];
%             T0 = [T.T0(obj.map(:,1)) T.T0(obj.map(:,2))];
%             polarity =  vertcat(obj.results.polarity);
%             polarity = polarity((obj.map(:,1)));
%             amp =  vertcat(obj.results.amp);
%             amp = amp(obj.map(:,1));
%             freq =  vertcat(obj.results.freq);
%             freq = freq(obj.map(:,1));
%             numpulses =  vertcat(obj.results.numpulses);
%             numpulses = numpulses(obj.map(:,1));
%             pw =  vertcat(obj.results.pw);
%             pw = pw(obj.map(:,1));
%             TA = table(T0, percHR, percBR, diffHR, diffBR, polarity, amp, freq, numpulses, pw);
%             obj.res_mdl.couple = TA;
%
%             if ifplot
%                 H = height(TA);
%
%                 figure,
%                 for j = 1:H
%                     subplot(121), plot([1 2], TA.percHR(j,:), 'marker', '.', 'markersize', 8), hold on
%                     subplot(122), plot([1 2], TA.percBR(j,:), 'marker', '.', 'markersize', 8), hold on
%                 end
%
%                 subplot(121), xticks([1 2]),xticklabels({'set 1', 'set2'}); xlim([0.7 2.3])
%                 title(['% change in HR'], 'interpreter', 'none', 'fontweight', 'normal'),
%
%                 subplot(122),xticks([1 2]),xticklabels({'set 1', 'set2'}); xlim([0.7 2.3])
%                 title(['% change in BR'], 'interpreter', 'none', 'fontweight', 'normal'),
%
%                 % wilcoxon paired test
%                 if ifstat
%                     HRtest = signrank(TA.percHR(:,1), TA.percHR(:,2));
%                     subplot(121),
%                     title(['% change in HR - p = ' num2str(round(HRtest*1000)/1000)], 'interpreter', 'none', 'fontweight', 'normal'),
%
%                     BRtest = signrank(TA.percBR(:,1), TA.percBR(:,2));
%                     subplot(122),
%                     title(['% change in BR - p = ' num2str(round(BRtest*1000)/1000)], 'interpreter', 'none', 'fontweight', 'normal'),
%                 end
%             end
%         end




%                     idx2 = find( strcmp( {obj.results(:).setid}, setid{1,i}{1,2}));
%
%                     MAPPA_i = [idx1'];
%
%                 for j1 = 1:numel(idx1)
%                     pp1 = obj.results(idx1(j1)).polarity;
%                     n = 2;
%                     for j2 = 1:numel(idx2)
%                         pp2 = obj.results(idx2(j2)).polarity;
%
%                         if pp1== pp2
%                             MAPPA_i(j1, n) = idx2(j2);
%                             n = n+1;
%                         end
%                     end
%
%                 end
%
%                 MAPPA = [ MAPPA; MAPPA_i];
%
%             end
%
%             MAPPA= unique(MAPPA, 'row');
%             %             MAPPA((MAPPA==0)) = NaN;
%             [r,~]= find((MAPPA==0));
%             MAPPA(r, :) = [];
%             obj.map = MAPPA;
%             end


%         function obj = sort_state_figure2(obj, param1, param2, which)
%             T = obj.res_mdl.couple;
%             vectors = obj.res_mdl.vectors;
%             T_val = [T.polarity T.amp T.freq T.numpulses T.pw];
%             T_val = T_val./max(T_val);
%
%             [CH1, idx1] = sort(vectors(:,1));
%             map1 = T_val(idx1, :);
%
%             [CH2, idx2] = sort(percCH(:,2));
%             map2 = T_val(idx2, :);
%
%             figure, subplot(321), imagesc(map1'), colorbar
%             yticks([1 2]), yticklabels({param1, param2})
%             xlabel('states'), title(['Map da set 1'])
%             subplot(323), plot(CH1)
%             title(['\Delta ' which ' for each state - set 1, map1'])
%             %              subplot(325), plot(diff(BR1))
%             %              title(['diff \Delta BR for following states - set 1, map1'])
%
%             subplot(325),  plot(percCH(idx1,2))
%             title(['\Delta ' which ' for each state - set 2, map1'])
%
%             subplot(322), imagesc(map2'), colorbar
%             yticks([1 2]), yticklabels({param1, param2})
%             xlabel('states'), title(['Map da set 2'])
%             subplot(324), plot(CH2)
%             title(['\Delta ' which ' for each state - set 1, map2'])
%             %              subplot(326), plot(diff(BR2))
%             %              title(['diff \Delta BR for following states - set 1, map2'])
%             subplot(326),  plot(percCH(idx2,1))
%             title(['\Delta ' which ' for each state - set 1, map2'])
%
%             T_val = [T.(param1) T.(param2)];
%             T_val = T_val./max(T_val);
%             switch which
%                 case 'BR'
%                     percCH = T.percBR;
%                 case 'HR'
%                     percCH = T.percHR;
%             end
%
%
%             [CH1, idx1] = sort(percCH(:,1));
%             map1 = T_val(idx1, :);
%
%             [CH2, idx2] = sort(percCH(:,2));
%             map2 = T_val(idx2, :);
%
%             figure, subplot(321), imagesc(map1'), colorbar
%             yticks([1 2]), yticklabels({param1, param2})
%             xlabel('states'), title(['Map da set 1'])
%             subplot(323), plot(CH1)
%             title(['\Delta ' which ' for each state - set 1, map1'])
%             %              subplot(325), plot(diff(BR1))
%             %              title(['diff \Delta BR for following states - set 1, map1'])
%
%             subplot(325),  plot(percCH(idx1,2))
%             title(['\Delta ' which ' for each state - set 2, map1'])
%
%             subplot(322), imagesc(map2'), colorbar
%             yticks([1 2]), yticklabels({param1, param2})
%             xlabel('states'), title(['Map da set 2'])
%             subplot(324), plot(CH2)
%             title(['\Delta ' which ' for each state - set 1, map2'])
%             %              subplot(326), plot(diff(BR2))
%             %              title(['diff \Delta BR for following states - set 1, map2'])
%             subplot(326),  plot(percCH(idx2,1))
%             title(['\Delta ' which ' for each state - set 1, map2'])
%
%         end

%