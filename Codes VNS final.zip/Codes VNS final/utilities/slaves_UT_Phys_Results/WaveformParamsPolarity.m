
function [keyset, polar, FT, condit] = WaveformParamsPolarity(filename)
% [folderDir, ~, ext] = fileparts(filename);
% switch ext
% %     case {'.xls', '.xlsx'}
% %         [numeric, ~, raw] = xlsread(filename);
% %         
% %         params = containers.Map(keyset, ...
% %             num2cell(arrayfun(@(ii) struct('pulsewidth_us', numeric(ii, 3), ...
% %             'freq_Hz', numeric(ii, 4), 'numpulses', numeric(ii, 5), ...
% %             'duration_s', numeric(ii, 6), 'amp', numeric(ii,7), 'iti_s', numeric(ii, 8), ...
% %             'wait_min', numeric(ii, 9)), inds)));
% %         obj.timeest = numeric(end, 2);
%     case '.csv'
        % implement csv reader
        raw = read_waveformparams_csv_pola(filename, ',');
        obj.datestr = raw{1, 2};
        obj.expid = raw{2, 2};
        obj.threshparams = struct('pulsewidth_us', str2double(raw{5, 2}), ...
            'freq_Hz', str2double(raw{1, 3}), ...
            'numpulses', str2double(raw{5, 4}), ...
            'duration_s', str2double(raw{5, 5}));
        obj.trainsperset = str2double(raw{7, 2});
        obj.altpol = contains_(raw{7, 1}, 'with alt-pol');
        obj.setreps = str2double(raw{9, 2});
        obj.vnsside = raw{10, 2};
        obj.stimcuff = raw{11, 2};
        obj.reccuff = raw{12, 2};
        ind1 = find(cellfun(@(x) isequal(x, 'Rep ID'), raw(:, 1)));
        ind = ind1 + find(cellfun(@(x) isempty(x), raw((ind1+1):end, 1)), 1, 'first') - 1;
        inds = (ind1+1):ind;
        temp = cellfun(@(x) str2double(x), raw(inds, :));
        
       
        
        
        keyset = arrayfun(@(repid, setid) [num2str(repid) '.' num2str(setid)], temp(:, 1), temp(:, 2), 'UniformOutput', false);
        polar = arrayfun(@(pol) [pol], temp(:, 8));
        FT = arrayfun(@(FT) [FT], temp(:, 9));
        condit = arrayfun(@(condit) [condit], temp(:, 8));
           
end

% end

