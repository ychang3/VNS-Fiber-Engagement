function cvrange = getcvrange(input)
    switch lower(input)
        case {'ia', '1a', 'ib', '1b', 'i', '1', 'a_alpha'}
            cvrange = [80, 120];
        case {'ii', '2', 'a_beta'}
            cvrange = [30, 80];
        case {'iii', '3', 'a_delta'}
            cvrange = [3, 30];
        case {'iv', '4', 'c'}
            cvrange = [0.5, 3];
        case 'a'
            cvrange = [15, 120];
        case 'b'
            cvrange = [3, 15];
        otherwise
            erorr('Unrecognized/Undefined input')
            cvrange = [];
    end
end