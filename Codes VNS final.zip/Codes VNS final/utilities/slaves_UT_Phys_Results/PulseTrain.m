classdef PulseTrain < handle
    properties
        repset
        data
        sr
        t0
        n1
        n2
        pulses
        pulses2    % falling edge
        evokedpotentials
        baseline
        prf
        
        record      % record in which this train occurs
        pol         % 'rep.set' only describes whether or not the polarity alternates
        ampgain     % 'rep.set' doesn't include the amplitude
                    % TODO Should direction (caudal to rostral or vise versa be a parameter?)
        comments    % cell array of strings
        
        physioNames % cell array of strings containing the physiological channel names
        physioData  % cell array of arrays of physiological data for each channel
        physioSr    % array of sampling rates for each channel
        
        params
        
        relecs      % recording electrodes
        selecs      % stimulating electrode(s)
        
        col         % color for plotting
        nfeats      % neural features computed for each train
        stimfeats   % stimulation features computed for each train
        
        % Electrical stimulation properties
        buffertime  % number of seconds of data extracted before and after stim
        stimdur     % duration of stim
        
        % Physiological parameters
        ecg         % ecg corresponding to stimulation train
        resp        % respiratory signal corresponding to stimulation train
        tecg        % time vector of ecg 
        tresp       % time vector of respiratory
        hr          % heart rate
        thr         % time vector for heart rate
        br          % breathing rate
        tbr         % time vector for breathing rate
        hpks        % ECG peak values
        bpks        % Breathing peak values
        results     % results table with mean values for physiological properties for pre, during and post stim
        results2    % results structure with arrays of the raw HR and BR values for pre, during and post stim
        resultsM
        physfeats   % extracted physiological features for modeling
        
        
        polar
        FT
        condit
        
        
        
    end
    
    properties (Dependent)
        tlocal
    end
        
    methods
        function val = get.tlocal(obj)
            val = obj.t0 + (0:size(obj.data, 1)-1) / obj.sr;
        end
    end
    
    methods (Access = public)
        function obj = PulseTrain(data, sr, t0, n1, n2, trigchan, pol, ampgain, repset, chan, plotflag, params, record)
              
            
             if ~exist('chan', 'var') || isempty(chan)
                chan = 1;
            end
            if ~exist('plotflag', 'var') || isempty(plotflag)
                plotflag = false;
            end
            
            obj.data = data;   % data segment around the pulse train
            obj.sr = sr;       % sampling rate (Hz)
            obj.t0 = t0;       % time at the beginning of the pulse train (s) (start of data segment, n0 samples back from pulse)
            obj.n1 = n1;       % number of samples to collect before each pulse for the baseline
            obj.n2 = n2;       % number of samples to collect after each pulse for the evoked response            
            obj.pol = pol;     % polarity {+1, -1}
            obj.ampgain = ampgain;                               
            obj.repset = repset;
            obj.params = params;
            obj.comments = {};
            
            if exist('record', 'var')
                obj.record = record;
            end
            
            if isempty(trigchan)
                % I only need to do this if the pulses aren't already marked
%                 if ~exist('chan', 'var')
%                     chan = 1;
%                 end
                obj.find_pulses(0.03, 100, 0.0001, 0.01, Inf, chan, plotflag);
            else
                temp = trigchan((obj.n1+1):(end-obj.n2));
                obj.pulses = obj.n1 + find(temp(1:end-1) == 0 & temp(2:end) == 1);
                obj.pulses2 = obj.n1 + find(temp(1:end-1) == 1 & temp(2:end) == 0);
                obj.prf = obj.sr / mode(diff(obj.pulses));
            end
            
            % don't stack here because data is all channels now
            % obj.stack_ep(chanfcn);
        end
        
        function find_pulses(obj, minpeakdist, minpeakprom, minpeakwidth, maxpeakwidth, wthresh, chan, plotflag)
            if ~exist('minpeakdist', 'var') || isempty(minpeakdist)
                minpeakdist = 0.03;
            end
            if ~exist('minpeakprom', 'var') || isempty(minpeakprom)
                minpeakprom = 50;
            end
            if ~exist('minpeakwidth', 'var') || isempty(minpeakwidth)
                minpeakwidth = 0.0001;
            end
            if ~exist('maxpeakwidth', 'var') || isempty(maxpeakwidth)
                maxpeakwidth = 0.001;
            end
            if ~exist('wthresh', 'var') || isempty(wthresh)
                wthresh = 14;
            end
            if ~exist('plotflag', 'var') || isempty(plotflag)
                plotflag = false;
            end
            
             if ~exist('chan', 'var') || isempty(chan)
                chan = 1;
            end
            
            % TODO this is a bandaid
            if obj.pol == 0
                obj.pol = 1;
            end
            
            assert(ismember(obj.pol, [-1 1]));
            assert(islogical(plotflag));            

            % This function is obsolete, so chan is hardcoded
%             chan = 1;
            
            [pks, locs, w, ~] = findpeaks(obj.pol * obj.data((obj.n1+1):(end-obj.n2), chan), ...
                'MinPeakDistance', minpeakdist * obj.sr, ...
                'MinPeakProminence', minpeakprom, ...
                'MinPeakWidth', minpeakwidth * obj.sr, ...
                'MaxPeakWidth', maxpeakwidth * obj.sr);
            
            indsw = w < wthresh;
            inds = (obj.n1+1):(size(obj.data, 1)-obj.n2);
            
            if plotflag                
                figure;plot(obj.tlocal(inds), obj.data(inds, chan), '-b', ...
                            obj.tlocal(inds(locs)), obj.pol * pks, 'r.');
                xlabel('Time (s)');ylabel('Voltage (\muV)');
            end
            
            obj.pulses = inds(locs(indsw));
            pw = 100e-6;  % look in spreadsheet
            obj.pulses2 = obj.pulses + obj.sr * pw;
            obj.prf = obj.sr / mode(diff(obj.pulses));
        end
        
        function stack_ep(obj, chanfcn, detrendartifact, T)
            if ~exist('detrendartifact', 'var') || isempty(detrendartifact)                
                detrendartifact = false;                
            end
            if ~exist('T', 'var') || isempty(T)                
                T = [0 0.005];                
            end
            assert(isa(chanfcn, 'function_handle'));
            if isempty(obj.pulses)
                fprintf('call obj.find_pulses() first to set obj.pulses\n');
            end
            
            % align to stim triggers            
            numpulses = length(obj.pulses);            
            obj.baseline = zeros(obj.n1, numpulses);
            obj.evokedpotentials = zeros(obj.n2, numpulses);
            
            if isempty(obj.relecs)
                obj.relecs = 1;
            end
            singlechannel = chanfcn(obj.data, obj.relecs);
            % singlechannel = chanfcn(obj.data);
            
            for ipulse = 1:numpulses
                obj.evokedpotentials(:, ipulse) = singlechannel(obj.pulses(ipulse) + (0:obj.n2 - 1));
                obj.baseline(:, ipulse) = singlechannel(obj.pulses(ipulse) + (-obj.n1:-1));
            end
            
            % suppress artifact with double exponential            
            if detrendartifact
                stimsamples = obj.pulses2(1) - obj.pulses(1) + 1;
                if isnan(T(1))
                    inds = stimsamples:min(ceil(T(2) * obj.sr), size(obj.data, 1));
                else
                    inds = (stimsamples + floor(T(1) * obj.sr)):min(ceil(T(2) * obj.sr), size(obj.data, 1));
                end
                x = inds';
                y = mean(obj.evokedpotentials(inds, :), 2);
                if isnan(T(1))
                    [~, mi] = max(y);
                else                    
                    mi = 1;
                end
                x = x(mi:end);
                y = y(mi:end);
                dblexpoffset = @(a, b, c, d, e, x) a + b*exp(-c*x) + d*exp(-e*x);
                try
                    [fitobj, gof, output] = fit(x, y, dblexpoffset, 'MaxFunEvals', 5000, 'MaxIter', 5000, 'Normalize', 'on');
                    if verLessThan('matlab', '9.1')
                        obj.evokedpotentials(mi+(0:length(x)-1), :) = bsxfun(@minus, obj.evokedpotentials(mi+(0:length(x)-1), :), fitobj(x));
                    else
%                         figure;plot(obj.evokedpotentials)
%                         figure;plot(x, [y fitobj(x) y-fitobj(x)]);
                        obj.evokedpotentials(mi+(0:length(x)-1), :) = obj.evokedpotentials(mi+(0:length(x)-1), :) - fitobj(x);
                    end
                catch ex
                    fprintf('Error in detrending curve fit\n');
                    disp(ex);
                end
                
            end
        end
        
        function plot_all_responses(obj, ax, chanfcn, pulseinds, suppressartifact, extendsuppression, outlierpct, detrendartifact, T)
            if ~exist('ax', 'var') || isempty(ax)                
                ax = [];
            end
            if ~exist('chanfcn', 'var') || isempty(chanfcn)                
                chanfcn = @(data, relecs) data(:, relecs(1));
            end
            if ~exist('pulseinds', 'var') || isempty(pulseinds)
                pulseinds = 1:length(obj.pulses);
            end
            if ~exist('suppressartifact', 'var') || isempty(suppressartifact)
                suppressartifact = 1;
            end
            if ~exist('extendsuppression', 'var') || isempty(extendsuppression)
                extendsuppression = 0;
            end
            if ~exist('outlierpct', 'var') || isempty(outlierpct)
                outlierpct = 0;
            end
            if ~exist('detrendartifact', 'var') || isempty(detrendartifact)
                detrendartifact = false;
            end
            if ~exist('T', 'var') || isempty(T)                
                T = 0.005;                
            end
            pulseinds = ismember(1:length(obj.pulses), pulseinds);  % truncate if necessary
            
            obj.stack_ep(chanfcn, detrendartifact, T);
            ep = obj.evokedpotentials;            
            
            % distribution doesn't look Gaussian
            % [N, X] = hist(sqrt(sum(ep(50:end, :).^2, 1)), round(sqrt(550)));figure;plot(X, N);
            x = sum(ep(50:end, :).^2, 1);
            thresh = quantile(x, (100 - outlierpct)/100);
            qinds = x < thresh;
                
            if verLessThan('matlab', '9.1')                
                y = bsxfun(@minus, [obj.baseline(:, qinds & pulseinds); ep(:, qinds & pulseinds)], median(obj.baseline(:, qinds & pulseinds), 1));
            else
                y = [obj.baseline(:, qinds & pulseinds); ep(:, qinds & pulseinds)] - median(obj.baseline(:, qinds & pulseinds), 1);
            end
            
            obj.plot_all_responses_(ax, y, obj.sr);
            if suppressartifact && ~isempty(obj.pulses2)          
                obj.blank_artifact_with_patch(ax, extendsuppression*1e-3);  % from us to ms
            end
            % obj.show_cv_ranges(ax)
            
            title(obj.repset)
        end
        
        function plot_avg_response(obj, ax, chanfcn, pulseinds, avgonly, suppressartifact, extendsuppression, outlierpct, detrendartifact, T)
            if ~exist('ax', 'var') || isempty(ax)                
                ax = [];
            end
            if ~exist('detrendartifact', 'var') || isempty(detrendartifact)                
                detrendartifact = false;
            end
            if ~exist('T', 'var') || isempty(T)                
                T = 0.005;                
            end
            
            obj.stack_ep(chanfcn, detrendartifact, T);
            
            % default to all pulses            
            if ~exist('pulseinds', 'var') || isempty(pulseinds)
                pulseinds = 1:length(obj.pulses);
            end
            pulseinds = ismember(1:length(obj.pulses), pulseinds);  % truncate if necessary
            
            if ~exist('avgonly', 'var') || isempty(avgonly)                
                avgonly = false;
            end
            
            ep = obj.evokedpotentials;            
            
            x = sum(ep(50:end, :).^2, 1);
            thresh = quantile(x, (100 - outlierpct)/100);
            qinds = x < thresh;
            
            if verLessThan('matlab', '9.1')
                y = bsxfun(@minus, [obj.baseline(:, qinds & pulseinds); ep(:, qinds & pulseinds)], median(obj.baseline(:, qinds & pulseinds), 1));
            else
                y = [obj.baseline(:, qinds & pulseinds); ep(:, qinds & pulseinds)] - median(obj.baseline(:, qinds & pulseinds), 1);
            end
            obj.plot_avg_response_(ax, y, obj.sr, avgonly);
            
            if suppressartifact && ~isempty(obj.pulses2)                               
                obj.blank_artifact_with_patch(ax, extendsuppression*1e-3);  % from us to ms
            end
            
            title(obj.repset)
        end
        
        function blank_artifact_with_patch(obj, ax, extension)
            if ~exist('ax', 'var') || isempty(ax) || ~isvalid(ax)
                ax = gca;
            end
            hold(ax, 'on');
            Tp = (obj.pulses2(1) - obj.pulses(1)) / obj.sr * 1000;  % ms
            yl = ylim;
            patch(ax, 'XData', [0, Tp + extension, Tp + extension, 0], ...
                    'YData', yl([1 1 2 2]), ...
                    'FaceColor', [0.5 0.5 0.5], 'FaceAlpha', 0.7);  % 1.0 is opaque
        end
        
        function show_cv_ranges(obj, ax)
            h = -5;
            line_colors = [...
                0.4660, 0.6740, 0.1880;
                0.8500, 0.3250, 0.0980;
                0.4940, 0.1840, 0.5560;
                0.3010, 0.7450, 0.9330
                ];
            %romNums = {'I','II','III','IV'};
            egClasser = {'A','B','C'};
            
            %% Prep the figure
            if ~exist('ax', 'var') || isempty(ax) || ~isvalid(ax)
                ax = gca;
            end
            hold(ax, 'on');
            
            %% Calculations
            dx = obj.params.distbwcuffs*1000; % convert to m
            %pw = obj.params.pulsewidth_us/1000000; % convert to s
            pw = (obj.pulses2(1) - obj.pulses(1)) / obj.sr * 1000;
            
            dt = obj.getFiberTimeWindows;
            for i = 1:length(egClasser)
                % plot(dt(i,:),[h,h],'Color',line_colors(i,:),'LineWidth',5)
                text(mean(dt(i,:)),h-5,egClasser{i},'Color',line_colors(i,:),'HorizontalAlignment','center','FontSize',12,'FontWeight','bold','BackgroundColor','White')
            end
        end
        
        function plot_pulses(obj, ax)
            if ~exist('ax', 'var') || isempty(ax) || ~isvalid(ax)
                figure;ax = gca;
            end
            isholdon = ishold(ax);
            
            % turn hold on if it wasn't on
            if ~isholdon
                hold(ax, 'on');
            end
            
            t = obj.t0 + (obj.n1 + obj.pulses) / obj.sr;
            stem(ax, t/60, ones(size(t)), 'r.-');
            xlabel(ax, 'Time (min)');
            
            % turn off hold if it was off before
            if ~isholdon
                hold(ax, 'off');
            end
        end
        
        function detrend(obj)
            de = @(a, b, c, d, e, x) a + b*exp(c*x) + d*exp(e*x);
            [fitobj, gof, output] = fit(x{1}', y{1}', de, 'MaxFunEvals', 5000, 'MaxIter', 5000);
        end
        
        function plot_physio(obj)
            % This function creates a raw plot of all physiological signals
            % in a given train
            
            figure;
            
            % Raw ECG
            plotwin = [obj.tecg(1) obj.tecg(end)];
            subplot(411)
            plot(obj.tecg, obj.ecg)
            hold on;
            plot(obj.thr, obj.hpks, 'r*')
            axis tight
            xlim(plotwin)
            vline2(obj.tecg(1) + obj.buffertime, {'color','r','linewidth', 5,'linestyle','-'},'Stim start')
            hold on;
            vline2(obj.tecg(1) + obj.buffertime + obj.stimdur, {'color','k','linewidth',5,'linestyle','-'}, 'Stim stop')
            xlabel('Time (s)')
            ylabel('Amplitude')
            title('ECG')
            set(gca,'FontSize',15)
            
            % Heart rate
            subplot(412)
            plot(obj.thr, obj.hr)
            hold on;
            axis tight
            xlim(plotwin)
            vline2(obj.tecg(1) + obj.buffertime, {'color','r','linewidth', 5,'linestyle','-'},'Stim start')
            hold on;
            vline2(obj.tecg(1) + obj.buffertime + obj.stimdur, {'color','k','linewidth',5,'linestyle','-'}, 'Stim stop')
            xlabel('Time (s)')
            ylabel('beats/min')
            title('Heart rate')
            set(gca,'FontSize',15)
            
            % Nose sensor
            subplot(413)
            plot(obj.tresp, obj.resp)
            hold on;
            plot(obj.tbr, obj.bpks, 'r*')
            axis tight
            xlim(plotwin)
            vline2(obj.tresp(1) + obj.buffertime, {'color','r','linewidth', 5,'linestyle','-'},'Stim start')
            hold on;
            vline2(obj.tresp(1) + obj.buffertime + obj.stimdur, {'color','k','linewidth',5,'linestyle','-'}, 'Stim stop')
            xlabel('Time (s)')
            ylabel('Amplitude')
            title('Temperature sensor')
            set(gca,'FontSize',15)
            
            % Breathing rate
            subplot(414)
            plot(obj.tbr, obj.br)
            hold on;
            axis tight
            xlim(plotwin)
            vline2(obj.tresp(1) + obj.buffertime, {'color','r','linewidth', 5,'linestyle','-'},'Stim start')
            hold on;
            vline2(obj.tresp(1) + obj.buffertime + obj.stimdur, {'color','k','linewidth',5,'linestyle','-'}, 'Stim stop')
            xlabel('Time (s)')
            ylabel('breaths/min')
            title('Breathing rate')
            set(gca,'FontSize',15)
%             suptitle(sprintf('Set - ID: %s, polarity = %d, trainnum = %d',
        end

        function features = extract_features(obj,chanfcn, plotflag, detrendartifact, T)
            %% handle inputs
            if nargin < 3
                plotflag = 1;
            end
            
            boundpeaks = 0;
            
            %% Define Constants
            kstdevs = 6;
            markersz = 50;
            extendsuppression = 200;
            outlierpct = 50;
            
            %% Initialize some variables
            if ~exist('detrendartifact', 'var') || isempt(detrendartifact)
                detrendartifact = false;
            end
            if ~exist('T', 'var') || isempty(T)                
                T = 0.005;                
            end
            obj.stack_ep(chanfcn, detrendartifact, T)
            ep = obj.evokedpotentials;       
            
            pulseinds = 1:length(obj.pulses);
            pulseinds = ismember(1:length(obj.pulses), pulseinds);  % truncate if necessary
            
            x = sum(ep(50:end, :).^2, 1);
            thresh = quantile(x, (100 - outlierpct)/100);
            qinds = x < thresh;
                
            if verLessThan('matlab', '9.1')                
                y_all = bsxfun(@minus, [obj.baseline(:, qinds & pulseinds); ep(:, qinds & pulseinds)], median(obj.baseline(:, qinds & pulseinds), 1));
            else
                y_all = [obj.baseline(:, qinds & pulseinds); ep(:, qinds & pulseinds)] - median(obj.baseline(:, qinds & pulseinds), 1);
            end
            
            y = mean(y_all,2); % averaging across all pulses
            t = ((0:length(y)-1) - obj.n1)/obj.sr * 1000;
            
            [nsamples, nsignals] = size(y);
            pw = obj.params.pulsewidth_us/1000;
            
            preStimInds = (1:obj.n1);
            postStimInds = (find(t>pw,1,'first'):nsamples);
                    
            %% Find the fiber time windows from conduction velocities
            timeWin = obj.getFiberTimeWindows;
            
            %% Main function body
            features = [];
            for iisignal = 1:nsignals
                %% Establish a baseline for peak detection
                iibaseline = y(preStimInds,iisignal);
                iiy = y(postStimInds,iisignal);
                iit = t(postStimInds);
                threshold = kstdevs*std(iibaseline);
                
                if plotflag
                    figure; hold on
                    plot(t,y(:,iisignal),'k')
                    obj.blank_artifact_with_patch(gca, extendsuppression*1e-3);  % from us to ms
                    
%                     plot(t(preStimInds),iibaseline,'b')
%                     plot(t(preStimInds),threshold*ones(size(iibaseline)))
                end
                
                %% Detect peaks
                [pkamps,pktimes,pkwidths,pkproms] = findpeaks(iiy,iit,'MinPeakProminence',threshold);
                
                if boundpeaks
                    %% Detect area under peak (using prominence)
                    % Identify the bounds for integration -- find the nearest subthreshold
                    % minima that neighbor the peak
                    area = [];
                    lbound = [];
                    rbound = [];
                    remInd = [];
                    for iipk = 1:length(pktimes)
                        iiamp = pkamps(iipk);
                        iitime = pktimes(iipk);
                        iiprom = pkproms(iipk);
                        
                        t0ind = find(t>= iitime,1,'first');
                        if iipk<length(pktimes)
                            trind = find(t>=pktimes(iipk+1),1,'first');
                        else
                            trind = length(t);
                        end
                        
                        if iipk>1
                            tlind = find(t>=pktimes(iipk-1),1,'first');
                        else
                            tlind = find(t>= pw,1,'first');
                        end
                        
                        tleft = (t0ind:-1:tlind);
                        tright = (t0ind:1:trind);
                        yleft = -(y(tleft,iisignal)-y(tleft(1)));
                        yright = -(y(tright,iisignal)-y(tleft(1)));
                        
                        % TODO: consider using iiprom instead of threshold
                        warning('off','all')
                        ylpks = [];
                        modl = 1;
                        while isempty(ylpks)
                            [~,ylpks]=findpeaks(yleft,'MinPeakHeight',iiprom*modl);
                            modl = modl-.05;
                            if modl <= 0
                                break
                            end
                        end
                        yrpks = [];
                        mod2 = 1;
                        while isempty(yrpks)
                            [~,yrpks]=findpeaks(yright,'MinPeakHeight',iiprom*mod2);
                            mod2 = mod2-.05;
                            if mod2 <= 0
                                break
                            end
                        end
                        warning('on','all')
                        
                        if isempty(ylpks) && max(yleft)==yleft(end)
                            ylpks = length(yleft);
                        end
                        if isempty(yrpks) && max(yright)==yright(end)
                            yrpks = length(yright);
                        end
                        
                        if isempty(ylpks) || isempty(yrpks) %failure to find side limits -- removal due to unlikely to be a real peak
                            % Return to time indices
                            lbound(iipk) = NaN;
                            rbound(iipk) = NaN;
                            area(iipk) = NaN;
                            remInd(end+1) = iipk;
                        else
                            % Return to time indices
                            lbound(iipk) = tleft(ylpks(1));
                            rbound(iipk) = tright(yrpks(1));
                            
                            % lbound = tleft(find(yleft<iiamp-iiprom,1,'first'));
                            % rbound = tright(find(yright<iiamp-iiprom,1,'first'));
                            
                            area(iipk) = sum(y(lbound(iipk):rbound(iipk),iisignal));
                        end
                    end
                    
                    %     for irem = fliplr(iipk)
                    %         pktimes(irem) = [];
                    %         pkamps(irem) = [];
                    %         pkwidths(irem) = [];
                    %         pkproms(irem) = [];
                    %         pkarea(irem) = [];
                    %         lbound(irem) = [];
                    %         rbound(irem) = [];
                    %     end
                    
                    %% Plot the found data
                    
                else
                    for ii = 1:size(timeWin,1)
                        % Return to time indices
                        lbound(ii) = find(t>timeWin(ii,2),1,'first');
                        rbound(ii) = find(t>timeWin(ii,1),1,'first');
                        
                        area(ii) = sum(y(lbound(ii):rbound(ii),iisignal));
                    end
                end
                if plotflag
                    scatter(pktimes,pkamps,markersz,'ro','LineWidth',2);
                    scatter(t(lbound),y(lbound,iisignal),markersz,'bx','LineWidth',2)
                    scatter(t(rbound),y(rbound,iisignal),markersz,'bx','LineWidth',2)
                    title(obj.repset)
                    obj.show_cv_ranges
                end
                
                %% Output peaks
                features.pktimes = pktimes';
                features.pkamps = pkamps;
                features.pkwidths = pkwidths';
                features.pkproms = pkproms;
                features.area = area';
                features.lbound = lbound';
                features.rbound = rbound';
            end
        end
        
        function timeWindows = getFiberTimeWindows(obj)
            dx = obj.params.distbwcuffs*1000; % convert to m
            pw = (obj.pulses2(1) - obj.pulses(1)) / obj.sr * 1000;
            egClasser = {'A','B','C'};
            
            cv = [];
            timeWindows = [];
            for i = 1:length(egClasser)
                cv(i,:) = getcvrange(egClasser{i}); % in m/s
                timeWindows(i,:) = pw + (dx./cv(i,:))/1000; % in ms
            end
        end
    end
    
    methods (Access = private)
        function plot_avg_response_(obj, ax, y, sr, avgonly)
            if ~exist('ax', 'var') || isempty(ax) || ~isvalid(ax)
                figure;ax = gca;
            end
            
            meany = mean(y, 2);
            stdy = std(y, 0, 2);
            
            pct = 0.95;
            c = norminv((1 + pct)/2);
            
            t = ((0:length(meany)-1) - obj.n1)/sr * 1000;  % ms
            
            firstplot = isempty(findobj(ax, 'Type', 'Patch'));
            
            if isempty(obj.col)
                if obj.pol == -1
                    obj.col = [0 0 1];
                elseif obj.pol == 1
                    obj.col = [1 0 0];
                else
                    obj.col = [0 1 0];
                end
            end
            
            if ~avgonly
                % new patches don't clear the axes like plots do
                patch(ax, 'XData', t([1:end end:-1:1 1]), ...
                    'YData', [meany + c*stdy; flipud(meany - c*stdy); meany(1) + c*stdy(1)], ...
                    'FaceColor', obj.col, 'FaceAlpha', 0.5);
            end
            hold(ax, 'on');plot(ax, t, meany, 'Color', obj.col, 'LineWidth', 2);hold(ax, 'off');
            xlabel(ax, 'Time (ms)');ylabel(ax, 'Voltage (\muV)');
            
            % set ylim symmetric based on max(abs()) after stim
            if ~isempty(obj.pulses2)
                Tp = 3 * (obj.pulses2(1) - obj.pulses(1)) / obj.sr * 1000;  % in ms
            else
                Tp = 0.005 * 1000;                                          % in ms
            end
            
            inds = t > Tp;
            maxy = max(abs([meany(inds) + c*stdy(inds); flipud(meany(inds) - c*stdy(inds))]));
            if firstplot
                ylim([-maxy, maxy]);                
            else                
                yl = ylim;
                if maxy > max(abs(yl))
                    ylim([-maxy, maxy]);
                end
            end
             xlim([-obj.n1 / obj.sr * 1000, obj.n2 / obj.sr * 1000]);  % ms
        end
        
        function plot_all_responses_(obj, ax, y, sr)
            if ~exist('ax', 'var') || isempty(ax) || ~isvalid(ax)
                figure;ax = gca;
            end
            
            t = ((0:size(y, 1)-1) - obj.n1)/sr * 1000;  % in ms
            
            firstplot = isempty(findobj(ax, 'Type', 'Line'));
            
            % interpolate hsv to rgb for each polarity to show time
            if isempty(obj.col)
                if obj.pol == -1
                    obj.col = [0 0 1];  % convert blue to hsv for negative polarity
                elseif obj.pol == 1
                    obj.col = [1 0 0];  % convert red to hsv for positive polarity
                else
                    obj.col = [0 1 0];  % convert green to hsv for unknown polarities
                end
            end
            hsv_ = rgb2hsv(obj.col);
            cols = hsv2rgb([repmat(hsv_(1:2), [size(y, 2) 1]) linspace(0.25, 1, size(y, 2))']);
            set(ax, 'ColorOrder', cols);
            
            hold(ax, 'on'); % hold on keeps color order
            plot(ax, t, y);
            hold(ax, 'off');
            xlabel(ax, 'Time (ms)');ylabel(ax, 'Voltage (\muV)');
            
            % set ylim symmetric based on max(abs()) after stim
            if ~isempty(obj.pulses2)
                % This heuristic is fine, I don't need to use the extension to calculate Tp
                Tp = 3 * (obj.pulses2(1) - obj.pulses(1)) / obj.sr * 1000;  % in ms
            else
                Tp = 0.005 * 1000;                                          % in ms
            end
            
            inds = t > Tp;
            maxy = max(max(abs(y(inds, :))));
            if firstplot
                ylim([-maxy, maxy]);                
            else                
                yl = ylim;
                if maxy > max(abs(yl))
                    ylim([-maxy, maxy]);
                end
            end
            xlim([-obj.n1 / obj.sr * 1000, obj.n2 / obj.sr * 1000]);
        end
    end
end