function read_intan_batch(rhsdirs, applynotch, filenames, connectedchannels)
% rhsdirs = {'C:\Users\CBEM_NDDA_L1\Dropbox\GE Rat Recordings\IL-1 Recordings\GE_Rat_IL1_1_7-29-17', ...
%            'C:\Users\CBEM_NDDA_L1\Dropbox\GE Rat Recordings\IL-1 Recordings\GE_Rat_IL1_2_7-30-17', ...
%            'C:\Users\CBEM_NDDA_L1\Dropbox\GE Rat Recordings\Test recordings_Intan-CorTec\Mouse_Intan_CorTec_7-25-17', ...
%            'C:\Users\CBEM_NDDA_L1\Dropbox\GE Rat Recordings\TNF Recordings\GE Rat TNF_1_7-27-17'};
% savedirs = {'C:\Users\CBEM_NDDA_L1\Documents\GE Rat Recordings\IL-1 Recordings\GE_Rat_IL1_1_7-29-17', ...
%            'C:\Users\CBEM_NDDA_L1\Documents\GE Rat Recordings\IL-1 Recordings\GE_Rat_IL1_2_7-30-17', ...
%            'C:\Users\CBEM_NDDA_L1\Documents\GE Rat Recordings\Test recordings_Intan-CorTec\Mouse_Intan_CorTec_7-25-17', ...
%            'C:\Users\CBEM_NDDA_L1\Documents\GE Rat Recordings\TNF Recordings\GE Rat TNF_1_7-27-17'};
% fileformat = 'rhs';

if ~iscellstr(rhsdirs)
    rhsdirs = {rhsdirs};
end
% rhsdirs = {'Z:\United Therapeutics\Exp_05.18.18(R.VNS_rostral stim)\intan recordings'};

savedirs = rhsdirs;
fileformat = 'rhs';
       
sr = 30e3;
[b, a] = butter(2, [10 5000]/(sr/2), 'bandpass');
       
for idir = 1:length(rhsdirs)
    D = dir(sprintf('%s\\*.%s', rhsdirs{idir}, fileformat));
    for ifile = 1:length(D)        
        filename = sprintf('%s\\%s', rhsdirs{idir}, D(ifile).name);
        if exist('filenames', 'var') && ~isempty(filenames) && ~ismember(filename, filenames)
            continue
        end
        
        savefile = sprintf('%s\\%s', savedirs{idir}, strrep(D(ifile).name, sprintf('.%s', fileformat), '.mat'));
        % if exist(savefile, 'file')
        %     continue
        % end
        fprintf('converting %s...\n', filename);
        
        switch fileformat
            case 'rhd'
                [t, amplifier_data, metadata] = read_Intan_RHD2000_file(filename);        
            case 'rhs'
                metadata = [];
                [notes, frequency_parameters, stim_parameters, reference_channel, ...
                    amplifier_channels, amplifier_data, dc_amplifier_data, stim_data, ...
                    amp_settle_data, charge_recovery_data, compliance_limit_data, t, ...
                    spike_triggers, board_adc_channels, board_adc_data, board_dac_channels, ...
                    board_dac_data, board_dig_in_channels, board_dig_in_data, board_dig_out_channels, ...
                    board_dig_out_data] = read_Intan_RHS2000_file(filename, applynotch);
                vars = {'notes', 'frequency_parameters', 'stim_parameters', 'reference_channel', ...
                    'amplifier_channels', 'amplifier_data', 'dc_amplifier_data', 'stim_data', ...
                    'amp_settle_data', 'charge_recovery_data', 'compliance_limit_data', 't', ...
                    'spike_triggers', 'board_adc_channels', 'board_adc_data', 'board_dac_channels', ...
                    'board_dac_data', 'board_dig_in_channels', 'board_dig_in_data', 'board_dig_out_channels', ...
                    'board_dig_out_data'};
                % convert doubles to singles
                for ii = 1:length(vars)
                    if isa(eval(vars{ii}), 'double')
                        eval(sprintf('%s = single(%s);', vars{ii}, vars{ii}));
                    end
                end
                
                save(savefile, vars{:}, '-v7.3');
                continue
        end
        
        y = single(amplifier_data');  % single(filtfilt(b, a, amplifier_data'));
        t0 = t(1);
        dt = t(2) - t(1);
        sr = round(1/dt);
        if sr ~= 30e3
            disp([idir ifile sr]);
        end
        % y1 = amplifier_data(1, :);
        if ~exist(savedirs{idir}, 'dir')
            mkdir(savedirs{idir});
        end
        fprintf('saving %s...\n', savefile);
        save(savefile, 'sr', 't0', 'dt', 'y', 'metadata');
        fprintf('\n');
        % inds = 1:min(length(t), 1e5);
        % figure;plot(t(inds), [y1(inds)' amplifier_data(1, inds)']);
        % title(sprintf('%d %d', idir, ifile));
        clear('t', 'y1', 'amplifier_data');
    end
end