%% emg

function [EMG] = fun_get_EMG(experdir)
% , Afiber, Bfiber, Cfiber
    dd = dir([experdir]);
    dd = {dd.name};
    for j = 1:length(dd)
        try
            A = load([experdir  '\' dd{j}]);
            
            t = (0:length(A.avg_CAP)-1)/30-1;
            figure
%             for i=1:length(A.avg_CAP(1, :)); plot(t, i*100+A.avg_CAP(:,i)); hold on; end
            for i=1:length(A.avg_CAP(1, :)); plot(t, A.avg_CAP(:,i)); hold on; end

%             xlim([2.5 6])
            EMG_cap = A.avg_CAP(t>3 & t < 6 , :);
            minPeak = min(EMG_cap,[], 1);
            maxPeak = max(EMG_cap,[], 1);
            EMGpk2pk = maxPeak-minPeak;
            EMG(A.sort_dur_set_id, 1) = EMGpk2pk;
      
            fields = fieldnames(A);
        catch
                continue
        end
%             for f = 1:length(fields)
%                 switch fields{f}
%                     case contains(fields{f}, 'us_A')
%                         Afiber(A.sort_dur_set_id, 1)  = A.(fields{f});
%                     case contains(fields{f}, 'us_B')
%                         Bfiber(A.sort_dur_set_id, 1)  = A.(fields{f});
%                     case contains(fields{f}, 'us_C')
%                         Cfiber(A.sort_dur_set_id, 1)  = A.(fields{f});
%                 end
%                 
            end
%         
    end
% end



%%
% if contains(dd{j}, 'ABC')
%                 fields = fieldnames(A);
%                 for f = 1:length(fields)
%                     switch fields{f}
%                         case contains(fields{f}, 'A')
%                             T.Afiber(A.sort_dur_set_id)  = A.(fields{f})
%                     end
%                     
%                 end
%                
%                 
%             else