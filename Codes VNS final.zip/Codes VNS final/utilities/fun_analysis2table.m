function[Ti, curve, repset] = fun_analysis2table(H,ecg_rel, bre_rel, t_train_phy, tph, ifplot )
    

t0 = H.t0;
    
    [~, posphy] = (min(abs(t_train_phy-t0)));
    trphy = t_train_phy(posphy);
    param = H.params; param.pol = H.pol; 
%     [param] = adjust_param(H, param, pol , els);
  
 

    Tm = 10 ; Tp = 15;
    idx_t_train = find(tph >= trphy-Tm & tph < trphy+param.duration_s+Tp);
   
    breath_train = bre_rel.breath{1}(idx_t_train, :);
    ecg_train = ecg_rel.ecg{1}(idx_t_train, :);

    
    br_train = bre_rel.br{1}((bre_rel.br{1}(:, 1) >= trphy-Tm & bre_rel.br{1}(:, 1) < trphy+param.duration_s+Tp), :);
    pk2pk_train = bre_rel.pk2pk{1}((bre_rel.pk2pk{1}(:, 1) >= trphy-Tm & bre_rel.pk2pk{1}(:, 1) < trphy+param.duration_s+Tp), :);
    idx_pk = (bre_rel.pk2pk{1}(:, 1) >= trphy-Tm & bre_rel.pk2pk{1}(:, 1) < trphy+param.duration_s+Tp);

    hr_train = ecg_rel.hr{1}((ecg_rel.hr{1}(:, 1) >= trphy-Tm & ecg_rel.hr{1}(:, 1) < trphy+param.duration_s+Tp), :);
    
    curve.ecg_breath = [ecg_train(:, 1)-trphy ecg_train(:, 2) breath_train(:, 2)];
curve.hr = [hr_train(:, 1)-trphy hr_train(:, 2)];
curve.br = [br_train(:, 1)-trphy br_train(:, 2)];
curve.pk2pkbr = [pk2pk_train(:, 1)-trphy pk2pk_train(:, 2)];

%% cre funct con tutto
if ifplot
    figure; n = 5;
h2 = subplot(n, 1, 1); plot(ecg_train(:, 1)-trphy, ecg_train(:, 2)); ylabel('ecg')

title(['setID = ' H.repset ' - freq = ' num2str(param.freq_Hz) ...
                        '; pol = ' num2str(param.pol) '; amp = ' num2str(param.amp) ...
                        '; pw = ' num2str(param.pulsewidth_us) ...
                        '; FT = ' num2str(param.FT)])
                    
h3 = subplot(n, 1, 2); plot(breath_train(:, 1)-trphy, breath_train(:, 2)); ylabel('nasal sensor')
hold on, plot(bre_rel.cop_loc{1}(idx_pk, 1)-trphy, bre_rel.cop_pks{1}(idx_pk, 1), '*r'),
hold on, plot(bre_rel.cop_loc{1}(idx_pk, 2)-trphy, bre_rel.cop_pks{1}(idx_pk, 2), '*k')

h4 = subplot(n, 1, 3); plot(hr_train(:, 1)-trphy, hr_train(:, 2));ylabel('hr'), hold on
h5 = subplot(n, 1, 4); plot(br_train(:, 1)-trphy, br_train(:, 2));ylabel('br')
h6 = subplot(n, 1, 5); plot(pk2pk_train(:, 1)-trphy, pk2pk_train(:, 2)); xlabel('s'), ylabel('pk to pk br')
linkaxes([h2 h3 h4 h5 h6], 'x')

end

repset = H.repset;

%% ecg
sec_pre = 10; sec_post = 10; 
[ idx_pre] =(curve.hr(:, 1)< 0 & curve.hr(:, 1)  > -sec_pre);
[idx_dur] = (curve.hr(:, 1) > 0 & curve.hr(:, 1) < param.duration_s);
[idx_post] = (curve.hr(:, 1) > param.duration_s & curve.hr(:, 1) < param.duration_s + sec_post);

mean_hr_pre = mean(curve.hr(idx_pre, 2));
mean_hr_dur = mean(curve.hr(idx_dur, 2));
mean_hr_durHalf = mean(curve.hr(idx_dur(1:end/2), 2));

mean_hr_post = mean(curve.hr(idx_post, 2));
curv_post_stim = curve.hr([idx_dur | idx_post], :);
[ min_hr_dur, idx_min,] = min(curv_post_stim(:, 2));
Tmin = curv_post_stim(idx_min, 1);

[coeffvals_stim, tilp, x_line] = fun_exponent_fit(curve.hr(:, 1), curve.hr(:, 2), param.duration_s);
if ifplot
try
subplot(n, 1, 3); plot(x_line, feval(tilp, x_line));ylabel('hr')
catch
end
end


%%
% %% compute error
%     
%     cu = curve.hr(:, 2);
%     dd = curve.hr(curve.hr(:, 1)>=0, : );
%     try
%         ERR_exp = rms(cu - feval(tilp,dd(1:length(cu))));
%     catch
%         ERR_exp = NaN;
%     end
%     try
%         ERR_mean{s}( 1, : ) = rms(cu - mean_durHR{s}(1)*ones(length(cu), 1));
%     catch
%         ERR_mean{s}( 1, : ) = NaN;
%     end
%     try
%         ERR_min{s}( 1, : ) = rms(cu - val_min*ones(length(cu), 1));
%     catch
%         ERR_min{s}( 1, : ) = NaN;
%     end
%     cu_post = HR_sm(end_point(1)+1:end_point(1)+N);
%     try
%         
%         ERR_meanPost{s}( 1, : ) = rms(cu_post - mean_postHR{s}(1)*ones(length(cu_post), 1));
%     catch
%         ERR_meanPost{s}( 1, : ) = NaN;
%     end
%     try
%         dd = T(T>=0);
%         ERR_sigmPost{s}( 1, : ) = rms(cu_post - feval(tilp_rec, dd(2:1+length(cu_post))));
%     catch
%         ERR_sigmPost{s}( 1, : ) = NaN;
%     end
%%


[coeffvals_rec, tilp, x_line] = fun_recovery_fit(curve.hr(:, 1), curve.hr(:, 2), param.duration_s, sec_post+param.duration_s, 'sigmo');
if ifplot
try
subplot(n, 1, 3); plot(x_line+param.duration_s, feval(tilp, x_line));ylabel('hr')
catch
end
end


%% breath
N = 6; sec_pre = 10; sec_post = 10; 
[ idx_pre] =(curve.br(:, 1)< 0 & curve.br(:, 1)  > -sec_pre);
[idx_dur] = (curve.br(:, 1) > 0 & curve.br(:, 1) < param.duration_s);
[idx_post] = (curve.br(:, 1) > param.duration_s & curve.br(:, 1) < param.duration_s + sec_post);

mean_br_pre = mean(curve.br(idx_pre, 2));
mean_br_dur = mean(curve.br(idx_dur, 2));
mean_br_post = mean(curve.br(idx_post, 2));

curvpkpre = curve.pk2pkbr(curve.pk2pkbr(:, 1) < 0 , :);

% mean_pk_pre = mean(curve.pk2pkbr(end-N:end-1, 2));
try
mean_pk_pre = mean(curvpkpre(end-N:end, 2));
catch
    mean_pk_pre = mean(curvpkpre(:, 2));
end

try

curvpkplusonesec = curve.pk2pkbr(curve.pk2pkbr(:, 1) > 1 , :);
pk0 = curvpkplusonesec(1, 2);

[~, idx] = min(abs(curve.br(:, 1)));
if idx <= N
    N2 = idx-1;
else N2 = N;
end

int0 = diff(curve.br(idx:idx+1, 1));
mean_int_pre = mean(diff(curve.br(idx-N2:idx-1, 1))); 


[~, idx] = min(abs(curve.pk2pkbr(:, 1)));
[~, idx10] = min(abs( curve.pk2pkbr(:, 1)-10 ));

if curve.pk2pkbr(idx, 1)>0; idx = idx-1; end

% try
Nbeat_dur = length(curve.pk2pkbr(idx+1:idx10, 1))/param.duration_s;
% catch
%     Nbeat_dur = length(curve.pk2pkbr(idx10, 1))/param.duration_s;
% 
% end
Nbeat_pre10 = length(curve.pk2pkbr(1:idx, 1))/10; 



catch
    br_train = bre_rel.br{1}((bre_rel.br{1}(:, 1) >= trphy-Tm), :);
    pk2pk_train = bre_rel.pk2pk{1}((bre_rel.pk2pk{1}(:, 1) >= trphy-Tm), :);
    br = [br_train(:, 1)-trphy br_train(:, 2)];
    pk2pkbr = [pk2pk_train(:, 1)-trphy pk2pk_train(:, 2)];

curvpkplusonesec = pk2pkbr(pk2pkbr(:, 1) > 1 , :);
pk0 = curvpkplusonesec(1, 2);

[~, idx] = min(abs(br(:, 1)));
if idx <=N
    N2 = idx-1;
else; N2 = N;
end

int0 = diff(br(idx:idx+1, 1));
mean_int_pre = mean(diff(br(idx-N2:idx-1, 1))); 


end

if ifplot
subplot(n, 1, 5); title([num2str((pk0-mean_pk_pre)/mean_pk_pre) ])
end



if ifplot
subplot(n, 1, 4); title([num2str(int0-mean_int_pre) ])
end


% put data togh in table
Ti = table;
% Ti.setid = hut.trains{1}(j).repset;
Ti.amp = param.amp;
Ti.freq = param.freq_Hz;
Ti.pw = param.pulsewidth_us;
Ti.pol = param.pol;
Ti.FT = param.FT;
Ti.dur = param.duration_s;
Ti.HRpre = mean_hr_pre; Ti.HRdur = mean_hr_dur; Ti.mean_hr_durHalf = mean_hr_durHalf; Ti.HRpost = mean_hr_post; Ti.HRmin = min_hr_dur; Ti.Tmin = Tmin;
Ti.BRpre = mean_br_pre; Ti.BRdur = mean_br_dur; Ti.BRpost = mean_br_post;
Ti.pk0 = pk0; Ti.meanPKpre = mean_pk_pre; Ti.int0 = int0; Ti.meanINTpre = mean_int_pre;
Ti.B = coeffvals_stim(1); Ti.A = coeffvals_stim(2); Ti.tau = coeffvals_stim(3);
Ti.Arec = coeffvals_rec(2); Ti.arec = coeffvals_rec(1); Ti.taurec = coeffvals_rec(3); Ti.Brec = coeffvals_rec(4);
Ti.Nbeat_dur = Nbeat_dur;
Ti.Nbeat_pre10 = Nbeat_pre10;
Ti.repset = {repset};



%% compute error
    
  


