function bre_rel = generate_resprate(hut, minpeakprompos, minpeakpromneg, smoothvar, plotvar, method)
% Identify resp channel, detect inhalation peaks and compute
% respiratory rate
bre_rel = struct;
phy = hut.physdata;
% Identify resp channel
if ~exist('minpeakprom','var') || isempty(minpeakprompos), minpeakprompos = 0.05; end
chan_names = {phy.channel_meta(:).name};
respidx = cell2mat(cellfun(@(x) contains(x, 'Resp', 'IgnoreCase',true) || contains(x, 'Nasal', 'IgnoreCase',true), chan_names, 'un',0));
respchan = find(respidx);
phy.respid = respchan;
numrecords = phy.file_meta.n_records;
phy.breath_params = repmat(struct('mindist', 0, 'minpeakprom', 0, 'smoothvar', 0), [1 numrecords]);

for rec = 1:numrecords
    % Get sampling rate of ECG channel
    chan_dt = [phy.channel_meta(respchan).dt];
    resp_sr = round(1/chan_dt(rec));
    
    % Assign ECG channel
    eval(sprintf('phy.resp{%d,1} = double(phy.data__chan_%d_rec_%d);', rec, respchan, rec));
    
    % High pass filter signal to remove movement artifacts
    [b,a] = butter(2, 0.1/(resp_sr/2), 'high');
    filt_resp = filtfilt(b, a, phy.resp{rec,1});
    filt_resp_smooth = smooth(filt_resp, smoothvar);
    
    % Detect peaks
    maxbr = 120; % 120 breaths per min
    mindist = 1/(maxbr/60)*80/100;
    t = linspace(0, numel(phy.resp{rec,1})/resp_sr, numel(phy.resp{rec,1}));
    
    %                 switch method
    [pks_pos, locs_pos] = findpeaks(filt_resp_smooth, t, 'MinPeakDistance', mindist, 'MinPeakProminence', minpeakprompos, 'MinPeakHeight', 0);
    [pks_neg, locs_neg] = findpeaks(-filt_resp_smooth, t, 'MinPeakDistance', mindist, 'MinPeakHeight', minpeakpromneg);
    pks_neg = -pks_neg;
    try
    switch method
        case 'pos2neg'
            
            cop_loc = []; cop_pks = [];
            for i = 1:length(locs_pos)-1
                id_next = find(locs_neg>locs_pos(i) & locs_neg<locs_pos(i+1));
                if ~isempty(id_next)
                    cop_loc = [cop_loc; locs_pos(i) locs_neg(id_next(1))   ];
                    cop_pks = [cop_pks; pks_pos(i) pks_neg(id_next(1))   ];
                end
            end
            
            idxdd = ((cop_loc(:,2) - cop_loc(:,1))>2);
            cop_loc(idxdd, :) = [];
            cop_pks(idxdd, :) = [];
            
            
            pk2pk = cop_pks(:, 1)-cop_pks(:, 2);
            br_pos = 60./diff(cop_loc(:, 1));
            br_neg = 60./diff(cop_loc(:, 2));
            
        case 'neg2pos'
            cop_loc = []; cop_pks = [];
            for i = 1:length(locs_neg)-1
                id_next = find(locs_pos>locs_neg(i) & locs_pos<locs_neg(i+1));
                if ~isempty(id_next)
                    cop_loc = [cop_loc; locs_neg(i) locs_pos(id_next(1))   ];
                    cop_pks = [cop_pks; pks_neg(i) pks_pos(id_next(1))   ];
                end
            end
            
            idxdd = ((cop_loc(:,2) - cop_loc(:,1))>2);
            cop_loc(idxdd, :) = [];
            cop_pks(idxdd, :) = [];
            
            
            pk2pk = -cop_pks(:, 1)+cop_pks(:, 2);
            br_neg = 60./diff(cop_loc(:, 1));
            br_pos = 60./diff(cop_loc(:, 2));
    end
    
    if plotvar
        figure,
        l1 = subplot(311); plot(t, filt_resp_smooth), hold on,  plot(locs_pos, pks_pos, 'r*'); hold on, plot(locs_neg, pks_neg, 'k*');
        l2 = subplot(312); plot(mean(cop_loc, 2), pk2pk), title('peak to peak')
        l3 = subplot(313); plot(cop_loc(2:end, 2), br_pos), hold on ; plot(cop_loc(2:end, 1), br_neg);
        title('breathing rate')
        linkaxes([l1 l2 l3], 'x')
    end
    
    if isempty(locs_neg)
        disp('Did not detect any respiratory peaks, skipping record')
        continue
    end
    
    bre_rel.breath{rec} = [t' filt_resp_smooth];
    bre_rel.cop_loc{rec} = cop_loc;
    bre_rel.cop_pks{rec} = cop_pks;
    
    
    bre_rel.breath_params(rec) = struct('minpeakprom',[minpeakprompos minpeakpromneg], 'mindist',mindist, 'smoothvar',smoothvar, 'method', method);
    bre_rel.pk2pk{rec} = [mean(cop_loc, 2)  pk2pk];
    bre_rel.br{rec} = [cop_loc(2:end, 1) br_neg];
    
    
    catch
        continue
end
    
end
end