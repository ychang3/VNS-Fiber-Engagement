function ecg_rel = gererate_heartrate(hut, method, minpeakprom, mindist, plotvar)
            % Identify ECG channel, detect QRS complexes and compute heart
            % rate
            ecg_rel = struct;
            phy = hut.physdata;
            % Identify ECG channel
            try
            chan_names = {phy.channel_meta(:).name};
            catch
                 chan_names = {phy(1).channel_meta(:).name};
            end
            
             
            ecgidx = cell2mat(cellfun(@(x) contains_(x, 'ECG'), chan_names, 'un',0));
            ecgchan = find(ecgidx);
            phy.ecgid = ecgchan;
            numrecords = phy.file_meta.n_records;
            [phy.hr, phy.thr] = deal([]);
            phy.ecg_params = repmat(struct('mindist', 0, 'minpeakprom', 0), [1 numrecords]);
            hmsg = MessageUpdater();
            for rec = 1:numrecords
                % Get sampling rate of ECG channel
                chan_dt = [phy.channel_meta(ecgchan).dt(rec)];
                if isnan(chan_dt)
                    continue
                end
                ecg_sr = round(1/chan_dt);
                phy.ecg{rec, 1} = double(phy.(sprintf('data__chan_%d_rec_%d', ecgchan, rec)));
                
                % eval(sprintf('obj.ecg{%d,1} = double(obj.data__chan_%d_rec_%d);', rec, ecgchan, rec));
                %             eval(sprintf('obj.data__chan_%d_rec_1 = [];', ecgchan));
                
                % High pass filter signal to remove movement artifacts
                [b,a] = butter(2, 0.1/(ecg_sr/2), 'high');
                filt_ecg = filtfilt(b, a, phy.ecg{rec});  %%%%%%%%%%%%%%%%%%%%%%%%%
                [b,a] = butter(2, 50/(ecg_sr/2), 'low');
                filt_ecg = filtfilt(b, a, filt_ecg);
                
                % Detect peaks
                if ~exist('mindist', 'var') || isempty(mindist)
                    maxhr = 500; % 500 beats per min
                    mindist = 1/(maxhr/60);
                end
                t = linspace(0, numel(phy.ecg{rec})/ecg_sr, numel(phy.ecg{rec}));
                 switch method
                    case 'template'
                        % Find template of ECG - QRS complexes
                        temp_locs = find(ismember(t,locs(locs < 10))); % Get location of ECG peaks less than 10 seconds
                        numsamples = 100;
                        temp_locs = temp_locs(temp_locs > numsamples);
                        gen_inds = arrayfun(@(x) x-numsamples:x+numsamples, temp_locs, 'un',0);
                        template_inds = vertcat(gen_inds{:});
                        conv_ecg = mean(filt_ecg(template_inds));
                        cpdt = conv(filt_ecg, conv_ecg);
                        
                    case 'negpeak'
                         [pks, locs] = findpeaks(-filt_ecg, t, 'MinPeakDistance', mindist, 'MinPeakProminence', minpeakprom);  %%%%%%%%%%%%%%
                         pks = -pks;
                         
                     case ''
                         [pks, locs] = findpeaks(filt_ecg, t, 'MinPeakDistance', mindist, 'MinPeakProminence', minpeakprom);  %%%%%%%%%%%%%%
                 end
  
             if isempty(locs)
                    continue
                end
                
                ibi = diff(locs); % inter-beat-interval
                phy.hr{rec} = 60./[0 ibi]; % heart rate
                diffhr = diff([0 phy.hr{rec}]);
                hr = 60./[0 ibi];
                % Correct spuriously detected peaks
                diffthresh = 150;
                counter = 0;
                
                while sum(abs(diffhr > diffthresh)) > 0 && counter < 10000
                    counter = counter + 1;
                    msg = sprintf('Correcting heart rate for %d points..', sum(abs(diffhr > 35)));
                    hmsg.update_message(msg);                    
                    excinds = find(diffhr > diffthresh | diffhr < -diffthresh);
                    numpoints = min([10, excinds(1)-1]);
                    %numpoints = cell2mat(arrayfun(@(x) min([10, x]), excinds, 'un',0));
                    phy.hr{rec}(excinds(1)) = nanmean(phy.hr{rec}(excinds(1)- numpoints: excinds(1) - 1));
                    diffhr = diff([0 phy.hr{rec}]);
                    excinds = find(diffhr > diffthresh | diffhr < -diffthresh);
                end
                
                diffhr = diff([0 phy.hr{rec}]);
                
                % print warning message about uncorrected spurious peaks
                if sum(abs(diffhr > diffthresh)) > 0
                    warning('%d spurious detections in ECG uncorrected...', sum(abs(diffhr > diffthresh)));
                end
                
                % Peak detection figure
                if plotvar
                    figure;
                    ax1 = subplot(311);
                    reduce_plot(t, filt_ecg);  %%%%%%%%%%%%%%%%%%%%%
%                     plot(t, filt_ecg);
                    hold on;
                    reduce_plot(locs, pks, 'r*');
%                     plot(locs, pks, 'r*');
                    ax2 = subplot(312);
                    plot(locs, phy.hr{rec});
                    ax3 = subplot(313);
                    plot(locs, diffhr)
                    linkaxes([ax1, ax2, ax3], 'x');
                end
                
                phy.thr{rec} = locs;
                phy.hpks{rec} = phy.ecg{rec}(ismember(t, locs));
                phy.ecg_params(rec) = struct('mindist',mindist, 'minpeakprom',minpeakprom);
            
               
            ecg_rel.ecg{rec} = [t' filt_ecg(:)];
            ecg_rel.hr{rec} = [locs' [0; hr(2:end)']];
            ecg_rel.ecg_params{rec} =  phy.ecg_params(rec);
            
            end
            clear hmsg
            
            
        end