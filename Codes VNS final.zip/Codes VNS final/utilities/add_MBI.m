% add column to TBL_neu with MBI
close all
clear all

% addpath('C:\Users\Subash\Dropbox\MATLAB\intananalysisMarina\slaves_plus')
plotvar = 1;
% pw_tot = [60 100  300];
pp = pwd; pp = pp(1:end-20);
excelfile = [pp '\dati\Exp_fibers_spec.xlsx'];
plotdiff = 0;
[Aex, bex, cex] = xlsread(excelfile, num2str(100));
bex = bex(2:end, :); cex = cex(2:end, :);
y_tot = [1:length(bex)]; % number of the raw with the file you want to analyze in the excel file

for y = 1:length(bex(:,1))
    direc = [pp '\dati\'];
    freq = 30;
    fold = cex{y};
    experimentdir  = [direc fold(1:end-1)];
    load([experimentdir '\physio_all.mat'])
    load([experimentdir '\TBL_neu.mat'])
    load([experimentdir '\curve_tot.mat'])
 
    clear maxInt0 meanInt0
    for i = 1:length(curve_tot)
        curve = curve_tot{i};
        %% breath
        N = 6; sec_pre = 10; sec_post = 10;
        [ idx_pre] =(curve.br(:, 1)< 0 & curve.br(:, 1)  > -sec_pre);
        [idx_dur] = (curve.br(:, 1) > 0.5 & curve.br(:, 1) < 10);
        [idx_post] = (curve.br(:, 1) > 10 & curve.br(:, 1) < 10 + sec_post);
 
      
        chi_10 = curve.pk2pkbr ( curve.pk2pkbr(:, 1)>-1 & curve.pk2pkbr(:, 1) < 11, 1);
        
        
        if length(chi_10) > 2
             [maxInt0i, idx] = max(diff(chi_10));
              meanInt0i = mean(diff(chi_10, 1));
        
        else
             chi_pos = curve.pk2pkbr ( curve.pk2pkbr(:, 1)>-1, 1);
            [maxInt0i, idx] = max(diff(chi_pos));
            
            if maxInt0i < 10
                meanInt0i = mean(diff(chi_pos(1:idx+1), 1));
            elseif isempty(maxInt0i)
                maxInt0i = 20;
                meanInt0i = maxInt0i;
            else
                meanInt0i = maxInt0i;
            end
            
        end
      
        
        maxInt0(i,1) = maxInt0i;
        meanInt0(i,1) = meanInt0i;
        
        
    end 
    TBL_neu.maxInt0 = maxInt0;
    TBL_neu.meanInt0 = meanInt0;
    
    save([experimentdir '\TBL_neu2.mat'], 'TBL_neu');
end

