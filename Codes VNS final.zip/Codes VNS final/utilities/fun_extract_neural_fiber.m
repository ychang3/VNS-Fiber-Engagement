function[Afiber, Bfiber, Cfiber, EMG] = fun_extract_neural_fiber(neu, curve, Tselo, rangeA, rangeB, rangeC, tmin, physio)

pw = Tselo.pw(1);
amp = Tselo.amp;
tv = (0:length(neu.avg_CAP(:, 1))-1)/30-1;
figure;
for ii = 1:length(neu.avg_CAP(1, :))
    if physio
    subplot(121),
    end
    plot(tv, 100*ii+neu.avg_CAP(:, ii), 'linewidth', 1);  hold on
end
set(gca, 'Fontsize', 16)
xlabel('time (ms)'), ylabel('Thresh. x')
yticks([100*(1:length(neu.avg_CAP(1, :)))]); yticklabels(amp)

% EMG
tEMG = [2 6]; idxEMG = find(tv>tEMG(1) & tv<tEMG(2) );
[minEMG, idxminEMG] = min(neu.avg_CAP(idxEMG, :)); idxminEMG  = idxminEMG+idxEMG(1)-1;
[maxEMG, idxmaxEMG] = max(neu.avg_CAP(idxEMG, :)); idxmaxEMG  = idxmaxEMG+idxEMG(1)-1;
EMG = maxEMG'-minEMG';


% fibers
idxmin = find(tv>tmin(1) & tv<tmin(2) );
[minval, idxminval] = min(neu.avg_CAP(idxmin, :)); idxminval  = idxminval+idxmin(1)-1;

[~, idxAestr1] = min(abs(tv-rangeA(1)));  
[A1, idxA1] = max(neu.avg_CAP(idxAestr1:idxminval, :)); idxA1  = idxA1+idxAestr1-1;

[~, idxBestr2] = min(abs(tv-rangeB(2)));  
[B2, idxB2] = max(neu.avg_CAP(idxminval:idxBestr2, :)); idxB2  = idxB2+idxminval;

Afiber = A1'-minval';
Bfiber = B2'-minval';

[idxC] = find(tv>=rangeC(1)+2 & tv<=rangeC(2));  
[C1, idxC1] = max(neu.avg_CAP(idxC, :)); idxC1 = idxC1+idxC(1)-1;
[C2, idxC2] = min(neu.avg_CAP(idxC, :)); idxC2 = idxC2+idxC(1)-1;

Cfiber = C1'-C2';
%% plot

% IDX = [idxA1; idxminval;  idxB2; idxminEMG; idxmaxEMG; idxC1; idxC2];
% VAL = [A1; minval;  B2; minEMG; maxEMG; C1; C2];
% 

% for ii = 1:length(neu.avg_CAP(1, :))
%     if physio
%     subplot(121),
%     end
%     plot(tv(IDX( :, ii)), 100*ii+VAL( :, ii), '*');
%  
% end
xlim([-1.05 20.1])
line([pw pw]/1000, get(gca, 'ylim'), 'color', 'k')
line([0 0 ], get(gca, 'ylim'), 'color', 'k')
patch('YData',[get(gca, 'ylim') fliplr(get(gca, 'ylim'))],'XData',[rangeA(1) rangeA(1) rangeA(2) rangeA(2)  ],'FaceAlpha',0.3,'LineStyle','none',...
    'FaceColor',[1 0.3 0.3]);
patch('YData',[get(gca, 'ylim') fliplr(get(gca, 'ylim'))],'XData',[rangeB(1) rangeB(1) rangeB(2) rangeB(2)  ],'FaceAlpha',0.3,'LineStyle','none',...
    'FaceColor',[0.5 1 0.5]);
patch('YData',[get(gca, 'ylim') fliplr(get(gca, 'ylim'))],'XData',[rangeC(1) rangeC(1) rangeC(2) rangeC(2)  ],'FaceAlpha',0.3,'LineStyle','none',...
    'FaceColor',[1 1 0.5]);


if physio
    
       subplot(143),  
       yl = [350 1600];
      patch('YData',[yl fliplr(yl)],'XData',[0 0 10 10  ],'FaceAlpha',0.3,'LineStyle','none',...
    'FaceColor',[238 230 255]/255); hold on
   
    subplot(144), yl = [0 12];
      patch('YData',[yl fliplr(yl)],'XData',[0 0 10 10  ],'FaceAlpha',0.3,'LineStyle','none',...
    'FaceColor',[238 230 255]/255), hold on
    
    
for i = 1:length(curve)
    c = curve{i};
    
%     subplot(185),  plot(c.hr(:, 1), i*70+c.hr(:, 2)); hold on,  ylabel('hr')
%     subplot(186), plot(c.ecg_breath(:, 1), i+c.ecg_breath(:, 3)); hold on,  ylabel('nasal sensor')
%     subplot(187), plot(c.br(:, 1), 100*i+c.br(:, 2));ylabel('br');  hold on,  ylabel('breathing rate')
%     subplot(188), plot(c.pk2pkbr(:, 1), i+c.pk2pkbr(:, 2)); hold on,  ylabel('peak to peak')

%     subplot(143),  plot(c.hr(:, 1), i*70+c.hr(:, 2)); hold on,  ylabel('hr')
%     xlim([-10 20]), xlabel('Time (seconds)')
%     subplot(144), plot(c.ecg_breath(:, 1), i+c.ecg_breath(:, 3)); hold on,  ylabel('nasal sensor')
%       xlim([-10 20]), xlabel('Time (seconds)')
 
      
         subplot(143),  plot(c.hr(:, 1), i*100+c.hr(:, 2), 'linewidth', 1); hold on,  
        title('heart rate', 'fontweight', 'normal'), set(gca, 'fontsize', 14), xlabel('Time (sec)')
        
        subplot(144), plot(c.ecg_breath(:, 1), i+c.ecg_breath(:, 3), 'linewidth', 1); hold on,  
        title('nasal sensor', 'fontweight', 'normal'), set(gca, 'fontsize', 14),  xlabel('Time (sec)')

    
end

% subplot(185);

 subplot(121);
title(['freq = ' num2str(Tselo.freq(1)) ...
    '; pol = ' num2str(Tselo.pol(1)) ...
    '; pw = ' num2str(Tselo.pw(1)) ...
    '; FT = ' num2str(Tselo.FT(1))]);

end


end