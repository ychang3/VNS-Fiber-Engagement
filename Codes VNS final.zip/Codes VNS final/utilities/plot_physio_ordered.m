function[] = plot_physio_ordered(curve, Tselo)



figure
for i = 1:length(curve)
    c = curve{i};
    
  subplot(141),  plot(c.hr(:, 1), i*200+c.hr(:, 2)); hold on,  ylabel('hr')
 subplot(142), plot(c.ecg_breath(:, 1), i+c.ecg_breath(:, 3)); hold on,  ylabel('nasal sensor')
  subplot(143), plot(c.br(:, 1), 100*i+c.br(:, 2));ylabel('br');  hold on,  ylabel('breathing rate')
 subplot(144), plot(c.pk2pkbr(:, 1), i+c.pk2pkbr(:, 2)); hold on,  ylabel('peak to peak')

end

subplot(141); 
title(['freq = ' num2str(Tselo.freq) ...
    '; pol = ' num2str(Tselo.pol) ...
    '; pw = ' num2str(Tselo.pw) ...
    '; FT = ' num2str(Tselo.FT)]);

end







