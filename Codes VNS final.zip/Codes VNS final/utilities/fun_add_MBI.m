function [maxInt0, meanInt0] =  fun_add_MBI(curve_tot)

for i = 1:length(curve_tot)
    curve = curve_tot{i};
    % breath
    N = 6; sec_pre = 10; sec_post = 10;
    [ idx_pre] =(curve.br(:, 1)< 0 & curve.br(:, 1)  > -sec_pre);
    [idx_dur] = (curve.br(:, 1) > 0.5 & curve.br(:, 1) < 10);
    [idx_post] = (curve.br(:, 1) > 10 & curve.br(:, 1) < 10 + sec_post);
    
    
    
    chi_first = find( curve.pk2pkbr(:, 1)< 0, 1,'last') ;
    chi_last = find( curve.pk2pkbr(:, 1)> 10, 1, 'first') ;
    
    if isempty(chi_last)
        maxInt0i = 20;
        meanInt0i = maxInt0i;
    elseif chi_last-chi_first == 1
        maxInt0i = curve.pk2pkbr(chi_last, 1) - curve.pk2pkbr(chi_first, 1);
        meanInt0i = maxInt0i;
    else
        maxInt0i = max(diff(curve.pk2pkbr(chi_first:chi_last, 1)));
        meanInt0i = mean(diff(curve.pk2pkbr(chi_first:chi_last, 1)));
    end
    
    maxInt0(i,1) = maxInt0i;
    meanInt0(i,1) = meanInt0i;
    
    
end

end