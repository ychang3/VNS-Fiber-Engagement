function[] = plot_neural_ordered(neu, curve, Tselo, rangeA, rangeB, rangeC)

pw = Tselo.pw;
% velA = fliplr([5 120]); rangeA = d./velA; % ms
% velB = fliplr([2 5]); rangeB = d./velB;
% velC = fliplr([0.1 0.8]); rangeC = d./velC;
%
tv = (0:length(neu.avg_CAP(:, 1))-1)/30-1;
figure;
for ii = 1:length(neu.avg_CAP(1, :))
    subplot(121), plot(tv, 100*ii+neu.avg_CAP(:, ii));  hold on
end
xlim([-1.05 20.1])
line([pw pw]/1000, get(gca, 'ylim'), 'color', 'k')
line([0 0 ], get(gca, 'ylim'), 'color', 'k')

patch('YData',[get(gca, 'ylim') fliplr(get(gca, 'ylim'))],'XData',[rangeA(1) rangeA(1) rangeA(2) rangeA(2)  ],'FaceAlpha',0.3,'LineStyle','none',...
    'FaceColor',[1 0.3 0.3]);
patch('YData',[get(gca, 'ylim') fliplr(get(gca, 'ylim'))],'XData',[rangeB(1) rangeB(1) rangeB(2) rangeB(2)  ],'FaceAlpha',0.3,'LineStyle','none',...
    'FaceColor',[0.5 1 0.5]);
patch('YData',[get(gca, 'ylim') fliplr(get(gca, 'ylim'))],'XData',[rangeC(1) rangeC(1) rangeC(2) rangeC(2)  ],'FaceAlpha',0.3,'LineStyle','none',...
    'FaceColor',[1 1 0.5]);

line([pw pw]/1000, get(gca, 'ylim'), 'color', 'k', 'linewidth', 1)
line([0 0 ], get(gca, 'ylim'), 'color', 'k', 'linewidth', 1)
xlabel('ms'), ylabel('neural')


for i = 1:length(curve)
    c = curve{i};
    
    subplot(185),  plot(c.hr(:, 1), i*200+c.hr(:, 2)); hold on,  ylabel('hr')
    subplot(186), plot(c.ecg_breath(:, 1), i+c.ecg_breath(:, 3)); hold on,  ylabel('nasal sensor')
    subplot(187), plot(c.br(:, 1), 100*i+c.br(:, 2));ylabel('br');  hold on,  ylabel('breathing rate')
    subplot(188), plot(c.pk2pkbr(:, 1), i+c.pk2pkbr(:, 2)); hold on,  ylabel('peak to peak')
    
end

subplot(185);
title(['freq = ' num2str(Tselo.freq) ...
    '; pol = ' num2str(Tselo.pol) ...
    '; pw = ' num2str(Tselo.pw) ...
    '; FT = ' num2str(Tselo.FT)]);



end