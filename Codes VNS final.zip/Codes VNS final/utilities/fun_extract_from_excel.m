function [fold, rangeA, rangeB, rangeC, tmin1, tmin_1, estrB2, tEMG, discard, Cmin2max1, Cmin2max2] = fun_extract_from_excel(Aex, bex,y)
 

fold = bex(y, 1); fold = fold{1}; d = Aex(y,1); 
tmin1 = bex(y, 3); tmin1 = tmin1{1};   
ix1 = regexp(tmin1,['[*\d.\d+ * '],'match'); ix1 = ix1{1}; ix1 = str2double(ix1(2:end-1));
ix2 = regexp(tmin1,[' *\d.\d+]'],'match'); ix2 = ix2{1}; ix2 = str2double(ix2(2:end-1));
tmin1 = [ix1 ix2];

tmin_1 = bex(y, 4); tmin_1 = tmin_1{1};   
ix1 = regexp(tmin_1,['[*\d.\d+ * '],'match'); ix1 = ix1{1}; ix1 = str2double(ix1(2:end-1));
ix2 = regexp(tmin_1,[' *\d.\d+]'],'match'); ix2 = ix2{1}; ix2 = str2double(ix2(2:end-1));
tmin_1 = [ix1 ix2];

rangeA = bex(y, 6); rangeA = rangeA{1};   
ix1 = regexp(rangeA,['[*\d.\d+ * '],'match'); ix1 = ix1{1}; ix1 = str2double(ix1(2:end-1));
ix2 = regexp(rangeA,[' *\d.\d+]'],'match'); ix2 = ix2{1}; ix2 = str2double(ix2(2:end-1));
rangeA = [ix1 ix2];

rangeB = bex(y, 7); rangeB = rangeB{1};   
ix1 = regexp(rangeB,['[*\d.\d+ * '],'match'); ix1 = ix1{1}; ix1 = str2double(ix1(2:end-1));
ix2 = regexp(rangeB,[' *\d.\d+]'],'match'); ix2 = ix2{1}; ix2 = str2double(ix2(2:end-1));
rangeB = [ix1 ix2];

tEMG = bex(y, 8); tEMG = tEMG{1};   
ix1 = regexp(tEMG,['[*\d.\d+ * '],'match'); ix1 = ix1{1}; ix1 = str2double(ix1(2:end-1));
ix2 = regexp(tEMG,[' *\d.\d+]'],'match'); ix2 = ix2{1}; ix2 = str2double(ix2(2:end-1));
tEMG = [ix1 ix2];


estrB2 = Aex(y, 4);
Cmin2max1 = Aex(y, 8);
Cmin2max2 = Aex(y, 9);


velC = fliplr([0.3 0.9]); rangeC = d./velC;

A1 = isempty(bex{y, 12});
A_1 = isempty(bex{y, 13});
B1 = isempty(bex{y, 14});
B_1 = isempty(bex{y, 15});

discard = [A1 A_1; B1 B_1];

end

