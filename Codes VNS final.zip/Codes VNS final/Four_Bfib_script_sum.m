%% correlation

clear all
close all

CO = [255 25 25;  0 102 34; 204 102 0;
    128 128 0 ; 187 153 255;
    136 204 0; 51 8 0; 66 229 244;
    0 14 142; 71 0 142 ; 111 109 114;
    255 85 0; 255 102 102; 77 77 255 ] / 256;

PATH = 'D:\TNP\Manuscript\Fiber Recruitment\DATA';
file = 'data_table_neural_physio';
load([PATH '\' file '.mat']);
% infopath
% [Aex, bex, cex] = xlsread(excelfile, num2str(100));
% fold_tot = bex(2:end, 1);
% direc = path_dati;



normal = 1;
fig_sing = 1;
n = 3; B = 200;  discr_pol = 0; fitvar = 1;
val_norm = []; po = [1 -1];
mark = {'.', 'o'}; sizemark = [18 8]; linest = {'-', '--'};
which_pw_tot = [60 100 300 500 600 1000];
%                1   2   3   4   5   6
which_pw = which_pw_tot([1:6]);
 posB = 1;   legB = {}; 
val_totA = []; val_totB = [];
for pol = 1:2
    
    posBc = 1; 
    for i = 1:length(fold_tot)
%         clear T TBL_neu
%         experimentdir  = [direc fold_tot{i}];
%         load([experimentdir '\TBL_neu2.mat'])
        T = table_exp{i};
        T.deltaHR  = (T.HRpre - T.HRdur)./T.HRpre*100;
        T.deltaBR  = (T.BRpre - T.BRdur)./T.BRpre*100;
        T.deltaBR(isnan(T.deltaBR )) = 100;
        
         if i == 1 || i == 8
              T = T(T.pol == 1, :);
         elseif i == 2 || i == 5 || i == 10 || i == 11 
            T = T(T.pol == -1, :);
         end
        
         T(T.deltaHR > 50, :) = [];
         T(T.Bfiber > 50, :) = [];

         
           if i == 3
              T(T.deltaHR > 16, :) = [];
           end
           
           if i == 1
              T(T.deltaHR > 8 & T.Bfiber < 5, :) = [];
           end
        
           if i == 4 || i == 5
            continue
           end
%         
        if ~discr_pol
            Tpi = T(isnan(T.FT) & ismember(T.pw, which_pw) & abs(T.pol) == 1, :) ;
        else
            Tpi = T(isnan(T.FT) & ismember(T.pw, which_pw) & (T.pol) == po(pol), :) ;
        end
        
        %% %%%%%%%%%%%%%%%%%%%%%% B
        clear val
        
            
            x = Tpi.deltaHR; y = Tpi.Bfiber; z = Tpi.amp; h = Tpi.pw;  w = Tpi.pol; val = [x y z h w];
           
         
            val(y>60 | x < 0, :) = []; val(isnan(sum(val, 2)), :) = [];
              if length(val(:,1))<2; continue; end
%             if mean(val(:,1))<5;  continue; end
            
           
            if fig_sing
                 pola = [1 -1];
                 for p = 1:2
                    pola_chosen = pola(p);
                    val_po = val(val(:,4) == 100 & val(:, 5) == pola_chosen, :);
                    axs = val_po(:,3); %.*val_po(:,4);
                    [axs, ifs] = sort(axs) ;
                    val_po  = val_po(ifs, :);
                    figure(i), subplot(131), plot(axs, val_po(:, 1),'Marker',  '.', 'markersize',16)  , xlabel('x th.'), ylabel('HR'), hold on
                    subplot(132), plot(axs, val_po(:, 2), 'Marker',  '.', 'markersize',16) , xlabel('x th.'), ylabel('B fiber'), hold on
                    subplot(133), plot(val_po(:,1), val_po(:, 2),   '.', 'markersize',16)  , xlabel('HR'), ylabel('B fiber'), hold on
                    title([fold_tot{i}(1:end-1) ] )
                    
                end
            end
            
            
            figure(B)
            plot(val(:,1), val(:,2), mark{pol}, 'markersize', sizemark(pol), 'color', CO(i, :));  hold on;
            ylabel('B fiber'), xlabel('delta HR'), hold on, set(gca, 'fontsize', 14)
            
            fit_type1=fittype('A*(1-exp(-x./T))','coefficients', {'A', 'T'},'indep','x');
            [tilp, gofi]=fit(val(:,1), val(:,2),fit_type1,'Robust','on', ...
                'StartPoint', [max(val(:, 2)) , 3], 'Lower',[max(val(:, 2)), 0], 'MaxIter', 1e6, 'TolFun', 1e-7);
            coeffvals =  coeffvalues(tilp); fittedX = linspace(0, max(val(:,1)), 100);
            errorB(posB) = gofi.rmse;
            NormerrorB(posB) = gofi.rmse/(range(val(:,2)));
            AccurB(posB) = 1-NormerrorB(posB);
            stdB(posB) = std(val(:,2)) ;
            co = corrcoef(feval(tilp, val(:, 1)), val(:, 2));
            corre(posB)  = co(1, 2);
            h1 = plot(fittedX, feval(tilp, fittedX), 'color', CO(i, :),'linewidth', 1, 'linestyle', linest{pol});
            set(get(get(h1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
            
            legB{posB} = fold_tot{i}; posB = posB +1; posBc = posBc +1;
            figure(B), legend(legB);
             charge = val(:,3).*val(:,4);
            val_totB = [val_totB; [val(:, 1)./max(val(:, 1)) val(:, 2)./max(val(:, 2)) charge]];
            
            
        
    end
    if ~discr_pol
      break
    end
end

%% Accuracy
figure
 plot(val_totB(:,1), val_totB(:,2), '.', 'markersize', 10), hold on
ylabel('B fiber'), xlabel('delta HR'), hold on, set(gca, 'fontsize', 14)
fit_type1=fittype('A*(1-exp(-x./T))','coefficients', {'A', 'T'},'indep','x');
[tilp, gofi]=fit(val_totB(:,1), val_totB(:,2),fit_type1,'Robust','on', ...
    'StartPoint', [max(val_totB(:, 2)) , 3], 'Lower',[max(val_totB(:, 2)), 0], 'MaxIter', 1e6, 'TolFun', 1e-7);
coeffvals =  coeffvalues(tilp); fittedX = linspace(0, max(val_totB(:,1)), 100);
NormerrorBt = gofi.rmse/(range(val_totB(:,2)));
AccurBt = 1-NormerrorBt;

h1 = plot(fittedX, feval(tilp, fittedX), 'color','k','linewidth', 1, 'linestyle',linest{1});
set(get(get(h1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
title(['RMSE = ' num2str(gofi.rmse) ])

%% color code
[uu, ~, posi] = unique(val_totB(:, 3), 'sorted'); ss = colormap;
uu = uu(1:32);
figure
for u = 1:length(uu)
    idx = find(posi == u);
    plot(val_totB(idx,1), val_totB(idx,2), 'o', 'markersize', 6, 'MarkerEdgeColor','k', 'MarkerFaceColor', ss(u*2, :)), hold on
end
ylabel('B fiber'), xlabel('delta HR'), hold on, set(gca, 'fontsize', 14)
xlim([-0.01 1.01]); ylim([-0.01 1.01]);
h1 = plot(fittedX, feval(tilp, fittedX), 'color','k','linewidth', 1, 'linestyle',linest{1});
set(get(get(h1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
title(['RMSE = ' num2str(gofi.rmse) ])
