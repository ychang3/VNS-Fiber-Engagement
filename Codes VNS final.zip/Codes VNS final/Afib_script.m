%% correlation

clear all
close all

CO = [255 25 25;  0 102 34; 204 102 0;
    128 128 0 ; 187 153 255;
    136 204 0; 51 8 0; 66 229 244;
    0 14 142; 71 0 142 ; 111 109 114;
    255 85 0; 255 102 102; 77 77 255 ;
    255 187 51;  255 179 191; 0 0 0] / 256;


infopath
[Aex, bex, cex] = xlsread(excelfile, num2str(100));
fold_tot = bex(2:end, 1);
direc = path_dati;

n = 3; A = 100;  discr_pol = 0; fitvar = 1; fig_sing = 0;
val_norm = []; po = [1 -1];
mark = {'.', 'o'}; sizemark = [18 8]; linest = {'-', '--'};

which_pw_tot = [60 100 300 500 600 1000];
%                1   2   3   4   5   6
which_pw = which_pw_tot([1:6]);
posA = 1; legA = {}; legB = {};
val_totA = []; val_totA = [];

% bipo = [1 , 2, 7, 11];
% tripo = [3,4,5,6,8,10];

for pol = 1:2
       
    posAc = 1;
    for i = 1:length(fold_tot)
%          if ~ismember(i, bipo)
%        continue
%     end
        clear T TBL_neu
        experimentdir  = [direc fold_tot{i}];
        load([experimentdir '\TBL_neu2.mat'])
        T = TBL_neu;
        T.deltaBR  = (T.BRpre - T.BRdur)./T.BRpre*100;
        T.deltaBR(isnan(T.deltaBR )) = 100;
        
        if i == 1
%             T = T(T.pol == -1, :);
            continue
        elseif i == 7
            T = T(T.pol == 1, :);
        elseif i == 8
            T = T(T.pol == 1, :);
            
        elseif i == 10
            T = T(T.pol == 1, :);
        elseif i == 11
            T = T(T.pol == 1, :);
        end
        
        if ~discr_pol
            Tpi = T(isnan(T.FT) & ismember(T.pw, which_pw) & abs(T.pol) == 1, :) ;
        else
            Tpi = T(isnan(T.FT) & ismember(T.pw, which_pw) & (T.pol) == po(pol), :) ;
            
        end
        
        %% %%%%%%%%%%%%%%%%%%%%%% A
        clear val fittype1
        
        
        x = Tpi.EMG; y = Tpi.Afiber; z = Tpi.amp; h = Tpi.pw; w = Tpi.pol; val = [x y z h w];
        val(x>120, :) = []; val(isnan(sum(val, 2)), :) = [];
        if length(val(:,1))<4; continue; end
        if mean(val(:,2))<10;  continue; end
        
          pola = [1 -1];
        if fig_sing
            for p = 1:2
                pola_chosen = pola(p);
            val_po = val(val(:,4) == 100 & val(:, 5) == pola_chosen, :); 
            axs = val_po(:,3); %.*val_po(:,4);
            [axs, ifs] = sort(axs) ;
            val_po  = val_po(ifs, :);
            figure(i), subplot(131), plot(axs, val_po(:, 1),'Marker',  '.', 'markersize',16)  , xlabel('x th.'), ylabel('EMG'), hold on
            subplot(132), plot(axs, val_po(:, 2), 'Marker',  '.', 'markersize',16) , xlabel('x th.'), ylabel('A fiber'), hold on
             subplot(133), plot(val_po(:,1), val_po(:, 2),   '.', 'markersize',16)  , xlabel('EMG'), ylabel('A fiber'), hold on
             title(fold_tot{i}(1:end-1) )
             
            end
        end
        figure(A)
        plot(val(:,1), val(:,2),  mark{pol}, 'markersize', sizemark(pol), 'color', CO(i, :));  hold on;
        ylabel('A fiber'), xlabel('EMG pk2pk'), hold on, set(gca, 'fontsize', 14)
        
        if fitvar
            fit_type1=fittype('A*x','coefficients', { 'A'},'indep','x');
            [tilp, gofi]=fit(val(:,1), val(:,2),fit_type1,'Robust','on', ...
                'StartPoint', [ 0.5 ], 'Lower',[ 0], 'MaxIter', 1e6, 'TolFun', 1e-7);
            coeffvals =  coeffvalues(tilp); fittedX = linspace(0, max(val(:,1)), 10);
            errorA(posA) = gofi.rmse;
            NormerrorA(posA) = gofi.rmse/(range(val(:,2)));
            AccurA(posA) = 1-NormerrorA(posA);
            stdA(posA) = std(val(:,2)) ;
              co = corrcoef(feval(tilp, val(:, 1)), val(:, 2));
            corre(posA)  = co(1, 2);
            h1 = plot(fittedX, feval(tilp, fittedX), 'color', CO(i, :),'linewidth', 1, 'linestyle',linest{pol});
            set(get(get(h1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
            legA{posA} = fold_tot{i}(1:end-1); posA = posA +1; posAc = posAc +1;
            
             charge = val(:,3).*val(:,4);
            val_totA = [val_totA; [val(:, 1)./max(val(:, 1)) val(:, 2)./max(val(:, 2)) charge val(:, 5)]];
            
            figure(A), legend(legA);
            
        end

    end
    
    if ~discr_pol
        break;
    end
end

%% Accuracy


figure, plot(val_totA(:,1), val_totA(:,2), '.', 'markersize', 10), hold on
ylabel('A fiber'), xlabel('EMG pk2pk'), hold on, set(gca, 'fontsize', 14)
fit_type1=fittype('A*x','coefficients', { 'A'},'indep','x');
[tilp, gofi]=fit(val_totA(:,1), val_totA(:,2),fit_type1,'Robust','on', ...
    'StartPoint', [ 0.5 ], 'Lower',[ 0], 'MaxIter', 1e6, 'TolFun', 1e-7);
coeffvals =  coeffvalues(tilp); fittedX = linspace(0, max(val_totA(:,1)), 10);
NormerrorAt = gofi.rmse/(range(val_totA(:,2)));
AccurAt = 1-NormerrorAt;

h1 = plot(fittedX, feval(tilp, fittedX), 'color','k','linewidth', 1, 'linestyle',linest{1});
set(get(get(h1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
[r , pp] = corr(val_totA(:,1), val_totA(:,2));
title(['RMSE = ' num2str(gofi.rmse) ', R = ' num2str(r) ', p << 0.001'])

%% color code
% val_totA = val_totA(val_totA(:, 3) > 100 & val_totA(:, 3) < 2400, :);
[uu, ~, posi] = unique(val_totA(:, 3), 'sorted'); ss = colormap;
y = sum(val_totA(:, 3)==val_totA(:, 3)');
va2 = val_totA; 
va2(y == 1, :) = [];
va2(y == 2, :) = [];

[uu, chu, posi] = unique(va2(:, 3), 'sorted'); ss = colormap;
colo = linspace(1, 64, length(uu));
colo = round(colo);
ss = ss(colo, :);
figure; 
for u = 1:length(uu)
    idx = find(posi == u); 
 plot(va2(idx,1), va2(idx,2), 'o', 'markersize', 6, 'MarkerEdgeColor','k', 'MarkerFaceColor', ss(u, :)),
 hold on; if length(idx) > 2;  end
end
ylabel('A fiber'), xlabel('EMG'), hold on, set(gca, 'fontsize', 14)
xlim([-0.01 1.01]); ylim([-0.01 1.01]);
h1 = plot(fittedX, feval(tilp, fittedX), 'color','k','linewidth', 1, 'linestyle',linest{1});
set(get(get(h1,'Annotation'),'LegendInformation'),'IconDisplayStyle','off');
title(['RMSE = ' num2str(gofi.rmse) ])

%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

