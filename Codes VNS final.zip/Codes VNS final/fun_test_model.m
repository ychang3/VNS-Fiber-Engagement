function [modello, rsq, RMSE] = fun_test_model(Testing,S, ifplot)

 Testing_arr = table2array(Testing);
    if mod(length(S), 2) == 0
    s = 1;
    modello = 0;
else
    s = 2;
    modello = S(1);
end

modello =  modello + S(s)*Testing.amp +  S(s+1)*Testing.EMG + ...
    S(s+2)*Testing.deltaHR +  S(s+3)*Testing.deltaINT +...
    S(s+4)*Testing.amp.^2 +S(s+5)*Testing.EMG.^2 +  ...
    S(s+6)*Testing.deltaHR.^2 + S(s+7)*Testing.deltaINT.^2;

modello(modello<0) = 0;

% without CL
Testing_fiber = Testing.Fiber;
dist = diff([modello Testing_fiber], 1, 2);
RMSE  = rms(dist);
rsq = (corrcoef(Testing_fiber , modello)); rsq = rsq(1, 2)^2;

if ifplot
plot(Testing_fiber, modello, '.', 'markersize', 14)
% aa = [get(gca, 'xlim'); get(gca, 'ylim')];
% xlim([0 max(aa(:, 2))]);  ylim([0 max(aa(:, 2))]);
aa = max([max(Testing_fiber) max( modello)]) + 0.1;
% xlim([0 max(aa(:, 2))]);  ylim([0 max(aa(:, 2))]);
% hold on, line([0  max(aa(:, 2))], [0  max(aa(:, 2)) ])
xlim([0 aa]);  ylim([0 aa]);
hold on, line([0  aa], [0  aa ])

xlabel('actual'), ylabel('predicted')
set(gca, 'fontsize', 14)
title([num2str(rsq) ' ' num2str(RMSE)])
end
end

