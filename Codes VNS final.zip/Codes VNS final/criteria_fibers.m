function[out, TBL_neu, MAXEMG] = criteria_fibers(fiber, TBL_neu, i, MAXEMG)

out = 0;
switch fiber
    
    case 'A'
        %% AA
        if i == 1;  out = 1;
        elseif i == 10
            TBL_neu = TBL_neu(TBL_neu.pol == 1, :);
            MAXEMG = mean(TBL_neu.EMG(TBL_neu.pw>=500 & TBL_neu.pw<=600  & TBL_neu.amp >= 6 & TBL_neu.amp <=8 & isnan(TBL_neu.FT)));
        elseif  i == 2
            TBL_neu = TBL_neu(TBL_neu.pol == 1, :);
            
        elseif  i == 8
            TBL_neu = TBL_neu(TBL_neu.pol == -1, :);
            
        elseif i == 5
            TBL_neu(TBL_neu.EMG > 100, :) = [];
            MAXEMG = mean(TBL_neu.EMG(TBL_neu.pw>=500 & TBL_neu.pw<=600  & TBL_neu.amp >= 6 & TBL_neu.amp <=8 & isnan(TBL_neu.FT)));
        elseif i == 7
            TBL_neu(TBL_neu.EMG > 170, :) = [];
            MAXEMG = mean(TBL_neu.EMG(TBL_neu.pw>=500 & TBL_neu.pw<=600  & TBL_neu.amp >= 6 & TBL_neu.amp <=8 & isnan(TBL_neu.FT)));
            
        else; end
        
        
    case 'B'
        if i == 1 || i == 8
            TBL_neu = TBL_neu(TBL_neu.pol == 1, :);
        elseif i == 2  || i == 11  || i == 5 % || i == 10 || i == 5
            TBL_neu = TBL_neu(TBL_neu.pol == -1, :);
        end
        if i == 11
            TBL_neu(TBL_neu.deltaHR > 50, :) = []; %TBL_neu(TBL_neu.Bfiber > 50, :) = [];
        end
        %
        %             if i == 3; TBL_neu(TBL_neu.deltaHR > 16, :) = []; end
        %
        %             if i == 1; TBL_neu(TBL_neu.deltaHR > 8 & TBL_neu.Bfiber < 5, :) = []; end
        %
        if i == 4  || i == 5
            out = 1;
        end
        
    case 'C'
        if i == 1 || i == 7 || i == 8; out = 1; end
        if i == 2 ; TBL_neu = TBL_neu(TBL_neu.pol == 1, :); end  %
        %             if i == 3 ; TBL_neu = TBL_neu(TBL_neu.pol == -1, :); end
        %              if i == 5 ; TBL_neu = TBL_neu(TBL_neu.pol == -1, :); end
        %             if i == 6 ; TBL_neu = TBL_neu(TBL_neu.pol == 1, :); end  %
        if i == 9 ; TBL_neu = TBL_neu(TBL_neu.pol == -1, :); end  %
        if i == 10 ; TBL_neu = TBL_neu(TBL_neu.pol == -1, :); end  %
        if i == 11 ; TBL_neu = TBL_neu(TBL_neu.pol == -1, :); end  %
end

end